import F18.KernelTrace
import F18.Integrability
import F18.SpinCharacter

namespace F18
open MeasureTheory
open scoped Matrix

noncomputable def operatorIntegral {N : ℕ} (μ : Measure Sphere)
    (F : Sphere → Operator N) : Operator N := fun i j => ∫ p, F p i j ∂μ

theorem operatorIntegral_mul_left {N : ℕ} (μ : Measure Sphere)
    (A : Operator N) (F : Sphere → Operator N) (hF : ∀ i j, Integrable (fun p => F p i j) μ) :
    operatorIntegral μ (fun p => A * F p) = A * operatorIntegral μ F := by
  ext i j
  simp only [operatorIntegral, Matrix.mul_apply]
  rw [integral_finset_sum]
  · simp only [integral_const_mul]
  · intro k _
    exact (hF k j).const_mul (A i k)

theorem operatorIntegral_mul_right {N : ℕ} (μ : Measure Sphere)
    (F : Sphere → Operator N) (A : Operator N) (hF : ∀ i j, Integrable (fun p => F p i j) μ) :
    operatorIntegral μ (fun p => F p * A) = operatorIntegral μ F * A := by
  ext i j
  simp only [operatorIntegral, Matrix.mul_apply]
  rw [integral_finset_sum]
  · simp only [integral_mul_const]
  · intro k _
    exact (hF i k).mul_const (A k j)

theorem trace_operatorIntegral {N : ℕ} (μ : Measure Sphere)
    (F : Sphere → Operator N) (hF : ∀ i, Integrable (fun p => F p i i) μ) :
    Matrix.trace (operatorIntegral μ F) = ∫ p, Matrix.trace (F p) ∂μ := by
  simp only [Matrix.trace, Matrix.diag_apply, operatorIntegral]
  rw [integral_finset_sum _ (fun i _ => hF i)]

private theorem integrable_continuous_compact {E : Type*} [NormedAddCommGroup E]
    {μ : Measure Sphere} [IsFiniteMeasure μ] {f : Sphere → E} (hf : Continuous f) :
    Integrable f μ := by
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  exact hf.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace f)

private theorem integral_comp_measurePreserving {μ : Measure Sphere} (r : Sphere → Sphere)
    (h : MeasurePreserving r μ μ) {f : Sphere → ℂ} (hf : Measurable f) :
    (∫ p, f (r p) ∂μ) = ∫ p, f p ∂μ := by
  rw [← integral_map h.measurable.aemeasurable hf.aestronglyMeasurable, h.map_eq]

/-- Integrating the exact kernel gives the identity once rotation invariance
has been established for the original spin measure. -/
theorem operatorIntegral_kernel_eq_one (N : ℕ) (signs : Weight N → Bool)
    (hrot : ∀ u : UnitSpinor, MeasurePreserving (spinorRotation u) (spinMeasure N) (spinMeasure N)) :
    operatorIntegral (spinMeasure N) (kernel N signs) = 1 := by
  let μ := spinMeasure N
  let A := operatorIntegral μ (kernel N signs)
  have hK : Continuous (kernel N signs) := continuous_kernel N signs
  have hiK (i j : Weight N) : Integrable (fun p => kernel N signs p i j) μ :=
    integrable_continuous_compact (hK.matrix_elem i j)
  have hcomm (u : UnitSpinor) :
      A * spinMatrix N u.val.1 u.val.2 = spinMatrix N u.val.1 u.val.2 * A := by
    let U := spinMatrix N u.val.1 u.val.2
    have hleft (i j : Weight N) : Integrable (fun p => (U * kernel N signs p) i j) μ :=
      integrable_continuous_compact ((continuous_const.matrix_mul hK).matrix_elem i j)
    have hcov : A = U * A * Uᴴ := by
      calc
        _ = operatorIntegral μ (fun p => kernel N signs (spinorRotation u p)) := by
          ext i j
          exact (integral_comp_measurePreserving _ (hrot u) (hK.matrix_elem i j).measurable).symm
        _ = operatorIntegral μ (fun p => (U * kernel N signs p) * Uᴴ) := by
          apply congrArg (operatorIntegral μ)
          funext p
          exact kernel_spinorRotation N signs u p
        _ = _ := by rw [operatorIntegral_mul_right _ _ _ hleft, operatorIntegral_mul_left _ _ _ hiK]
    calc
      A * U = (U * A * Uᴴ) * U := congrArg (· * U) hcov
      _ = U * A := by rw [Matrix.mul_assoc _ Uᴴ U, spinMatrix_conjTranspose_mul_self N u, mul_one]
  obtain ⟨c, hc⟩ := spin_commutant_scalar A hcomm
  have htrace : Matrix.trace A = ((N+1 : ℕ) : ℂ) := by
    change Matrix.trace (operatorIntegral μ (kernel N signs)) = _
    rw [trace_operatorIntegral _ _ (fun i => hiK i i)]
    simp_rw [kernel_trace_eq_one]
    rw [integral_const, measureReal_def, spinMeasure_mass, ENNReal.toReal_natCast]
    simp
  have hc' : c = 1 := by
    rw [hc, Matrix.trace_diagonal, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      nsmul_eq_mul] at htrace
    exact mul_left_cancel₀ (Nat.cast_ne_zero.mpr (Nat.succ_ne_zero N)) (by simpa using htrace)
  change A = 1
  rw [hc, hc']
  exact Matrix.diagonal_one

theorem integral_wigner_eq_squaredNorm {N : ℕ} (signs : Weight N → Bool) (ψ : State N)
    (hrot : ∀ u : UnitSpinor, MeasurePreserving (spinorRotation u) (spinMeasure N) (spinMeasure N)) :
    (∫ p, wigner signs ψ p ∂spinMeasure N) = squaredNorm ψ := by
  let μ := spinMeasure N
  let F : Sphere → Operator N := fun p => projector ψ * kernel N signs p
  have hK := continuous_kernel N signs
  have hF : Continuous F := continuous_const.matrix_mul hK
  have he : (∫ p, (wigner signs ψ p : ℂ) ∂μ) = (squaredNorm ψ : ℂ) := by
    simp_rw [← complex_trace_eq_wigner]
    change (∫ p, Matrix.trace (F p) ∂μ) = _
    rw [← trace_operatorIntegral _ _ (fun i => integrable_continuous_compact (hF.matrix_elem i i))]
    unfold F
    rw [operatorIntegral_mul_left _ _ _ (fun i j => integrable_continuous_compact (hK.matrix_elem i j)),
      operatorIntegral_kernel_eq_one _ _ hrot, mul_one]
    simp only [Matrix.trace, Matrix.diag_apply, projector, squaredNorm, Complex.ofReal_sum,
      Complex.mul_conj]
  exact Complex.ofReal_injective (integral_complex_ofReal.symm.trans he)

end F18
