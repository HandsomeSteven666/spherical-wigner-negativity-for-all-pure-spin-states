import F18.KernelTrace
import F18.MeridianPolynomial
import F18.ClosingAssembly
import Mathlib.Algebra.BigOperators.Intervals

namespace F18
open scoped Matrix

private theorem choose_split (n a b : ℕ) (h : a+b ≤ n) :
    n.choose a * (n-a).choose b = n.choose (a+b) * (a+b).choose a := by
  rw [Nat.choose_mul h (by omega : a ≤ a+b), Nat.add_sub_cancel_left]

private theorem choose_split_comm (n a b : ℕ) (h : a+b ≤ n) :
    n.choose a * (n-a).choose b = n.choose b * (n-b).choose a := by
  rw [choose_split n a b h, choose_split n b a (by omega), Nat.add_comm b a,
    Nat.choose_symm_add]

private theorem choose_profile_product {N l q k : ℕ} (hl : l ≤ N)
    (hq : q ≤ l) (hk : k ≤ N-l) :
    N.choose (q+k) * (q+k).choose q * (N-(q+k)).choose (l-q) =
      N.choose l * l.choose q * (N-l).choose k := by
  rw [Nat.choose_mul (by omega : q+k ≤ N) (by omega : q ≤ q+k),
    Nat.add_sub_cancel_left, Nat.mul_assoc]
  have he : N-(q+k) = N-q-k := by omega
  rw [he, choose_split_comm (N-q) k (l-q) (by omega), ← Nat.mul_assoc,
    choose_split N q (l-q) (by omega),
    show q+(l-q) = l by omega, show N-q-(l-q) = N-l by omega]

def bernsteinWeight (N r : ℕ) (p : ℝ) : ℝ :=
  (N.choose r : ℝ) * p^r * (1-p)^(N-r)

/-- Collapse the support of a binomial slice before shifting its index. -/
theorem bernstein_choose_slice (N l q : ℕ) (hl : l ≤ N) (hq : q ≤ l) (p : ℝ) :
    (∑ r ∈ Finset.range (N+1), bernsteinWeight N r p *
      (r.choose q : ℝ) * ((N-r).choose (l-q) : ℝ)) =
        ((N.choose l * l.choose q : ℕ) : ℝ) * p^q * (1-p)^(l-q) := by
  let f := fun r : ℕ => bernsteinWeight N r p * (r.choose q : ℝ) * ((N-r).choose (l-q) : ℝ)
  change (∑ r ∈ Finset.range (N+1), f r) = _
  have hs : (∑ r ∈ Finset.Ico q (N-l+q+1), f r) = ∑ r ∈ Finset.range (N+1), f r := by
    apply Finset.sum_subset
    · intro r hr
      have := Finset.mem_Ico.mp hr
      exact Finset.mem_range.mpr (by omega)
    · intro r hr hnot
      have h₁ := Finset.mem_range.mp hr
      by_cases h₂ : q ≤ r
      · have h₃ : N-r < l-q := by
          have : ¬ r < N-l+q+1 := fun h => hnot (Finset.mem_Ico.mpr ⟨h₂,h⟩)
          omega
        simp [f, Nat.choose_eq_zero_of_lt h₃]
      · simp [f, Nat.choose_eq_zero_of_lt (show r < q by omega)]
  rw [← hs, Finset.sum_Ico_eq_sum_range, show N-l+q+1-q = N-l+1 by omega]
  let C : ℝ := ((N.choose l * l.choose q : ℕ) : ℝ) * p^q * (1-p)^(l-q)
  have he : (∑ k ∈ Finset.range (N-l+1), f (q+k)) = C *
      ∑ k ∈ Finset.range (N-l+1), p^k * (1-p)^(N-l-k) * ((N-l).choose k : ℝ) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro k hk
    have hk' := Finset.mem_range.mp hk
    have hp : N-(q+k) = (l-q)+(N-l-k) := by omega
    have hc := congrArg (fun x : ℕ => (x : ℝ))
      (choose_profile_product hl hq (show k ≤ N-l by omega))
    push_cast at hc
    rw [hp] at hc
    unfold f C bernsteinWeight
    rw [hp, pow_add p, pow_add (1-p)]
    push_cast
    linear_combination hc * (p^q * p^k * (1-p)^(l-q) * (1-p)^(N-l-k))
  rw [he, ← add_pow, show p + (1-p) = 1 by ring, one_pow, mul_one]

/-- The shifted Legendre expression obtained directly from the CG diagonal. -/
def shiftedLegendreValue (l : ℕ) (p : ℝ) : ℝ :=
  ∑ q ∈ Finset.range (l+1), (-1 : ℝ)^q * (l.choose q : ℝ)^2 * p^q * (1-p)^(l-q)

theorem bernstein_weighted_northCG (N : ℕ) (l : Weight N) (p : ℝ) :
    (∑ r : Weight N, bernsteinWeight N r.val p * northCG N r l) =
      cgScale N l.val * (N.choose l.val : ℝ) * shiftedLegendreValue l.val p := by
  simp only [northCG_choose, ← mul_assoc, Finset.mul_sum]
  rw [Finset.sum_comm]
  unfold shiftedLegendreValue
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro q hq
  have hs := bernstein_choose_slice N l.val q (Nat.le_of_lt_succ l.isLt)
    (Nat.le_of_lt_succ (Finset.mem_range.mp hq)) p
  let D := cgScale N l.val * (-1 : ℝ)^q * (l.val.choose q : ℝ)
  calc
    _ = D * ∑ r : Weight N, bernsteinWeight N r.val p *
      (r.val.choose q : ℝ) * ((N-r.val).choose (l.val-q) : ℝ) := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro r _
        unfold D
        ring
    _ = _ := by
      rw [Fin.sum_univ_eq_sum_range (fun r : ℕ => bernsteinWeight N r p *
        (r.choose q : ℝ) * ((N-r).choose (l.val-q) : ℝ)) (N+1), hs]
      unfold D
      push_cast
      ring


noncomputable def coherentProfileValue (N : ℕ) (signs : Weight N → Bool) (p : ℝ) : ℝ :=
  ∑ l : Weight N, (rankSign signs l * ((2*l.val+1 : ℕ) : ℝ) / ((N+1 : ℕ) : ℝ)) *
    (cgScale N l.val * (N.choose l.val : ℝ) * shiftedLegendreValue l.val p)

theorem wigner_coherent_north (N : ℕ) (signs : Weight N → Bool) (u : UnitSpinor) :
    wigner signs (coherentVec N u.val) northPoint =
      coherentProfileValue N signs (Complex.normSq u.val.2) := by
  have hn : spinor northPoint = (1,0) := by norm_num [northPoint, spinor]
  have hk : kernel N signs northPoint =
      Matrix.diagonal (fun r => (poleEigenvalue N signs r : ℂ)) := by
    simp only [kernel, hn, spinMatrix_one, Matrix.conjTranspose_one, one_mul, mul_one]
  have hw (r : Weight N) : Complex.normSq (coherentVec N u.val r) =
      bernsteinWeight N r.val (Complex.normSq u.val.2) := by
    rw [coherentVec_normSq, show Complex.normSq u.val.1 = 1-Complex.normSq u.val.2 by
      linarith [u.property]]
    unfold bernsteinWeight
    ring
  unfold wigner
  simp only [hk, Matrix.mul_diagonal, Matrix.trace, Matrix.diag_apply, projector,
    Complex.mul_conj, ← Complex.ofReal_mul, ← Complex.ofReal_sum, Complex.ofReal_re, hw]
  unfold coherentProfileValue poleEigenvalue
  simp only [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro l _
  rw [← bernstein_weighted_northCG, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro r _
  ring


/-- For a coherent input, the concrete Wigner symbol is zonal about its
Bloch axis, with the exact signed CG profile. -/
theorem wigner_coherent_zonal (N : ℕ) (signs : Weight N → Bool) (u : UnitSpinor) (p : Sphere) :
    wigner signs (coherentVec N u.val) p =
      coherentProfileValue N signs ((1-sphereDot (bloch u) p)/2) := by
  let v := liftSpinor p
  let z := unitSpinorMul (unitSpinorInv v) u
  have hv : spinorRotation v northPoint = p := spinorRotation_liftSpinor_north p
  have ha : (spinMatrix N v.val.1 v.val.2).conjTranspose *ᵥ coherentVec N u.val =
      coherentVec N z.val := by
    rw [← spinMatrix_inv_eq_conjTranspose, spinMatrix_coherentVec]
    rfl
  have hcov := wigner_spinorRotation signs v (coherentVec N u.val) northPoint
  rw [hv, ha, wigner_coherent_north] at hcov
  have hz : sphereDot (bloch z) northPoint = sphereDot (bloch u) p := by
    rw [← spinorRotation_bloch, ← spinorRotation_dot v, hv, spinorRotation_inv_right]
  have hz' : Complex.normSq z.val.1 - Complex.normSq z.val.2 = sphereDot (bloch u) p := by
    simpa [sphereDot, northPoint, bloch] using hz
  have he : Complex.normSq z.val.2 = (1-sphereDot (bloch u) p)/2 := by linarith [z.property]
  rw [← hcov, he]


/-- The squared normalization in the zonal profile is the beta-moment factor
times the spin dimension. -/
theorem cgScale_choose_sq (N : ℕ) (l : Weight N) :
    (cgScale N l.val * (N.choose l.val : ℝ))^2 =
      ((N+1 : ℕ) : ℝ) * (N.factorial : ℝ)^2 /
        (((N-l.val).factorial : ℝ) * ((N+l.val+1).factorial : ℝ)) := by
  have hl := Nat.le_of_lt_succ l.isLt
  have hc := congrArg (fun x : ℕ => (x : ℝ)) (Nat.choose_mul_factorial_mul_factorial hl)
  push_cast at hc
  unfold cgScale
  rw [mul_pow, Real.sq_sqrt (by positivity), ← hc]
  have hn (n : ℕ) : (n.factorial : ℝ) ≠ 0 := by positivity
  field_simp [hn]
  ring

theorem coherent_projector_overlap (N : ℕ) (u v : UnitSpinor) :
    Matrix.trace (projector (coherentVec N u.val) * projector (coherentVec N v.val)) =
      ((((1+sphereDot (bloch u) (bloch v))/2 : ℝ)^N : ℝ) : ℂ) := by
  rw [trace_projector_product]
  have he (z w : ℂ × ℂ) : (∑ r, starRingEnd ℂ (coherentVec N z r) *
      coherentVec N w r) = pairInner z w ^ N := coherentVec_inner N z w
  rw [he, he]
  have hc : pairInner v.val u.val = starRingEnd ℂ (pairInner u.val v.val) := by
    simp only [pairInner, map_add, map_mul, Complex.conj_conj]
    ring
  rw [hc, ← map_pow, Complex.mul_conj, map_pow]
  have hh : Complex.normSq (pairInner u.val v.val) = (1+sphereDot (bloch u) (bloch v))/2 := by
    rw [sphereDot_bloch]
    change Complex.normSq (pairInner u.val v.val) = (1+(2*Complex.normSq
      (pairInner u.val v.val)-1))/2
    ring
  rw [hh]

end F18
