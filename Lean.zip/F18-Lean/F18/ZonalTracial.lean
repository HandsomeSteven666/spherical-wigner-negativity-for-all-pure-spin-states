import F18.CoherentTracial
import F18.ShiftedLegendre
import F18.AzimuthPolynomial

open scoped Polynomial
namespace F18
open MeasureTheory Polynomial

/-- The precise zonal product formula still needed on the original area. -/
def ZonalLegendreProduct : Prop :=
  ∀ (l m : ℕ) (u v : Sphere),
    (∫ p, shiftedLegendreValue l ((1-sphereDot u p)/2) *
      shiftedLegendreValue m ((1-sphereDot v p)/2) ∂areaProbability) =
      if l = m then shiftedLegendreValue l ((1-sphereDot u v)/2) / (2*(l:ℝ)+1) else 0

private noncomputable def profileCoeff (N : ℕ) (signs : Weight N → Bool) (l : Weight N) : ℝ :=
    (rankSign signs l * ((2*l.val+1 : ℕ) : ℝ) / ((N+1 : ℕ) : ℝ)) *
      (cgScale N l.val * (N.choose l.val : ℝ))

private noncomputable def overlapTerm (N l : ℕ) (x : ℝ) : ℝ :=
  (2*(l:ℝ)+1) * ((N.factorial : ℝ)^2 /
         (((N-l).factorial : ℝ) * ((N+l+1).factorial : ℝ))) * shiftedLegendreValue l x

private theorem profileCoeff_square (N : ℕ) (signs : Weight N → Bool) (l : Weight N)
    (x : ℝ) :
    ((N+1 : ℕ) : ℝ) *
      (profileCoeff N signs l * profileCoeff N signs l *
        (shiftedLegendreValue l.val x / (2*(l.val:ℝ)+1))) = overlapTerm N l.val x := by
  have hs : (rankSign signs l)^2 = 1 := by
    unfold rankSign
    split <;> norm_num
  have hc := cgScale_choose_sq N l
  unfold profileCoeff overlapTerm
  push_cast
  rw [show (rankSign signs l * (2*(l.val:ℝ)+1) / ((N:ℝ)+1) *
      (cgScale N l.val * (N.choose l.val : ℝ))) *
      (rankSign signs l * (2*(l.val:ℝ)+1) / ((N:ℝ)+1) *
      (cgScale N l.val * (N.choose l.val : ℝ))) =
      (rankSign signs l)^2 * ((2*(l.val:ℝ)+1) / ((N:ℝ)+1))^2 *
        (cgScale N l.val * (N.choose l.val : ℝ))^2 by ring, hs, hc]
  push_cast
  have hN : (N:ℝ)+1 ≠ 0 := by positivity
  have hl : (2*(l.val:ℝ)+1) ≠ 0 := by positivity
  field_simp [hN, hl]
  ring

private theorem continuous_legendre_axis (l : ℕ) (u : Sphere) :
    Continuous (fun p : Sphere => shiftedLegendreValue l ((1-sphereDot u p)/2)) := by
  simp_rw [← eval_shiftedLegendrePoly]
  exact (shiftedLegendrePoly l).continuous.comp (by unfold sphereDot; fun_prop)

private theorem integrable_legendre_axis_product (l m : ℕ) (u v : Sphere) :
    Integrable (fun p : Sphere => shiftedLegendreValue l ((1-sphereDot u p)/2) *
      shiftedLegendreValue m ((1-sphereDot v p)/2)) areaProbability := by
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  letI : IsFiniteMeasure areaProbability := ⟨by simp [areaProbability_mass]⟩
  exact ((continuous_legendre_axis l u).mul (continuous_legendre_axis m v)).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

/-- The original traciality follows from the zonal product identity alone. -/
theorem spinWignerTracial_of_zonalLegendreProduct (hzonal : ZonalLegendreProduct) :
    SpinWignerTracial := by
  apply spinWignerTracial_of_coherent
  intro N signs u v
  rw [coherent_projector_overlap]
  apply congrArg Complex.ofReal
  simp_rw [wigner_coherent_zonal]
  let z := (1-sphereDot (bloch u) (bloch v))/2
  let a := profileCoeff N signs
  let L (l : Weight N) (w p : Sphere) := shiftedLegendreValue l.val ((1-sphereDot w p)/2)
  have hF (p : Sphere) (w : Sphere) : coherentProfileValue N signs ((1-sphereDot w p)/2) =
      ∑ l : Weight N, a l * L l w p := by
    unfold coherentProfileValue
    apply Finset.sum_congr rfl
    intro l _
    dsimp [a, L, profileCoeff]
    ring
  simp_rw [hF]
  unfold spinMeasure
  rw [integral_smul_measure]
  simp only [ENNReal.toReal_natCast, smul_eq_mul]
  simp_rw [Finset.sum_mul, Finset.mul_sum, fun i j p => show
    a i * L i (bloch u) p * (a j * L j (bloch v) p) =
    (a i * a j) * (L i (bloch u) p * L j (bloch v) p) by ring]
  have hi (i j : Weight N) : Integrable
      (fun p => (a i * a j) * (L i (bloch u) p * L j (bloch v) p)) areaProbability :=
    (integrable_legendre_axis_product i.val j.val (bloch u) (bloch v)).const_mul _
  rw [integral_finset_sum _ (fun i _ => integrable_finset_sum _ (fun j _ => hi i j))]
  simp_rw [integral_finset_sum _ (fun j _ => hi _ j), integral_const_mul]
  change _ * (∑ i : Weight N, ∑ j : Weight N, a i * a j *
    (∫ p, shiftedLegendreValue i.val ((1-sphereDot (bloch u) p)/2) *
      shiftedLegendreValue j.val ((1-sphereDot (bloch v) p)/2) ∂areaProbability)) = _
  have hz (i j : Weight N) := hzonal i.val j.val (bloch u) (bloch v)
  simp_rw [hz]
  have hd (i : Weight N) :
      (∑ j : Weight N, a i * a j * (if i.val = j.val then
        shiftedLegendreValue i.val z / (2*(i.val:ℝ)+1) else 0)) =
        a i * a i * (shiftedLegendreValue i.val z / (2*(i.val:ℝ)+1)) := by
    rw [Finset.sum_eq_single i]
    · simp
    · intro j _ hj
      simp [show i.val ≠ j.val from fun h => hj (Fin.ext h.symm)]
    · simp
  change _ * (∑ i : Weight N, ∑ j : Weight N, a i * a j *
    (if i.val = j.val then shiftedLegendreValue i.val z / (2*(i.val:ℝ)+1) else 0)) = _
  simp_rw [hd, Finset.mul_sum, show ∀ i : Weight N, ((N+1 : ℕ) : ℝ) *
    (a i * a i * (shiftedLegendreValue i.val z / (2*(i.val:ℝ)+1))) =
      overlapTerm N i.val z from fun i => profileCoeff_square N signs i z]
  rw [Fin.sum_univ_eq_sum_range (fun l => overlapTerm N l z) (N+1)]
  have he := congrArg (fun P : ℝ[X] => P.eval z) (shiftedLegendre_overlap_expansion N)
  simp only [eval_pow, eval_sub, eval_one, eval_X, eval_finset_sum,
    eval_mul, eval_C, eval_shiftedLegendrePoly, overlapTerm] at he
  unfold overlapTerm
  rw [← he, show 1-z = (1+sphereDot (bloch u) (bloch v))/2 by dsimp [z]; ring]


private theorem axis_pair_rotation (hrot : SphereRotationInvariant) (g : UnitSpinor)
    (R Q : ℝ[X]) (x y : Sphere) :
    (∫ p, axisPolynomial R (spinorRotation g x) p *
      axisPolynomial Q (spinorRotation g y) p ∂areaProbability) =
    ∫ p, axisPolynomial R x p * axisPolynomial Q y p ∂areaProbability := by
  let F (p : Sphere) := axisPolynomial R (spinorRotation g x) p *
    axisPolynomial Q (spinorRotation g y) p
  have hF : Continuous F := (continuous_axisPolynomial ..).mul (continuous_axisPolynomial ..)
  have hg := hrot g
  change (∫ p, F p ∂areaProbability) = _
  conv_lhs => rw [← hg.map_eq]
  rw [integral_map hg.measurable.aemeasurable hF.measurable.aestronglyMeasurable]
  simp only [F, axisPolynomial, spinorRotation_dot]

private theorem north_legendre_profile (hrot : SphereRotationInvariant) (m : ℕ) (y : Sphere) :
    ∀ R : ℝ[X], (∫ p, axisPolynomial R northPoint p *
      axisPolynomial (shiftedLegendrePoly m) y p ∂areaProbability) =
      axisPolynomial (shiftedLegendrePoly m) y northPoint *
        polynomialIntegral (R * shiftedLegendrePoly m) := by
  obtain ⟨P,hP,h₀,hpair⟩ := north_axisPolynomial_pairing (shiftedLegendrePoly m) y
  have hd := hP.trans (shiftedLegendre_degree_le m)
  have hlow (j : ℕ) (hj : j < m) :
      polynomialIntegral (P * shiftedLegendrePoly j) = 0 := by
    rw [mul_comm, ← hpair]
    let g := liftSpinor y
    have hg : spinorRotation g northPoint = y := spinorRotation_liftSpinor_north y
    let x := spinorRotation (unitSpinorInv g) northPoint
    have hx : spinorRotation g x = northPoint := spinorRotation_inv_right g northPoint
    rw [← hx, ← hg, axis_pair_rotation hrot g]
    -- Swap the axes so the higher mode is now the north-axis test.
    simp_rw [mul_comm (axisPolynomial (shiftedLegendrePoly j) x _)]
    obtain ⟨P',hP',_,hpair'⟩ := north_axisPolynomial_pairing (shiftedLegendrePoly j) x
    rw [hpair', mul_comm]
    exact shiftedLegendre_orthogonal_lower m P' (hP'.trans_lt ((shiftedLegendre_degree_le j).trans_lt hj))
  have htop : P = C (P.eval 0) * shiftedLegendrePoly m := by
    let c := (2*(m:ℝ)+1)*polynomialIntegral (P*shiftedLegendrePoly m)
    have he : P = C c * shiftedLegendrePoly m := by
      calc
        P = _ := polynomial_legendre_expansion hd
        _ = _ := by
          rw [Finset.sum_eq_single m]
          · intro j hj hjm
            have hj' := Finset.mem_range.mp hj
            rw [hlow j (by omega), mul_zero, map_zero, zero_mul]
          · simp
    have hc := congrArg (fun T : ℝ[X] => T.eval 0) he
    simp only [eval_mul, eval_C, shiftedLegendre_eval_zero, mul_one] at hc
    rw [hc]
    exact he
  intro R
  rw [hpair, htop, ← mul_left_comm]
  have hi : ∀ c : ℝ, polynomialIntegral (C c * (R * shiftedLegendrePoly m)) =
      c * polynomialIntegral (R * shiftedLegendrePoly m) := by
    intro c
    simp only [polynomialIntegral, eval_mul, eval_C, intervalIntegral.integral_const_mul]
  rw [hi, h₀]

/-- The exact zonal identity follows once invariance of the original area
under its concrete rotations is established. -/
theorem zonalLegendreProduct_of_rotationInvariant (hrot : SphereRotationInvariant) :
    ZonalLegendreProduct := by
  intro l m u v
  simp_rw [← eval_shiftedLegendrePoly]
  let L := shiftedLegendrePoly l
  let M := shiftedLegendrePoly m
  let g := liftSpinor u
  let y := spinorRotation (unitSpinorInv g) v
  have hu : spinorRotation g northPoint = u := spinorRotation_liftSpinor_north u
  have hv : spinorRotation g y = v := spinorRotation_inv_right g v
  have hz : sphereDot y northPoint = sphereDot u v := by
    rw [← spinorRotation_dot g y northPoint, hv, hu]
    unfold sphereDot
    ring
  change (∫ p, axisPolynomial L u p * axisPolynomial M v p ∂areaProbability) = _
  rw [← hu, ← hv, axis_pair_rotation hrot g, north_legendre_profile hrot m]
  rw [hu, hv]
  by_cases h : l = m
  · subst m
    change axisPolynomial L y northPoint * polynomialIntegral (L*L) = _
    rw [if_pos rfl, shiftedLegendre_norm_sq]
    unfold axisPolynomial
    rw [hz]
    ring
  · rw [if_neg h]
    change axisPolynomial M y northPoint * polynomialIntegral (L*M) = 0
    rw [shiftedLegendre_orthogonal h, mul_zero]

theorem spinWignerTracial_of_rotationInvariant (hrot : SphereRotationInvariant) :
    SpinWignerTracial :=
  spinWignerTracial_of_zonalLegendreProduct (zonalLegendreProduct_of_rotationInvariant hrot)


/-- The quantitative statement in the original definitions now reduces to
two independent obligations; traciality is no longer an independent input. -/
theorem originalQuantitative_of_rotationInvariant_orthogonal (hrot : SphereRotationInvariant)
    (horth : SpinOrthogonalRotation) : OriginalQuantitativeBounds :=
  originalQuantitative_of_invariance_tracial_orthogonal hrot
    (spinWignerTracial_of_rotationInvariant hrot) horth

end F18
