import Mathlib.Analysis.SpecialFunctions.PolarCoord
import Mathlib.Analysis.SpecialFunctions.Sqrt

namespace F18
open MeasureTheory Set
open scoped ENNReal

/-- Cylinder coordinates (horizontal radius, height) from radius and latitude
cosine. The open latitude interval omits only the polar axis. -/
noncomputable def radialLatitude (p : ℝ × ℝ) : ℝ × ℝ :=
  (p.1 * Real.sqrt (1-p.2^2), p.1*p.2)

def radialLatitudeDomain : Set (ℝ × ℝ) := Ioi (0:ℝ) ×ˢ Ioo (-1:ℝ) 1

private theorem radialLatitude_sqrt_pos (p : ℝ × ℝ) (hp : p ∈ radialLatitudeDomain) :
    0 < Real.sqrt (1-p.2^2) := by
  apply Real.sqrt_pos_of_pos
  have h₀ := hp.2.1
  have h₁ := hp.2.2
  nlinarith [mul_pos (show 0 < 1-p.2 by linarith) (show 0 < 1+p.2 by linarith)]

private theorem radialLatitude_radius_sq (p : ℝ × ℝ) (hp : p ∈ radialLatitudeDomain) :
    (radialLatitude p).1^2 + (radialLatitude p).2^2 = p.1^2 := by
  have hp' := Real.sqrt_pos.mp (radialLatitude_sqrt_pos p hp)
  unfold radialLatitude
  dsimp
  rw [mul_pow, Real.sq_sqrt hp'.le, mul_pow]
  ring

theorem radialLatitude_injOn : InjOn radialLatitude radialLatitudeDomain := by
  intro p hp q hq he
  have hr : p.1 = q.1 := by
    have h := radialLatitude_radius_sq p hp
    rw [he, radialLatitude_radius_sq q hq] at h
    have hp₀ : 0 < p.1 := hp.1
    have hq₀ : 0 < q.1 := hq.1
    exact ((sq_eq_sq_iff_eq_or_eq_neg.mp h).resolve_right (by linarith)).symm
  apply Prod.ext hr
  have hs := congrArg Prod.snd he
  change p.1*p.2 = q.1*q.2 at hs
  rw [← hr] at hs
  exact mul_left_cancel₀ (ne_of_gt hp.1) hs

theorem radialLatitude_image :
    radialLatitude '' radialLatitudeDomain = Ioi (0:ℝ) ×ˢ (univ : Set ℝ) := by
  ext x
  constructor
  · rintro ⟨p,hp,rfl⟩
    exact ⟨mul_pos hp.1 (radialLatitude_sqrt_pos p hp), trivial⟩
  · intro hx
    have hx₀ : 0 < x.1 := hx.1
    let r := Real.sqrt (x.1^2+x.2^2)
    have hr : 0 < r := Real.sqrt_pos_of_pos (by positivity)
    have hr₂ : r^2 = x.1^2+x.2^2 := Real.sq_sqrt (by positivity)
    have ht : (x.2/r)^2 < 1 := by
      rw [div_pow, div_lt_iff₀ (by positivity : 0 < r^2), one_mul, hr₂]
      nlinarith
    have hT : x.2/r ∈ Ioo (-1:ℝ) 1 := by
      constructor <;> nlinarith
    refine ⟨(r,x.2/r),⟨hr,hT⟩,Prod.ext ?_ ?_⟩
    · change r * Real.sqrt (1-(x.2/r)^2) = x.1
      have he : (r * Real.sqrt (1-(x.2/r)^2))^2 = x.1^2 := by
        rw [mul_pow, Real.sq_sqrt (sub_nonneg.mpr ht.le), mul_sub, mul_one, div_pow,
          mul_comm (r^2) (x.2^2/r^2), div_mul_cancel₀ _ (pow_ne_zero 2 hr.ne'), hr₂]
        ring
      have hn : 0 ≤ r * Real.sqrt (1-(x.2/r)^2) := by positivity
      exact (sq_eq_sq_iff_eq_or_eq_neg.mp he).resolve_right (by linarith)
    · change r*(x.2/r) = x.2
      field_simp [hr.ne']

noncomputable def radialLatitudeDerivative (p : ℝ × ℝ) : (ℝ × ℝ) →L[ℝ] (ℝ × ℝ) :=
  LinearMap.toContinuousLinearMap (Matrix.toLin (Basis.finTwoProd ℝ)
    (Basis.finTwoProd ℝ)
      !![Real.sqrt (1-p.2^2), p.1 * (-(p.2 / Real.sqrt (1-p.2^2))); p.2, p.1])

theorem hasFDerivAt_radialLatitude (p : ℝ × ℝ) (hp : p ∈ radialLatitudeDomain) :
    HasFDerivAt radialLatitude (radialLatitudeDerivative p) p := by
  have hs := Real.sqrt_pos.mp (radialLatitude_sqrt_pos p hp)
  have hd0 : HasDerivAt (fun t : ℝ => 1-t^2) (-(2*p.2)) p.2 := by
    convert (hasDerivAt_const p.2 (1:ℝ)).sub ((hasDerivAt_id p.2).pow 2) using 1
    simp
  have hd : HasDerivAt (fun t : ℝ => Real.sqrt (1-t^2))
      (-(p.2/Real.sqrt (1-p.2^2))) p.2 := by
    convert (Real.hasDerivAt_sqrt hs.ne').comp p.2 hd0 using 1
    field_simp [ne_of_gt (radialLatitude_sqrt_pos p hp)]
    ring
  unfold radialLatitudeDerivative
  rw [Matrix.toLin_finTwoProd_toContinuousLinearMap]
  have hf : HasFDerivAt Prod.fst (ContinuousLinearMap.fst ℝ ℝ ℝ) p := hasFDerivAt_fst
  have hg : HasFDerivAt Prod.snd (ContinuousLinearMap.snd ℝ ℝ ℝ) p := hasFDerivAt_snd
  convert HasFDerivAt.prodMk (𝕜 := ℝ)
    (hf.mul (hd.comp_hasFDerivAt p hg)) (hf.mul hg) using 2 <;>
  simp [smul_smul, add_comm, neg_smul]
  ext
  all_goals first
    | change -(p.1 * (p.2 / Real.sqrt (1-p.2^2))) * (0:ℝ) =
        -(p.1 * (p.2 / Real.sqrt (1-p.2^2)) * 0)
      ring
    | change -(p.1 * (p.2 / Real.sqrt (1-p.2^2))) * (1:ℝ) =
        -(p.1 * (p.2 / Real.sqrt (1-p.2^2)) * 1)
      ring

theorem det_radialLatitudeDerivative (p : ℝ × ℝ) (hp : p ∈ radialLatitudeDomain) :
    (radialLatitudeDerivative p).det = p.1 / Real.sqrt (1-p.2^2) := by
  have hs := radialLatitude_sqrt_pos p hp
  have he := Real.sq_sqrt (Real.sqrt_pos.mp hs).le
  unfold radialLatitudeDerivative
  simp only [LinearMap.det_toContinuousLinearMap, LinearMap.det_toLin, Matrix.det_fin_two_of]
  field_simp [hs.ne']
  linear_combination p.1 * he

/-- The cylindrical Jacobian and the latitude Jacobian combine to (R^2),
with exactly uniform latitude cosine. -/
theorem lintegral_radialLatitude (f : (ℝ × ℝ) → ℝ≥0∞) :
    (∫⁻ x in Ioi (0:ℝ) ×ˢ (univ : Set ℝ), ENNReal.ofReal x.1 * f x) =
      ∫⁻ p in radialLatitudeDomain, ENNReal.ofReal (p.1^2) * f (radialLatitude p) := by
  have hm : MeasurableSet radialLatitudeDomain := measurableSet_Ioi.prod measurableSet_Ioo
  rw [← radialLatitude_image, lintegral_image_eq_lintegral_abs_det_fderiv_mul volume hm
    (fun p hp => (hasFDerivAt_radialLatitude p hp).hasFDerivWithinAt) radialLatitude_injOn]
  apply setLIntegral_congr_fun hm
  filter_upwards with p hp
  have hs := radialLatitude_sqrt_pos p hp
  have hr : 0 < p.1 := hp.1
  rw [det_radialLatitudeDerivative p hp, abs_of_pos (div_pos hr hs), ← mul_assoc,
    ← ENNReal.ofReal_mul (by positivity)]
  congr 2
  change (p.1 / Real.sqrt (1-p.2^2)) * (p.1 * Real.sqrt (1-p.2^2)) = p.1^2
  field_simp [hs.ne']
  ring


/-- Ambient Lebesgue integration in azimuth, radial distance and latitude
cosine. Proved using planar polar coordinates and the cylindrical change. -/
theorem lintegral_spherical_coordinates (f : ((ℝ × ℝ) × ℝ) → ℝ≥0∞) (hf : Measurable f) :
    (∫⁻ x, f x) = ∫⁻ φ in Ioo (-Real.pi) Real.pi,
      ∫⁻ R in Ioi (0:ℝ), ∫⁻ t in Ioo (-1:ℝ) 1, ENNReal.ofReal (R^2) *
        f (((R*Real.sqrt (1-t^2))*Real.cos φ, (R*Real.sqrt (1-t^2))*Real.sin φ),R*t) := by
  let g (z φ r : ℝ) := ENNReal.ofReal r * f ((r*Real.cos φ,r*Real.sin φ),z)
  have hg (z : ℝ) : Measurable (fun p : ℝ × ℝ => g z p.2 p.1) := by
    unfold g
    fun_prop
  have hg' (φ : ℝ) : Measurable (fun p : ℝ × ℝ => g p.2 φ p.1) := by
    unfold g
    fun_prop
  have hφz : Measurable (Function.uncurry
      (fun (z φ : ℝ) => ∫⁻ r in Ioi (0:ℝ), g z φ r)) := by
    apply Measurable.lintegral_prod_right (f := fun (p : ℝ × ℝ) r => g p.1 p.2 r)
    unfold g Function.uncurry
    fun_prop
  rw [Measure.volume_eq_prod, lintegral_prod_symm _ hf.aemeasurable]
  have hpolar (z : ℝ) :
      (∫⁻ x : ℝ × ℝ, f (x,z)) = ∫⁻ φ in Ioo (-Real.pi) Real.pi, ∫⁻ r in Ioi (0:ℝ), g z φ r := by
    rw [← lintegral_comp_polarCoord_symm (fun x => f (x,z))]
    change (∫⁻ p in Ioi (0:ℝ) ×ˢ Ioo (-Real.pi) Real.pi, g z p.2 p.1) = _
    rw [Measure.volume_eq_prod, ← Measure.prod_restrict, lintegral_prod_symm _ (hg z).aemeasurable]
  simp_rw [hpolar]
  rw [lintegral_lintegral_swap hφz.aemeasurable]
  apply lintegral_congr
  intro φ
  have hc : (∫⁻ z : ℝ, ∫⁻ r in Ioi (0:ℝ), g z φ r) =
      ∫⁻ p in Ioi (0:ℝ) ×ˢ (univ : Set ℝ), g p.2 φ p.1 := by
    rw [Measure.volume_eq_prod, ← Measure.prod_restrict, Measure.restrict_univ,
      lintegral_prod_symm _ (hg' φ).aemeasurable]
  rw [hc]
  unfold g
  rw [lintegral_radialLatitude]
  unfold radialLatitudeDomain
  rw [Measure.volume_eq_prod, ← Measure.prod_restrict, lintegral_prod]
  · rfl
  · apply Measurable.aemeasurable
    unfold radialLatitude
    fun_prop

end F18
