import F18.QuantitativeCore
import F18.Integrability
import Mathlib.Tactic.FieldSimp

namespace F18
open MeasureTheory Set

/-- The elementary final bound of the paper for the concrete phase space.
The overlap and symmetries of the symbols are the remaining inputs. -/
theorem quantitative_of_concrete_overlap {N : ℕ} (signs : Weight N → Bool)
    (ψ φ : State N) (M : ℝ) (hM : 0 < M)
    (hu : ∀ p, |wigner signs ψ p| ≤ M) (hv : ∀ p, |wigner signs φ p| ≤ M)
    (hsq : ∫ p, wigner signs ψ p * wigner signs ψ p ∂spinMeasure N = 1)
    (hz : ∫ p, wigner signs ψ p * wigner signs φ p ∂spinMeasure N = 0)
    (hneg : negativeVolume signs φ = negativeVolume signs ψ)
    (hbound : ((N + 1 : ℕ) : ℝ) * M ^ 2 * boundFactor N ≤
      ∫ p, |wigner signs ψ p * wigner signs φ p| ∂spinMeasure N) :
    Real.sqrt ((N + 1 : ℕ) : ℝ) / 4 * boundFactor N ≤ negativeVolume signs ψ ∧
    ∃ p : Sphere, (∀ q : Sphere, wigner signs ψ p ≤ wigner signs ψ q) ∧
      boundFactor N / (4 * Real.sqrt ((N + 1 : ℕ) : ℝ)) ≤ -wigner signs ψ p := by
  let d : ℝ := ((N + 1 : ℕ) : ℝ)
  have hd : 0 < d := by positivity
  let E := boundFactor N
  have hE : 0 < E := Real.exp_pos _
  let u := wigner signs ψ
  let v := wigner signs φ
  have hV : d * M * E / 4 ≤ negativeVolume signs ψ :=
    volume_lower_bound_of_overlap (spinMeasure N) u v d M E hM hu hv
      (integrable_wigner_negative_part signs ψ) (integrable_wigner_negative_part signs φ)
      (integrable_wigner_product signs ψ φ) (integrable_wigner_product signs ψ φ).abs hz hneg hbound
  have hconst (c : ℝ) : ∫ _ : Sphere, c ∂spinMeasure N = d * c := by
    rw [integral_const, measureReal_def, spinMeasure_mass]
    rw [ENNReal.toReal_natCast]
    rfl
  have hb (p : Sphere) : u p * u p ≤ M ^ 2 := by
    have h := hu p
    change |u p| ≤ M at h
    calc
      _ = |u p| ^ 2 := by rw [sq_abs, pow_two]
      _ ≤ _ := pow_le_pow_left₀ (abs_nonneg _) h 2
  have h1 : 1 ≤ d * M ^ 2 := by
    have hh := integral_mono (integrable_wigner_product signs ψ ψ)
      (integrable_const (M ^ 2)) hb
    change (∫ p, wigner signs ψ p * wigner signs ψ p ∂spinMeasure N) ≤
      ∫ _ : Sphere, M ^ 2 ∂spinMeasure N at hh
    rwa [hsq, hconst] at hh
  have hsqrt : 1 ≤ Real.sqrt d * M := by
    have h := Real.sqrt_le_sqrt h1
    rwa [Real.sqrt_one, Real.sqrt_mul hd.le, Real.sqrt_sq hM.le] at h
  have hdM : Real.sqrt d ≤ d * M := by
    have h := mul_le_mul_of_nonneg_left hsqrt (Real.sqrt_nonneg d)
    calc
      _ = Real.sqrt d * 1 := by ring
      _ ≤ Real.sqrt d * (Real.sqrt d * M) := h
      _ = _ := by rw [← mul_assoc, Real.mul_self_sqrt hd.le]
  have hvold : Real.sqrt d / 4 * E ≤ negativeVolume signs ψ := by
    calc
      _ = Real.sqrt d * E / 4 := by ring
      _ ≤ d * M * E / 4 := div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_right hdM hE.le) (by norm_num)
      _ ≤ _ := hV
  refine ⟨hvold, ?_⟩
  have hnegp : ∃ p : Sphere, u p < 0 := by
    by_contra h
    have h0 : negativeVolume signs ψ = 0 := by
      unfold negativeVolume
      have heq : (fun p : Sphere => max (-wigner signs ψ p) 0) = fun _ => (0 : ℝ) := by
        funext p
        exact max_eq_right (neg_nonpos.mpr (le_of_not_gt fun hlt => h ⟨p, hlt⟩))
      simp [heq]
    have hp : 0 < Real.sqrt d / 4 * E := by positivity
    linarith
  obtain ⟨p, hp, hpn⟩ :=
    negative_minimum_of_continuous u (continuous_wigner signs ψ) hnegp
  refine ⟨p, hp, ?_⟩
  have hup : negativeVolume signs ψ ≤ d * (-u p) := by
    unfold negativeVolume
    rw [← hconst (-u p)]
    refine integral_mono (integrable_wigner_negative_part signs ψ) (integrable_const _) ?_
    intro q
    exact max_le (neg_le_neg (hp q)) (neg_nonneg.mpr hpn.le)
  have hh : Real.sqrt d / 4 * E ≤ d * (-u p) := hvold.trans hup
  have hid : Real.sqrt d / 4 * E = d * (E / (4 * Real.sqrt d)) := by
    have hpos : 0 < Real.sqrt d := Real.sqrt_pos.2 hd
    field_simp [hpos.ne']
    nlinarith [Real.sq_sqrt hd.le]
  rw [hid] at hh
  exact le_of_mul_le_mul_left hh hd

end F18
