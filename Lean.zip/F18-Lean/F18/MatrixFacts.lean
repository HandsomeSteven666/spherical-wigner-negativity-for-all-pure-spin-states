import F18.Definition
import Mathlib.Data.Matrix.ConjTranspose
import Mathlib.Tactic.Linarith

namespace F18
open scoped BigOperators

/-- The matrix in the definition is Hermitian, directly from its diagonal construction. -/
theorem kernel_hermitian (N : ℕ) (signs : Weight N → Bool) (p : Sphere) :
    (kernel N signs p).conjTranspose = kernel N signs p := by
  unfold kernel
  dsimp only
  have hdiag : (star (fun r => (poleEigenvalue N signs r : ℂ))) =
      (fun r => (poleEigenvalue N signs r : ℂ)) := by
    funext r
    exact Complex.conj_ofReal _
  simp [Matrix.conjTranspose_mul, Matrix.mul_assoc, hdiag]

theorem projector_hermitian {N : ℕ} (ψ : State N) :
    (projector ψ).conjTranspose = projector ψ := by
  ext r s
  simp [Matrix.conjTranspose_apply, projector, mul_comm]

/-- Taking the real part in the definition does not change the complex trace. -/
theorem complex_trace_eq_wigner {N : ℕ} (signs : Weight N → Bool)
    (ψ : State N) (p : Sphere) :
    Matrix.trace (projector ψ * kernel N signs p) = (wigner signs ψ p : ℂ) := by
  let z := Matrix.trace (projector ψ * kernel N signs p)
  have hz : star z = z := by
    change star (Matrix.trace (projector ψ * kernel N signs p)) = _
    rw [← Matrix.trace_conjTranspose, Matrix.conjTranspose_mul,
      kernel_hermitian, projector_hermitian, Matrix.trace_mul_comm]
  change z = (z.re : ℂ)
  apply Complex.ext
  · simp
  · have hh := congrArg Complex.im hz
    change -z.im = z.im at hh
    rw [Complex.ofReal_im]
    linarith

/-- Rank-one projector overlap factors as the two scalar overlaps. -/
theorem trace_projector_product {N : ℕ} (ψ φ : State N) :
    Matrix.trace (projector ψ * projector φ) =
      (∑ r, starRingEnd ℂ (ψ r) * φ r) * (∑ r, starRingEnd ℂ (φ r) * ψ r) := by
  classical
  simp only [Matrix.trace, Matrix.diag_apply, Matrix.mul_apply, projector,
    Finset.sum_mul, Finset.mul_sum]
  congr 1
  funext r
  congr 1
  funext s
  ac_rfl

/-- The vanishing trace needed in the manuscript follows from an orthogonal pair. -/
theorem trace_projector_product_zero {N : ℕ} (ψ φ : State N)
    (h : (∑ r, starRingEnd ℂ (ψ r) * φ r) = 0) :
    Matrix.trace (projector ψ * projector φ) = 0 := by
  rw [trace_projector_product, h, zero_mul]

end F18
