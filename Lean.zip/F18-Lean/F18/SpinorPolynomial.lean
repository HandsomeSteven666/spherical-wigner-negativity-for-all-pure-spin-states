import F18.Geometry
import F18.MatrixFacts
import Mathlib.Algebra.MvPolynomial.Degrees
import Mathlib.Algebra.MvPolynomial.CommRing

namespace F18

/-- Powers of a spinor and of its conjugate are paired using the four entries
of its rank-one matrix. The equal total powers are the phase-balance condition. -/
theorem pair_balanced_powers {R : Type*} [CommMonoid R]
    (a b c d : R) (A B C D : ℕ) (h : A + B = C + D) :
    a ^ A * b ^ B * c ^ C * d ^ D =
      (a * c) ^ min A C * (a * d) ^ (A - C) *
        (b * c) ^ (C - A) * (b * d) ^ min B D := by
  have eA : min A C + (A - C) = A := by omega
  have eB : (C - A) + min B D = B := by omega
  have eC : min A C + (C - A) = C := by omega
  have eD : (A - C) + min B D = D := by omega
  calc
    a ^ A * b ^ B * c ^ C * d ^ D =
        a ^ (min A C + (A - C)) * b ^ ((C - A) + min B D) *
          c ^ (min A C + (C - A)) * d ^ ((A - C) + min B D) := by rw [eA, eB, eC, eD]
    _ = _ := by simp only [mul_pow, pow_add]; ac_rfl

theorem pair_balanced_degree {A B C D : ℕ} (h : A + B = C + D) :
    min A C + (A - C) + (C - A) + min B D = A + B := by omega

theorem spinor_a_mul_conj_a (p : Sphere) :
    (spinor p).1 * starRingEnd ℂ (spinor p).1 =
      (((1 + p.val.2.2) / 2 : ℝ) : ℂ) := by
  rw [Complex.mul_conj, (spinor_norms p).1]

theorem spinor_b_mul_conj_b (p : Sphere) :
    (spinor p).2 * starRingEnd ℂ (spinor p).2 =
      (((1 - p.val.2.2) / 2 : ℝ) : ℂ) := by
  rw [Complex.mul_conj, (spinor_norms p).2]

theorem spinor_b_mul_conj_a (p : Sphere) :
    (spinor p).2 * starRingEnd ℂ (spinor p).1 =
      ((p.val.1 : ℂ) + (p.val.2.1 : ℂ) * Complex.I) / 2 := by
  have h := spinor_equator p
  apply (eq_div_iff (show (2 : ℂ) ≠ 0 by norm_num)).mpr
  calc
    _ = 2 * starRingEnd ℂ (spinor p).1 * (spinor p).2 := by ring
    _ = _ := h

theorem spinor_a_mul_conj_b (p : Sphere) :
    (spinor p).1 * starRingEnd ℂ (spinor p).2 =
      ((p.val.1 : ℂ) - (p.val.2.1 : ℂ) * Complex.I) / 2 := by
  have h := congrArg (starRingEnd ℂ) (spinor_b_mul_conj_a p)
  simp only [map_mul, Complex.conj_conj, map_div₀, map_add, Complex.conj_ofReal,
    Complex.conj_I, map_ofNat] at h
  convert h using 1 <;> ring


open MvPolynomial

private noncomputable def termCoeff (N s r u : ℕ) : ℂ :=
  (Nat.choose (N - s) u : ℂ) * (Nat.choose s (r-u) : ℂ) * (-1 : ℂ) ^ (s-(r-u))

/-- A form of the matrix summand with all signs in its scalar coefficient. -/
private theorem spinMatrix_expand (N : ℕ) (a b : ℂ) (r s : Weight N) :
    spinMatrix N a b r s =
      (Real.sqrt ((Nat.choose N s.val : ℝ) / (Nat.choose N r.val : ℝ)) : ℂ) *
      ∑ u ∈ Finset.range (N - s.val + 1),
        if u ≤ r.val ∧ r.val-u ≤ s.val then
          termCoeff N s.val r.val u * a ^ (N-s.val-u) * b ^ u *
            starRingEnd ℂ a ^ (r.val-u) * starRingEnd ℂ b ^ (s.val-(r.val-u))
        else 0 := by
  unfold spinMatrix
  congr 1
  apply Finset.sum_congr rfl
  intro u _
  split_ifs
  · rw [show -starRingEnd ℂ b = (-1 : ℂ) * starRingEnd ℂ b by ring, mul_pow]
    unfold termCoeff
    ring
  · rfl

/-- The four phase-invariant products are complex affine forms in Cartesian
coordinates. We keep their coefficients complex and take the real part only
when evaluating the Wigner symbol. -/
private noncomputable def bilinearPolys :
    MvPolynomial (Fin 3) ℂ × MvPolynomial (Fin 3) ℂ ×
      MvPolynomial (Fin 3) ℂ × MvPolynomial (Fin 3) ℂ :=
  (C (1/2) * (1 + X 2),
   C (1/2) * (X 0 - C Complex.I * X 1),
   C (1/2) * (X 0 + C Complex.I * X 1),
   C (1/2) * ((1 : MvPolynomial (Fin 3) ℂ) - X 2))

def sphereCoords (p : Sphere) : Fin 3 → ℂ :=
  fun k => if k = 0 then p.val.1 else if k = 1 then p.val.2.1 else p.val.2.2

private theorem eval_bilinearPolys (p : Sphere) :
    eval (sphereCoords p) bilinearPolys.1 =
      (spinor p).1 * starRingEnd ℂ (spinor p).1 ∧
    eval (sphereCoords p) bilinearPolys.2.1 =
      (spinor p).1 * starRingEnd ℂ (spinor p).2 ∧
    eval (sphereCoords p) bilinearPolys.2.2.1 =
      (spinor p).2 * starRingEnd ℂ (spinor p).1 ∧
    eval (sphereCoords p) bilinearPolys.2.2.2 =
      (spinor p).2 * starRingEnd ℂ (spinor p).2 := by
  rw [spinor_a_mul_conj_a, spinor_a_mul_conj_b, spinor_b_mul_conj_a, spinor_b_mul_conj_b]
  simp [bilinearPolys, sphereCoords, Complex.ofReal_div]
  constructor
  · ring
  constructor
  · ring
  constructor <;> ring

private theorem totalDegree_bilinearPolys :
    bilinearPolys.1.totalDegree ≤ 1 ∧ bilinearPolys.2.1.totalDegree ≤ 1 ∧
    bilinearPolys.2.2.1.totalDegree ≤ 1 ∧ bilinearPolys.2.2.2.totalDegree ≤ 1 := by
  have h (x y : MvPolynomial (Fin 3) ℂ) (hx : x.totalDegree ≤ 1) (hy : y.totalDegree ≤ 1) :
      (x + y).totalDegree ≤ 1 :=
    (totalDegree_add ..).trans (max_le hx hy)
  have hc (a : ℂ) (x : MvPolynomial (Fin 3) ℂ) (hx : x.totalDegree ≤ 1) :
      (C a * x).totalDegree ≤ 1 := by
    exact (totalDegree_mul ..).trans (by simpa using hx)
  have hn (x y : MvPolynomial (Fin 3) ℂ) (hx : x.totalDegree ≤ 1) (hy : y.totalDegree ≤ 1) :
      (x - y).totalDegree ≤ 1 := by
    rw [sub_eq_add_neg, ← neg_one_mul, ← C_1, ← C_neg]
    exact h _ _ hx (hc _ _ hy)
  unfold bilinearPolys
  exact ⟨hc _ _ (h _ _ (by simp) (by simp)),
    hc _ _ (hn _ _ (by simp) (hc _ _ (by simp))),
    hc _ _ (h _ _ (by simp) (hc _ _ (by simp))),
    hc _ _ (hn _ _ (by simp) (by simp))⟩

private noncomputable def pairedPoly (A B U V : ℕ) : MvPolynomial (Fin 3) ℂ :=
  bilinearPolys.1 ^ min A U * bilinearPolys.2.1 ^ (A-U) *
    bilinearPolys.2.2.1 ^ (U-A) * bilinearPolys.2.2.2 ^ min B V

private theorem eval_pairedPoly (p : Sphere) {A B U V : ℕ} (h : A+B=U+V) :
    eval (sphereCoords p) (pairedPoly A B U V) =
      (spinor p).1 ^ A * (spinor p).2 ^ B *
      starRingEnd ℂ (spinor p).1 ^ U * starRingEnd ℂ (spinor p).2 ^ V := by
  obtain ⟨h₁,h₂,h₃,h₄⟩ := eval_bilinearPolys p
  simp only [pairedPoly, map_mul, map_pow, h₁,h₂,h₃,h₄]
  exact (pair_balanced_powers _ _ _ _ _ _ _ _ h).symm

private theorem totalDegree_pairedPoly {A B U V : ℕ} (h : A+B=U+V) :
    (pairedPoly A B U V).totalDegree ≤ A+B := by
  obtain ⟨h₁,h₂,h₃,h₄⟩ := totalDegree_bilinearPolys
  have hpow (x : MvPolynomial (Fin 3) ℂ) (n : ℕ) (hx : x.totalDegree ≤ 1) :
      (x^n).totalDegree ≤ n := (totalDegree_pow ..).trans (by simpa using Nat.mul_le_mul_left n hx)
  unfold pairedPoly
  calc
    _ ≤ min A U + (A-U) + (U-A) + min B V :=
      (totalDegree_mul ..).trans (Nat.add_le_add
        ((totalDegree_mul ..).trans (Nat.add_le_add
          ((totalDegree_mul ..).trans (Nat.add_le_add (hpow _ _ h₁) (hpow _ _ h₂)))
          (hpow _ _ h₃))) (hpow _ _ h₄))
    _ = A+B := pair_balanced_degree h


private noncomputable def kernelSummandPoly {N : ℕ} (r t s : Weight N) (u v : ℕ) :
    MvPolynomial (Fin 3) ℂ :=
  if u ≤ r.val ∧ r.val-u ≤ s.val then
    if v ≤ t.val ∧ t.val-v ≤ s.val then
      C (termCoeff N s.val r.val u * starRingEnd ℂ (termCoeff N s.val t.val v)) *
        pairedPoly (N-s.val-u+(t.val-v)) (u+(s.val-(t.val-v)))
          (r.val-u+(N-s.val-v)) (s.val-(r.val-u)+v)
    else 0
  else 0

private theorem kernelSummand_degree {N : ℕ} (r t s : Weight N) (u v : ℕ)
    (hu : u ∈ Finset.range (N-s.val+1)) (hv : v ∈ Finset.range (N-s.val+1)) :
    (kernelSummandPoly r t s u v).totalDegree ≤ N := by
  have hs : s.val ≤ N := Nat.le_of_lt_succ s.isLt
  have hu' := Finset.mem_range.mp hu
  have hv' := Finset.mem_range.mp hv
  unfold kernelSummandPoly
  split_ifs with h₁ h₂
  · apply (totalDegree_mul ..).trans
    rw [totalDegree_C, zero_add]
    exact (totalDegree_pairedPoly (by omega)).trans (by omega)
  all_goals simp

private noncomputable def spinMonomial (N s r u : ℕ) (a b : ℂ) : ℂ :=
  if u ≤ r ∧ r-u ≤ s then
    termCoeff N s r u * a ^ (N-s-u) * b ^ u *
      starRingEnd ℂ a ^ (r-u) * starRingEnd ℂ b ^ (s-(r-u))
  else 0

private theorem eval_kernelSummand {N : ℕ} (r t s : Weight N) (u v : ℕ)
    (hu : u ∈ Finset.range (N-s.val+1)) (hv : v ∈ Finset.range (N-s.val+1))
    (p : Sphere) :
    eval (sphereCoords p) (kernelSummandPoly r t s u v) =
      spinMonomial N s.val r.val u (spinor p).1 (spinor p).2 *
        starRingEnd ℂ (spinMonomial N s.val t.val v (spinor p).1 (spinor p).2) := by
  have hu' := Finset.mem_range.mp hu
  have hv' := Finset.mem_range.mp hv
  unfold kernelSummandPoly spinMonomial
  split_ifs with h₁ h₂ h₂
  · rw [map_mul, eval_C, eval_pairedPoly p (by omega)]
    simp only [map_mul, map_pow, Complex.conj_conj, pow_add]
    ring
  all_goals simp

private noncomputable def normalization (N : ℕ) (r s : Weight N) : ℂ :=
  (Real.sqrt ((Nat.choose N s.val : ℝ) / (Nat.choose N r.val : ℝ)) : ℂ)

private noncomputable def kernelEntryPoly (N : ℕ) (signs : Weight N → Bool) (r t : Weight N) :
    MvPolynomial (Fin 3) ℂ :=
  ∑ s : Weight N,
    C (normalization N r s * (poleEigenvalue N signs s : ℂ) *
      starRingEnd ℂ (normalization N t s)) *
    ∑ u ∈ Finset.range (N-s.val+1), ∑ v ∈ Finset.range (N-s.val+1),
      kernelSummandPoly r t s u v

private theorem kernelEntry_degree (N : ℕ) (signs : Weight N → Bool) (r t : Weight N) :
    (kernelEntryPoly N signs r t).totalDegree ≤ N := by
  unfold kernelEntryPoly
  apply totalDegree_finsetSum_le
  intro s _
  apply (totalDegree_mul ..).trans
  rw [totalDegree_C, zero_add]
  apply totalDegree_finsetSum_le
  intro u hu
  apply totalDegree_finsetSum_le
  intro v hv
  exact kernelSummand_degree r t s u v hu hv

private theorem eval_kernelEntry (N : ℕ) (signs : Weight N → Bool) (r t : Weight N) (p : Sphere) :
    eval (sphereCoords p) (kernelEntryPoly N signs r t) = kernel N signs p r t := by
  unfold kernelEntryPoly kernel
  rw [Matrix.mul_apply]
  simp only [map_sum, map_mul, eval_C, Matrix.mul_diagonal, Matrix.conjTranspose_apply]
  apply Finset.sum_congr rfl
  intro s _
  have h : (∑ u ∈ Finset.range (N-s.val+1), ∑ v ∈ Finset.range (N-s.val+1),
      eval (sphereCoords p) (kernelSummandPoly r t s u v)) =
      (∑ u ∈ Finset.range (N-s.val+1), spinMonomial N s.val r.val u (spinor p).1 (spinor p).2) *
      starRingEnd ℂ (∑ v ∈ Finset.range (N-s.val+1), spinMonomial N s.val t.val v (spinor p).1 (spinor p).2) := by
    rw [map_sum, Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro u hu
    rw [Finset.mul_sum]
    exact Finset.sum_congr rfl fun v hv => eval_kernelSummand r t s u v hu hv p
  rw [h]
  simp only [spinMatrix_expand]
  unfold spinMonomial normalization
  change _ = _ * starRingEnd ℂ _
  simp only [map_mul]
  ring

/-- A complex polynomial representative of the concrete Wigner symbol.
It applies to every choice of rank signs and every state. -/
noncomputable def wignerPoly {N : ℕ} (signs : Weight N → Bool) (ψ : State N) :
    MvPolynomial (Fin 3) ℂ :=
  ∑ r : Weight N, ∑ t : Weight N, C (projector ψ r t) * kernelEntryPoly N signs t r

theorem totalDegree_wignerPoly {N : ℕ} (signs : Weight N → Bool) (ψ : State N) :
    (wignerPoly signs ψ).totalDegree ≤ N := by
  unfold wignerPoly
  apply totalDegree_finsetSum_le
  intro r _
  apply totalDegree_finsetSum_le
  intro t _
  exact (totalDegree_mul ..).trans (by simpa only [totalDegree_C, zero_add] using
    (kernelEntry_degree N signs t r))

theorem eval_wignerPoly {N : ℕ} (signs : Weight N → Bool) (ψ : State N) (p : Sphere) :
    eval (sphereCoords p) (wignerPoly signs ψ) = (wigner signs ψ p : ℂ) := by
  rw [← complex_trace_eq_wigner]
  simp only [wignerPoly, Matrix.trace, Matrix.diag, Matrix.mul_apply,
    map_sum, map_mul, eval_C, eval_kernelEntry]

theorem wigner_eq_re_eval_poly {N : ℕ} (signs : Weight N → Bool) (ψ : State N) (p : Sphere) :
    wigner signs ψ p = (eval (sphereCoords p) (wignerPoly signs ψ)).re := by
  simp only [wigner, wignerPoly, Matrix.trace, Matrix.diag, Matrix.mul_apply,
    map_sum, map_mul, eval_C, eval_kernelEntry]

end F18
