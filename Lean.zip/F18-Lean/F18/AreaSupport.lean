import F18.Integrability
import Mathlib.Analysis.SpecialFunctions.Complex.Arg

namespace F18
open MeasureTheory Set Filter

/-- The original integration rectangle, in polar cosine and azimuth. -/
def polarRectangle : Set (ℝ × ℝ) :=
  Icc (-1) 1 ×ˢ Icc 0 (2 * Real.pi)

theorem sphereChart_val {q : ℝ × ℝ} (hq : q.1 ^ 2 ≤ 1) :
    (sphereChart q).val =
      (Real.sqrt (1 - q.1 ^ 2) * Real.cos q.2,
       Real.sqrt (1 - q.1 ^ 2) * Real.sin q.2, q.1) := by
  simp [sphereChart, hq]

theorem continuousOn_sphereChart : ContinuousOn sphereChart polarRectangle := by
  apply Topology.IsInducing.subtypeVal.continuousOn_iff.mpr
  refine (show Continuous (fun q : ℝ × ℝ =>
    (Real.sqrt (1 - q.1 ^ 2) * Real.cos q.2,
     Real.sqrt (1 - q.1 ^ 2) * Real.sin q.2, q.1)) from by fun_prop).continuousOn.congr ?_
  intro q hq
  exact sphereChart_val ((sq_le_one_iff_abs_le_one _).mpr (abs_le.mpr hq.1))

/-- Even at the poles and along the azimuth seam, every point is hit by the
closed integration rectangle. -/
theorem sphereChart_surjOn : SurjOn sphereChart polarRectangle univ := by
  rintro ⟨⟨x, y, z⟩, hp⟩ -
  change x ^ 2 + y ^ 2 + z ^ 2 = 1 at hp
  let c : ℂ := (x : ℂ) + (y : ℂ) * Complex.I
  have hre : c.re = x := by simp [c]
  have him : c.im = y := by simp [c]
  let a := Complex.arg c
  let b := if 0 ≤ a then a else a + 2 * Real.pi
  have hb : b ∈ Icc 0 (2 * Real.pi) := by
    have h₁ : -Real.pi < a := Complex.neg_pi_lt_arg c
    have h₂ : a ≤ Real.pi := Complex.arg_le_pi c
    have hπ := Real.pi_pos
    by_cases h : 0 ≤ a
    · exact ⟨by simp [b, h], by simp [b, h]; linarith⟩
    · exact ⟨by simp [b, h]; linarith, by simp [b, h]; linarith⟩
  have hz : z ∈ Icc (-1 : ℝ) 1 :=
    ⟨by nlinarith [sq_nonneg x, sq_nonneg y], by nlinarith [sq_nonneg x, sq_nonneg y]⟩
  have hnorm : Real.sqrt (1 - z ^ 2) = ‖c‖ := by
    have heq : ‖c‖ ^ 2 = 1 - z ^ 2 := by
      rw [Complex.sq_norm, Complex.normSq_apply, hre, him]
      nlinarith [hp]
    rw [← heq, Real.sqrt_sq (norm_nonneg _)]
  have hcos : Real.cos b = Real.cos a := by
    by_cases h : 0 ≤ a <;> simp [b, h, Real.cos_add_two_pi]
  have hsin : Real.sin b = Real.sin a := by
    by_cases h : 0 ≤ a <;> simp [b, h, Real.sin_add_two_pi]
  refine ⟨(z,b), ⟨hz,hb⟩, Subtype.ext ?_⟩
  rw [sphereChart_val (q := (z,b)) (by nlinarith [sq_nonneg x, sq_nonneg y]),
    hnorm, hcos, hsin, Complex.norm_mul_cos_arg, Complex.norm_mul_sin_arg, hre, him]

theorem areaProbability_pos_of_open {U : Set Sphere} (hU : IsOpen U) (hne : U.Nonempty) :
    0 < areaProbability U := by
  obtain ⟨p, hp⟩ := hne
  obtain ⟨q, hq, heq⟩ := sphereChart_surjOn (mem_univ p)
  have hV : sphereChart ⁻¹' U ∈ nhdsWithin q polarRectangle :=
    (continuousOn_sphereChart q hq).preimage_mem_nhdsWithin (hU.mem_nhds (heq ▸ hp))
  obtain ⟨V, hV, hsub⟩ := mem_nhdsWithin_iff_exists_mem_nhds_inter.mp hV
  obtain ⟨W, hWV, hW, hqW⟩ := mem_nhds_iff.mp hV
  let R : Set (ℝ × ℝ) := Ioo (-1) 1 ×ˢ Ioo 0 (2 * Real.pi)
  have hR : closure R = polarRectangle := by
    unfold R polarRectangle
    rw [closure_prod_eq, closure_Ioo (by norm_num : (-1 : ℝ) ≠ 1),
      closure_Ioo (by positivity : 0 < 2 * Real.pi).ne]
  have hWR : (W ∩ R).Nonempty := mem_closure_iff.mp (hR.symm ▸ hq) W hW hqW
  have hRopen : IsOpen R := isOpen_Ioo.prod isOpen_Ioo
  have hWRsub : W ∩ R ⊆ sphereChart ⁻¹' U ∩ polarRectangle := by
    intro r hr
    have hr' : r ∈ polarRectangle := ⟨Ioo_subset_Icc_self hr.2.1, Ioo_subset_Icc_self hr.2.2⟩
    exact ⟨hsub ⟨hWV hr.1, hr'⟩, hr'⟩
  have hvol := (hW.inter hRopen).measure_pos (volume : Measure (ℝ × ℝ)) hWR
  unfold areaProbability
  rw [Measure.smul_apply, Measure.map_apply measurable_sphereChart hU.measurableSet,
    Measure.restrict_apply (measurable_sphereChart hU.measurableSet), smul_eq_mul]
  apply ENNReal.mul_pos_iff.mpr
  exact And.intro (ENNReal.ofReal_pos.mpr (by positivity)) (lt_of_lt_of_le hvol (measure_mono hWRsub))

theorem spinMeasure_pos_of_open (N : ℕ) {U : Set Sphere} (hU : IsOpen U)
    (hne : U.Nonempty) : 0 < spinMeasure N U := by
  rw [spinMeasure, Measure.smul_apply, smul_eq_mul]
  apply ENNReal.mul_pos_iff.mpr
  exact And.intro (by positivity) (areaProbability_pos_of_open hU hne)

end F18

instance F18.spinMeasure_isOpenPos (N : ℕ) :
    (F18.spinMeasure N).IsOpenPosMeasure where
  open_pos _ hU hne := (F18.spinMeasure_pos_of_open N hU hne).ne'
