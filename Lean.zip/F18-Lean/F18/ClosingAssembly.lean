import F18.OperatorIntegral
import F18.SphereLog
import F18.Jensen

namespace F18
open MeasureTheory
open scoped Matrix

/-- These named properties are proof obligations used by the assembly,
not axioms or extra premises in the original statement. -/
def SphereRotationInvariant : Prop :=
  ∀ u : UnitSpinor, MeasurePreserving (spinorRotation u) areaProbability areaProbability

def SpinWignerTracial : Prop :=
  ∀ (N : ℕ) (signs : Weight N → Bool) (ψ φ : State N),
    ((∫ p, wigner signs ψ p * wigner signs φ p ∂spinMeasure N : ℝ) : ℂ) =
      Matrix.trace (projector ψ * projector φ)

def SpinOrthogonalRotation : Prop :=
  ∀ (N : ℕ), 0 < N → ∀ ψ : State N, squaredNorm ψ = 1 → ∃ u : UnitSpinor,
    (∑ r, starRingEnd ℂ (ψ r) * ((spinMatrix N u.val.1 u.val.2)ᴴ *ᵥ ψ) r) = 0

theorem spinMeasure_rotationInvariant (h : SphereRotationInvariant) (N : ℕ) (u : UnitSpinor) :
    MeasurePreserving (spinorRotation u) (spinMeasure N) (spinMeasure N) := by
  refine ⟨(h u).measurable, ?_⟩
  rw [spinMeasure, Measure.map_smul, (h u).map_eq]

theorem spinorRotation_liftSpinor_north (p : Sphere) :
    spinorRotation (liftSpinor p) northPoint = p := by
  have h : bloch unitSpinorOne = northPoint := by
    apply Subtype.ext
    norm_num [bloch, unitSpinorOne, northPoint]
  rw [← h, spinorRotation_bloch_one, bloch_liftSpinor]

private theorem log_at_wigner_max (hrot : SphereRotationInvariant)
    {N : ℕ} (hN : 0 < N) (signs : Weight N → Bool) (ψ : State N) (p : Sphere)
    (h₀ : wigner signs ψ p ≠ 0) (hM : ∀ q, |wigner signs ψ q| ≤ |wigner signs ψ p|) :
    (∀ᵐ q ∂areaProbability, wigner signs ψ q ≠ 0) ∧
    Integrable (fun q => Real.log |wigner signs ψ q|) areaProbability ∧
    Real.log |wigner signs ψ p| - (1+Real.exp (-1))*(N : ℝ) ≤
      ∫ q, Real.log |wigner signs ψ q| ∂areaProbability := by
  let u := liftSpinor p
  have hu : spinorRotation u northPoint = p := spinorRotation_liftSpinor_north p
  have he := log_mean_area_transport hN signs ψ
    ((spinMatrix N u.val.1 u.val.2)ᴴ *ᵥ ψ) (spinorRotation u) (hrot u)
    (wigner_spinorRotation signs u ψ) (hu.symm ▸ h₀) _ hM
  simpa only [hu, mul_comm (N : ℝ)] using he

set_option maxHeartbeats 700000 in
theorem originalQuantitative_of_invariance_tracial_orthogonal
    (hrot : SphereRotationInvariant) (htrace : SpinWignerTracial)
    (horth : SpinOrthogonalRotation) : OriginalQuantitativeBounds := by
  intro N hN signs ψ hψ
  let w := wigner signs ψ
  obtain ⟨p, hp⟩ := exists_max_abs_wigner signs ψ
  let M := |w p|
  have hM : 0 < M := by
    by_contra hp0
    have hw : w = fun _ => 0 := by
      funext q
      exact abs_eq_zero.mp (le_antisymm ((hp q).trans (le_of_not_gt hp0)) (abs_nonneg _))
    have hh := integral_wigner_eq_squaredNorm signs ψ (spinMeasure_rotationInvariant hrot N)
    change (∫ q, w q ∂spinMeasure N) = _ at hh
    rw [hw, hψ, integral_zero] at hh
    exact zero_ne_one hh
  obtain ⟨u, hU⟩ := horth N hN ψ hψ
  let φ := (spinMatrix N u.val.1 u.val.2)ᴴ *ᵥ ψ
  have hcov (q : Sphere) : wigner signs φ q = w (spinorRotation u q) :=
    wigner_spinorRotation signs u ψ q
  let q := spinorRotation (unitSpinorInv u) p
  have hq : |wigner signs φ q| = M := by
    rw [hcov, spinorRotation_inv_right]
  have hv (r : Sphere) : |wigner signs φ r| ≤ M := hcov r ▸ hp (spinorRotation u r)
  have hnψ : w p ≠ 0 := abs_pos.mp hM
  have hnφ : wigner signs φ q ≠ 0 := abs_pos.mp (hq.symm ▸ hM)
  obtain ⟨heψ, hiψ, hlψ⟩ := log_at_wigner_max hrot hN signs ψ p hnψ hp
  obtain ⟨heφ, hiφ, hlφ⟩ := log_at_wigner_max hrot hN signs φ q hnφ (fun r => hq.symm ▸ hv r)
  rw [hq] at hlφ
  have hJ := overlap_of_log_means signs ψ φ M hM heψ heφ hiψ hiφ hlψ hlφ
  have hneg : negativeVolume signs φ = negativeVolume signs ψ := by
    unfold negativeVolume
    simp_rw [hcov]
    have ht := spinMeasure_rotationInvariant hrot N u
    have hfun : Measurable (fun r : Sphere => max (-w r) 0) :=
      ((continuous_wigner signs ψ).neg.max continuous_const).measurable
    rw [← integral_map ht.measurable.aemeasurable hfun.aestronglyMeasurable, ht.map_eq]
  have hzero : (∫ r, wigner signs ψ r * wigner signs φ r ∂spinMeasure N) = 0 := by
    apply Complex.ofReal_injective
    rw [htrace N signs ψ φ, trace_projector_product_zero ψ φ hU, Complex.ofReal_zero]
  have hself : (∫ r, wigner signs ψ r * wigner signs ψ r ∂spinMeasure N) = 1 := by
    apply Complex.ofReal_injective
    rw [htrace N signs ψ ψ, trace_projector_product]
    have he : (∑ r, starRingEnd ℂ (ψ r) * ψ r) = (squaredNorm ψ : ℂ) := by
      unfold squaredNorm
      rw [Complex.ofReal_sum]
      apply Finset.sum_congr rfl
      intro r _
      rw [mul_comm, Complex.mul_conj]
    rw [he, hψ, Complex.ofReal_one, mul_one]
  exact quantitative_of_concrete_overlap signs ψ φ M hM hp hv hself hzero hneg hJ

theorem minimumNegativity_of_originalQuantitative (h : OriginalQuantitativeBounds) :
    OriginalMinimumNegativity := by
  intro N hN signs ψ hψ
  obtain ⟨_, p, hp, hneg⟩ := h N hN signs ψ hψ
  have hh : 0 < boundFactor N / (4 * Real.sqrt ((N+1 : ℕ) : ℝ)) := by
    unfold boundFactor
    positivity
  exact ⟨p, hp, neg_pos.mp (hh.trans_le hneg)⟩

end F18
