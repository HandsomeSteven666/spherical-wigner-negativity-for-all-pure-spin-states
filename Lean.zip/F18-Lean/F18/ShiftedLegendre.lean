import F18.CoherentProfile
import Mathlib.Algebra.Polynomial.Derivative
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus

namespace F18
open Polynomial
open scoped Polynomial

noncomputable def shiftedLegendrePoly (l : ℕ) : ℝ[X] :=
  ∑ q ∈ Finset.range (l+1), C ((-1 : ℝ)^q * (l.choose q : ℝ)^2) *
    X^q * (1-X)^(l-q)

theorem eval_shiftedLegendrePoly (l : ℕ) (p : ℝ) :
    (shiftedLegendrePoly l).eval p = shiftedLegendreValue l p := by
  simp only [shiftedLegendrePoly, shiftedLegendreValue, eval_finset_sum, eval_mul, eval_C,
    eval_pow, eval_X, eval_sub, eval_one]

private theorem iterate_derivative_one_sub_X (n k : ℕ) :
    derivative^[k] (((1 : ℝ[X])-X)^n) =
      C ((-1 : ℝ)^k * (n.descFactorial k : ℝ)) * (1-X)^(n-k) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Function.iterate_succ_apply', ih, derivative_C_mul, derivative_pow]
    have h : derivative ((1 : ℝ[X])-X) = -1 := by simp
    rw [h, Nat.descFactorial_succ, Nat.cast_mul, pow_succ]
    simp only [Nat.sub_succ, Nat.sub_zero, ← C_eq_natCast, map_mul, map_neg, map_one]
    ring

/-- Rodrigues formula for the precise shifted Legendre profile, with the
factorial left on the polynomial side to avoid division. -/
theorem shiftedLegendre_rodrigues (l : ℕ) :
    derivative^[l] ((X : ℝ[X])^l * (1-X)^l) =
      C (l.factorial : ℝ) * shiftedLegendrePoly l := by
  rw [iterate_derivative_mul, shiftedLegendrePoly, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro q hq
  have h := Nat.le_of_lt_succ (Finset.mem_range.mp hq)
  rw [iterate_derivative_X_pow_eq_C_mul, iterate_derivative_one_sub_X,
    show l-(l-q) = q by omega, nsmul_eq_mul]
  have hd : l.choose q * l.descFactorial (l-q) * l.descFactorial q =
      l.factorial * l.choose q ^ 2 := by
    rw [Nat.descFactorial_eq_factorial_mul_choose, Nat.descFactorial_eq_factorial_mul_choose,
      Nat.choose_symm h, ← Nat.choose_mul_factorial_mul_factorial h]
    ring
  have he := congrArg (fun x : ℕ => (x : ℝ[X])) hd
  push_cast at he
  simp only [map_mul, map_pow, map_neg, map_one, C_eq_natCast]
  linear_combination he * ((-1 : ℝ[X])^q * X^q * (1-X)^(l-q))


noncomputable def legendreBase (l : ℕ) : ℝ[X] := X^l * (1-X)^l

private theorem legendreBase_endpoints (l k : ℕ) (hk : k < l) :
    (derivative^[k] (legendreBase l)).eval 0 = 0 ∧
      (derivative^[k] (legendreBase l)).eval 1 = 0 := by
  rw [legendreBase, iterate_derivative_mul]
  simp only [eval_finset_sum]
  constructor <;> apply Finset.sum_eq_zero <;> intro j hj
  all_goals
    have hj' := Finset.mem_range.mp hj
    rw [iterate_derivative_X_pow_eq_C_mul, iterate_derivative_one_sub_X, nsmul_eq_mul]
    simp only [eval_mul, eval_natCast, eval_C, eval_pow, eval_X, eval_sub, eval_one]
  · rw [zero_pow (by omega : l-(k-j) ≠ 0)]
    ring
  · rw [sub_self, zero_pow (by omega : l-j ≠ 0)]
    ring

noncomputable def polynomialIntegral (P : ℝ[X]) : ℝ :=
  ∫ x in (0 : ℝ)..1, P.eval x

private theorem polynomialIntegral_const_mul (c : ℝ) (P : ℝ[X]) :
    polynomialIntegral (C c * P) = c * polynomialIntegral P := by
  unfold polynomialIntegral
  simp only [eval_mul, eval_C, intervalIntegral.integral_const_mul]

private theorem polynomialIntegral_primitive (P : ℝ[X]) :
    polynomialIntegral (derivative P) = P.eval 1 - P.eval 0 := by
  unfold polynomialIntegral
  exact intervalIntegral.integral_eq_sub_of_hasDerivAt
    (f := fun x => P.eval x) (f' := fun x => (derivative P).eval x)
    (fun x _ => P.hasDerivAt x) ((derivative P).continuous.intervalIntegrable 0 1)

private theorem polynomialIntegral_add (P Q : ℝ[X]) :
    polynomialIntegral (P+Q) = polynomialIntegral P + polynomialIntegral Q := by
  unfold polynomialIntegral
  simp only [eval_add]
  exact intervalIntegral.integral_add (P.continuous.intervalIntegrable _ _)
    (Q.continuous.intervalIntegrable _ _)

private theorem polynomialIntegral_parts (P Q : ℝ[X]) (h₀ : Q.eval 0 = 0) (h₁ : Q.eval 1 = 0) :
    polynomialIntegral (P * derivative Q) = -polynomialIntegral (derivative P * Q) := by
  have h := polynomialIntegral_primitive (P*Q)
  rw [derivative_mul, polynomialIntegral_add] at h
  simp only [eval_mul, h₀, h₁, mul_zero, sub_self] at h
  linarith

/-- Repeated integration by parts, justified by exact endpoint vanishing. -/
theorem polynomialIntegral_legendreBase_parts (l k : ℕ) (hk : k ≤ l) (P : ℝ[X]) :
    polynomialIntegral (P * derivative^[k] (legendreBase l)) =
      (-1 : ℝ)^k * polynomialIntegral (derivative^[k] P * legendreBase l) := by
  induction k generalizing P with
  | zero => simp
  | succ k ih =>
    have hb := legendreBase_endpoints l k (by omega)
    conv_lhs => rw [Function.iterate_succ_apply']
    rw [polynomialIntegral_parts _ _ hb.1 hb.2, ih (by omega), Function.iterate_succ_apply]
    rw [pow_succ]
    ring

/-- Orthogonality against every strictly lower-degree polynomial. -/
theorem shiftedLegendre_orthogonal_lower (l : ℕ) (P : ℝ[X]) (hP : P.natDegree < l) :
    polynomialIntegral (P * shiftedLegendrePoly l) = 0 := by
  have h := polynomialIntegral_legendreBase_parts l l le_rfl P
  rw [iterate_derivative_eq_zero hP, zero_mul] at h
  have hbase : derivative^[l] (legendreBase l) =
      C (l.factorial : ℝ) * shiftedLegendrePoly l := shiftedLegendre_rodrigues l
  rw [hbase, ← mul_left_comm, polynomialIntegral_const_mul] at h
  have hz : polynomialIntegral (0 : ℝ[X]) = 0 := by simp [polynomialIntegral]
  rw [hz, mul_zero] at h
  exact (mul_eq_zero.mp h).resolve_left (by positivity)


theorem shiftedLegendre_degree_le (l : ℕ) : (shiftedLegendrePoly l).natDegree ≤ l := by
  unfold shiftedLegendrePoly
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro q hq
  have h := Nat.le_of_lt_succ (Finset.mem_range.mp hq)
  have hd : ((1 : ℝ[X])-X).natDegree ≤ 1 :=
    (natDegree_sub_le ..).trans (by simp)
  have hp : (((1 : ℝ[X])-X)^(l-q)).natDegree ≤ l-q :=
    natDegree_pow_le.trans (by simpa using Nat.mul_le_mul_left (l-q) hd)
  calc
    _ ≤ q + (l-q) := natDegree_mul_le.trans (Nat.add_le_add
      (natDegree_C_mul_le .. |>.trans (by simp)) hp)
    _ = l := Nat.add_sub_of_le h

theorem shiftedLegendre_orthogonal {l m : ℕ} (h : l ≠ m) :
    polynomialIntegral (shiftedLegendrePoly l * shiftedLegendrePoly m) = 0 := by
  rcases lt_or_gt_of_ne h with hl | hm
  · exact shiftedLegendre_orthogonal_lower _ _ ((shiftedLegendre_degree_le _).trans_lt hl)
  · rw [mul_comm]
    exact shiftedLegendre_orthogonal_lower _ _ ((shiftedLegendre_degree_le _).trans_lt hm)

theorem shiftedLegendre_eval_zero (l : ℕ) : (shiftedLegendrePoly l).eval 0 = 1 := by
  rw [eval_shiftedLegendrePoly, shiftedLegendreValue, Finset.sum_eq_single 0]
  · simp
  · intro q _ hq
    simp [zero_pow hq]
  · simp


private theorem derivative_one_sub_X_pow (n : ℕ) :
    derivative (((1 : ℝ[X])-X)^(n+1)) =
      C (-(n+1 : ℝ)) * (1-X)^n := by
  rw [derivative_pow]
  simp only [derivative_sub, derivative_one, derivative_X, zero_sub,
    Nat.add_sub_cancel, ← C_eq_natCast, Nat.cast_add, Nat.cast_one, map_neg]
  ring

/-- The integer beta integral on [0,1], with exact factorial normalization. -/
theorem polynomialIntegral_beta (a b : ℕ) :
    polynomialIntegral (X^a * (1-X)^b) =
      (a.factorial : ℝ) * (b.factorial : ℝ) / (((a+b+1).factorial : ℕ) : ℝ) := by
  induction a generalizing b with
  | zero =>
    have hp := polynomialIntegral_primitive (((1 : ℝ[X])-X)^(b+1))
    rw [derivative_one_sub_X_pow, polynomialIntegral_const_mul] at hp
    have he : -((b : ℝ)+1) * polynomialIntegral ((1-X)^b) = -1 := by
      simpa using hp
    simp only [pow_zero, one_mul, Nat.factorial_zero, Nat.cast_one, Nat.zero_add,
      Nat.factorial_succ, Nat.cast_mul, Nat.cast_add]
    have h₁ : ((b : ℝ)+1) ≠ 0 := by positivity
    have h₂ : (b.factorial : ℝ) ≠ 0 := by positivity
    field_simp [h₁,h₂]
    linear_combination (-he) * (b.factorial : ℝ)
  | succ a ih =>
    have hp := polynomialIntegral_primitive ((X : ℝ[X])^(a+1) * (1-X)^(b+1))
    rw [derivative_mul, derivative_one_sub_X_pow, derivative_X_pow] at hp
    simp only [Nat.add_sub_cancel, ← C_eq_natCast, Nat.cast_add, Nat.cast_one] at hp
    have hpoly : C ((a:ℝ)+1) * X^a * (1-X)^(b+1) +
        X^(a+1) * (C (-((b:ℝ)+1)) * (1-X)^b) =
        C ((a:ℝ)+1) * (X^a*(1-X)^(b+1)) +
        C (-((b:ℝ)+1)) * (X^(a+1)*(1-X)^b) := by ring
    rw [hpoly, polynomialIntegral_add, polynomialIntegral_const_mul, polynomialIntegral_const_mul] at hp
    have he : ((a : ℝ)+1) * polynomialIntegral (X^a*(1-X)^(b+1)) -
        ((b : ℝ)+1) * polynomialIntegral (X^(a+1)*(1-X)^b) = 0 := by
      simp [eval_mul, eval_sub, eval_one] at hp
      linarith
    rw [ih (b+1)] at he
    have hd : (a+1)+b+1 = a+(b+1)+1 := by omega
    rw [hd, Nat.factorial_succ a]
    rw [Nat.factorial_succ b] at he
    push_cast at he ⊢
    have h₁ : ((b : ℝ)+1) ≠ 0 := by positivity
    have h₂ : ((a+(b+1)+1).factorial : ℝ) ≠ 0 := by positivity
    apply (mul_left_cancel₀ h₁)
    calc
      _ = ((a : ℝ)+1) * (((a.factorial : ℝ) * ((b+1 : ℝ) * b.factorial)) /
        ((a+(b+1)+1).factorial : ℝ)) := by linarith
      _ = _ := by field_simp [h₁,h₂]; ring

/-- Projection of the coherent overlap (1-p)^N onto the lth Legendre mode. -/
theorem shiftedLegendre_beta_moment (N l : ℕ) (hl : l ≤ N) :
    polynomialIntegral ((1-X)^N * shiftedLegendrePoly l) =
      (N.factorial : ℝ)^2 / (((N-l).factorial : ℝ) * ((N+l+1).factorial : ℝ)) := by
  have h := polynomialIntegral_legendreBase_parts l l le_rfl (((1 : ℝ[X])-X)^N)
  change polynomialIntegral (((1 : ℝ[X])-X)^N * derivative^[l] (legendreBase l)) = _ at h
  rw [show derivative^[l] (legendreBase l) = _ from shiftedLegendre_rodrigues l,
    ← mul_left_comm, polynomialIntegral_const_mul, iterate_derivative_one_sub_X,
    mul_assoc, polynomialIntegral_const_mul] at h
  unfold legendreBase at h
  rw [show ((1 : ℝ[X])-X)^(N-l) * (X^l * (1-X)^l) = X^l * (1-X)^N by
    rw [← mul_left_comm, ← pow_add, Nat.sub_add_cancel hl]] at h
  rw [polynomialIntegral_beta] at h
  have hs : (-1 : ℝ)^l * (-1)^l = 1 := by rw [← mul_pow]; norm_num
  have hclean : (l.factorial : ℝ) * polynomialIntegral ((1-X)^N * shiftedLegendrePoly l) =
      (N.descFactorial l : ℝ) * ((l.factorial : ℝ) * (N.factorial : ℝ) /
        ((l+N+1).factorial : ℝ)) := by
    linear_combination h + hs * ((N.descFactorial l : ℝ) *
      ((l.factorial : ℝ) * (N.factorial : ℝ) / ((l+N+1).factorial : ℝ)))
  have hd := congrArg (fun n : ℕ => (n : ℝ)) (Nat.factorial_mul_descFactorial hl)
  push_cast at hd
  have he : l+N+1 = N+l+1 := by omega
  rw [he] at hclean
  have h₁ : (l.factorial : ℝ) ≠ 0 := by positivity
  have h₂ : ((N-l).factorial : ℝ) ≠ 0 := by positivity
  have h₃ : ((N+l+1).factorial : ℝ) ≠ 0 := by positivity
  have hD : (N.descFactorial l : ℝ) = (N.factorial : ℝ) / ((N-l).factorial : ℝ) :=
    (eq_div_iff h₂).mpr (by rwa [mul_comm])
  apply mul_left_cancel₀ h₁
  rw [hclean, hD]
  field_simp [h₂,h₃]
  ring


private theorem legendreBase_topDerivative (l : ℕ) :
    derivative^[l+l] (legendreBase l) = C ((-1 : ℝ)^l * ((l+l).factorial : ℝ)) := by
  rw [legendreBase, iterate_derivative_mul, Finset.sum_eq_single l]
  · rw [show l+l-l=l by omega, iterate_derivative_X_pow_eq_C_mul,
      iterate_derivative_one_sub_X]
    simp only [Nat.sub_self, pow_zero, mul_one, Nat.descFactorial_self, nsmul_eq_mul,
      ← C_eq_natCast, ← map_mul]
    congr 1
    have h := congrArg (fun n : ℕ => (n : ℝ))
      (Nat.choose_mul_factorial_mul_factorial (show l ≤ l+l by omega))
    rw [Nat.add_sub_cancel_left] at h
    push_cast at h
    linear_combination h * ((-1 : ℝ)^l)
  · intro q hq hn
    have hq' := Finset.mem_range.mp hq
    rw [iterate_derivative_X_pow_eq_C_mul, iterate_derivative_one_sub_X]
    rcases lt_or_gt_of_ne hn with h | h
    · rw [Nat.descFactorial_of_lt (show l < l+l-q by omega)]
      simp
    · rw [Nat.descFactorial_of_lt h]
      simp
  · intro h
    exact (h (Finset.mem_range.mpr (by omega))).elim

private theorem shiftedLegendre_topDerivative (l : ℕ) :
    derivative^[l] (shiftedLegendrePoly l) =
      C ((-1 : ℝ)^l * ((l+l).factorial : ℝ) / (l.factorial : ℝ)) := by
  have hc : (l.factorial : ℝ) ≠ 0 := by positivity
  apply mul_left_cancel₀ (show C (l.factorial : ℝ) ≠ (0 : ℝ[X]) by simpa using hc)
  rw [← iterate_derivative_C_mul, ← shiftedLegendre_rodrigues,
    ← Function.iterate_add_apply, ← legendreBase, legendreBase_topDerivative, ← map_mul]
  congr 1
  field_simp [hc]

theorem shiftedLegendre_norm_sq (l : ℕ) :
    polynomialIntegral (shiftedLegendrePoly l * shiftedLegendrePoly l) =
      1 / (2*(l : ℝ)+1) := by
  have h := polynomialIntegral_legendreBase_parts l l le_rfl (shiftedLegendrePoly l)
  rw [show derivative^[l] (legendreBase l) = _ from shiftedLegendre_rodrigues l,
    ← mul_left_comm, polynomialIntegral_const_mul, shiftedLegendre_topDerivative,
    polynomialIntegral_const_mul, legendreBase, polynomialIntegral_beta] at h
  have hs : (-1 : ℝ)^l * (-1)^l = 1 := by rw [← mul_pow]; norm_num
  have h₁ : (l.factorial : ℝ) ≠ 0 := by positivity
  have h₂ : ((l+l).factorial : ℝ) ≠ 0 := by positivity
  have h₃ : 2*(l : ℝ)+1 ≠ 0 := by positivity
  apply mul_left_cancel₀ h₁
  rw [h, Nat.factorial_succ]
  push_cast
  field_simp [h₁,h₂,h₃]
  linear_combination hs * ((l.factorial : ℝ)^2 * ((l+l).factorial : ℝ) * (2*(l : ℝ)+1))


theorem shiftedLegendre_natDegree (l : ℕ) : (shiftedLegendrePoly l).natDegree = l := by
  apply le_antisymm (shiftedLegendre_degree_le l)
  by_contra! h
  have hz := shiftedLegendre_orthogonal_lower l (shiftedLegendrePoly l) h
  rw [shiftedLegendre_norm_sq] at hz
  exact (ne_of_gt (by positivity : 0 < 1 / (2*(l:ℝ)+1))) hz

theorem shiftedLegendre_ne_zero (l : ℕ) : shiftedLegendrePoly l ≠ 0 := by
  intro h
  have hval := shiftedLegendre_eval_zero l
  simp [h] at hval

private theorem polynomialIntegral_sub (P Q : ℝ[X]) :
    polynomialIntegral (P-Q) = polynomialIntegral P - polynomialIntegral Q := by
  unfold polynomialIntegral
  simp only [eval_sub]
  exact intervalIntegral.integral_sub P.continuous.continuousOn.intervalIntegrable
    Q.continuous.continuousOn.intervalIntegrable

/-- The top Legendre moment of a nonzero polynomial detects its leading term. -/
theorem polynomialIntegral_top_legendre {P : ℝ[X]} (hp : P ≠ 0) :
    polynomialIntegral (P * shiftedLegendrePoly P.natDegree) =
      (P.leadingCoeff / (shiftedLegendrePoly P.natDegree).leadingCoeff) *
        (1 / (2*(P.natDegree : ℝ)+1)) := by
  let l := P.natDegree
  let L := shiftedLegendrePoly l
  let c := P.leadingCoeff / L.leadingCoeff
  have hL : L ≠ 0 := shiftedLegendre_ne_zero l
  have hc : c ≠ 0 := div_ne_zero (leadingCoeff_ne_zero.mpr hp) (leadingCoeff_ne_zero.mpr hL)
  have hd : (C c * L).natDegree = P.natDegree := by
    rw [natDegree_C_mul hc, shiftedLegendre_natDegree]
  have hcn : C c * L ≠ 0 := mul_ne_zero (by simpa using hc) hL
  have hdeg : (P - C c * L).degree < P.degree := by
    refine degree_sub_lt ?_ hp ?_
    · rw [degree_eq_natDegree hp, degree_eq_natDegree hcn, hd]
    · rw [leadingCoeff_mul, leadingCoeff_C]
      exact (div_mul_cancel₀ _ (leadingCoeff_ne_zero.mpr hL)).symm
  have hz : polynomialIntegral ((P - C c * L) * L) = 0 := by
    by_cases h : P - C c * L = 0
    · simp [h, polynomialIntegral]
    · rw [degree_eq_natDegree h, degree_eq_natDegree hp] at hdeg
      exact shiftedLegendre_orthogonal_lower l _ (WithBot.coe_lt_coe.mp hdeg)
  rw [sub_mul, polynomialIntegral_sub, mul_assoc, polynomialIntegral_const_mul,
    shiftedLegendre_norm_sq] at hz
  exact sub_eq_zero.mp hz

/-- Two bounded-degree polynomials agree if their tested Legendre moments agree. -/
theorem polynomial_eq_of_legendre_moments {P Q : ℝ[X]} {N : ℕ}
    (hp : P.natDegree ≤ N) (hq : Q.natDegree ≤ N)
    (h : ∀ l ≤ N, polynomialIntegral (P * shiftedLegendrePoly l) =
      polynomialIntegral (Q * shiftedLegendrePoly l)) : P = Q := by
  by_contra hn
  have hn' : P-Q ≠ 0 := sub_ne_zero.mpr hn
  let l := (P-Q).natDegree
  have hl : l ≤ N := (natDegree_sub_le_of_le hp hq).trans (max_self N).le
  have hz : polynomialIntegral ((P-Q) * shiftedLegendrePoly l) = 0 := by
    rw [sub_mul, polynomialIntegral_sub, h l hl, sub_self]
  rw [polynomialIntegral_top_legendre hn'] at hz
  exact mul_ne_zero
    (div_ne_zero (leadingCoeff_ne_zero.mpr hn')
      (leadingCoeff_ne_zero.mpr (shiftedLegendre_ne_zero l)))
    (ne_of_gt (by positivity : 0 < 1/(2*(l:ℝ)+1))) hz

private theorem polynomialIntegral_sum {ι : Type*} (s : Finset ι) (P : ι → ℝ[X]) :
    polynomialIntegral (∑ i ∈ s, P i) = ∑ i ∈ s, polynomialIntegral (P i) := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [polynomialIntegral]
  | insert a s ha ih => simp [Finset.sum_insert ha, polynomialIntegral_add, ih]

/-- Orthogonal expansion with the exact normalizations on [0,1]. -/
theorem polynomial_legendre_expansion {P : ℝ[X]} {N : ℕ} (hP : P.natDegree ≤ N) :
    P = ∑ l ∈ Finset.range (N+1), C ((2*(l:ℝ)+1) *
      polynomialIntegral (P * shiftedLegendrePoly l)) * shiftedLegendrePoly l := by
  apply polynomial_eq_of_legendre_moments hP
  · apply natDegree_sum_le_of_forall_le
    intro l hl
    exact (natDegree_C_mul_le _ _).trans ((shiftedLegendre_degree_le l).trans
      (Nat.le_of_lt_succ (Finset.mem_range.mp hl)))
  · intro l hl
    rw [Finset.sum_mul, polynomialIntegral_sum, Finset.sum_eq_single l]
    · rw [mul_assoc, polynomialIntegral_const_mul, shiftedLegendre_norm_sq]
      field_simp [show 2*(l:ℝ)+1 ≠ 0 by positivity]
    · intro j _ hj
      rw [mul_assoc, polynomialIntegral_const_mul, shiftedLegendre_orthogonal hj, mul_zero]
    · exact fun hn => (hn (Finset.mem_range.mpr (Nat.lt_succ_of_le hl))).elim

/-- Expansion of the exact coherent projector overlap, not an asymptotic formula. -/
theorem shiftedLegendre_overlap_expansion (N : ℕ) :
    ((1 : ℝ[X])-X)^N = ∑ l ∈ Finset.range (N+1),
      C ((2*(l:ℝ)+1) * ((N.factorial : ℝ)^2 /
        (((N-l).factorial : ℝ) * ((N+l+1).factorial : ℝ)))) * shiftedLegendrePoly l := by
  have hd : (((1 : ℝ[X])-X)^N).natDegree ≤ N := by
    exact natDegree_pow_le.trans (by
      have h : ((1 : ℝ[X])-X).natDegree ≤ 1 :=
        (natDegree_sub_le (1 : ℝ[X]) X).trans (by simp)
      simpa using Nat.mul_le_mul_left N h)
  calc
    _ = ∑ l ∈ Finset.range (N+1), C ((2*(l:ℝ)+1) *
        polynomialIntegral (((1 : ℝ[X])-X)^N * shiftedLegendrePoly l)) *
          shiftedLegendrePoly l := polynomial_legendre_expansion hd
    _ = _ := by
      apply Finset.sum_congr rfl
      intro l hl
      rw [shiftedLegendre_beta_moment N l (Nat.le_of_lt_succ (Finset.mem_range.mp hl))]

end F18
