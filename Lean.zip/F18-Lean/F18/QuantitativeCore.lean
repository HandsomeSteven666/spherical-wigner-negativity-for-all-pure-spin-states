import F18.Quantitative
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-! The last part of the quantitative proof. All integration and kernel
properties used here are explicit lemmas to be established for the concrete
symbols; the original theorem statement is unchanged. -/
namespace F18
open MeasureTheory

private def negPart (x : ℝ) : ℝ := max (-x) 0

/-- Pointwise estimate used to bound the negative part of a product. -/
private theorem negPart_mul_le (u v M : ℝ)
    (hu : |u| ≤ M) (hv : |v| ≤ M) :
    negPart (u * v) ≤ M * (negPart u + negPart v) := by
  have hM : 0 ≤ M := (abs_nonneg u).trans hu
  by_cases hu0 : 0 ≤ u <;> by_cases hv0 : 0 ≤ v
  · simp [negPart, max_eq_right (neg_nonpos.mpr hu0), max_eq_right (neg_nonpos.mpr hv0),
      max_eq_right (neg_nonpos.mpr (mul_nonneg hu0 hv0))]
  · have hv' : v ≤ 0 := le_of_not_ge hv0
    rw [negPart, max_eq_left (neg_nonneg.mpr (mul_nonpos_of_nonneg_of_nonpos hu0 hv'))]
    rw [show negPart u = 0 by simp [negPart, max_eq_right (neg_nonpos.mpr hu0)],
      show negPart v = -v by simp [negPart, max_eq_left (neg_nonneg.mpr hv')], zero_add, neg_mul_eq_mul_neg]
    exact mul_le_mul_of_nonneg_right ((le_abs_self u).trans hu) (neg_nonneg.mpr hv')
  · have hu' : u ≤ 0 := le_of_not_ge hu0
    rw [negPart, max_eq_left (neg_nonneg.mpr (mul_nonpos_of_nonpos_of_nonneg hu' hv0))]
    rw [show negPart u = -u by simp [negPart, max_eq_left (neg_nonneg.mpr hu')],
      show negPart v = 0 by simp [negPart, max_eq_right (neg_nonpos.mpr hv0)], add_zero, ← neg_mul]
    exact mul_le_mul_of_nonneg_left ((le_abs_self v).trans hv) (neg_nonneg.mpr hu') |>.trans_eq (mul_comm _ _)
  · have hu' : u ≤ 0 := le_of_not_ge hu0
    have hv' : v ≤ 0 := le_of_not_ge hv0
    rw [negPart, max_eq_right (neg_nonpos.mpr (mul_nonneg_of_nonpos_of_nonpos hu' hv'))]
    exact mul_nonneg hM (add_nonneg (le_max_right _ _) (le_max_right _ _))

/-- The manuscript's last integration estimate with arbitrary overlap lower factor. -/
theorem volume_lower_bound_of_overlap {X : Type*} [MeasurableSpace X] (μ : Measure X)
    (u v : X → ℝ) (d M E : ℝ) (hM : 0 < M)
    (hu : ∀ x, |u x| ≤ M) (hv : ∀ x, |v x| ≤ M)
    (hiu : Integrable (fun x => max (-u x) 0) μ)
    (hiv : Integrable (fun x => max (-v x) 0) μ)
    (hiuv : Integrable (fun x => u x * v x) μ)
    (hiabs : Integrable (fun x => |u x * v x|) μ)
    (hzero : ∫ x, u x * v x ∂μ = 0)
    (hneg : (∫ x, max (-v x) 0 ∂μ) = ∫ x, max (-u x) 0 ∂μ)
    (hlower : d * M ^ 2 * E ≤ ∫ x, |u x * v x| ∂μ) :
    d * M * E / 4 ≤ ∫ x, max (-u x) 0 ∂μ := by
  have hpoint (x : X) : |u x * v x| ≤ u x * v x +
      2 * (M * (max (-u x) 0 + max (-v x) 0)) := by
    have hm := negPart_mul_le (u x) (v x) M (hu x) (hv x)
    unfold negPart at hm
    by_cases h : 0 ≤ u x * v x
    · rw [abs_of_nonneg h]
      have h2 := mul_nonneg (le_of_lt hM)
        (add_nonneg (le_max_right (-u x) 0) (le_max_right (-v x) 0))
      linarith
    · have hn := le_of_not_ge h
      rw [abs_of_nonpos hn]
      rw [max_eq_left (neg_nonneg.mpr hn)] at hm
      linarith
  have hr : Integrable (fun x => 2 * (M * (max (-u x) 0 + max (-v x) 0))) μ :=
    ((hiu.add hiv).const_mul M).const_mul 2
  have hle := integral_mono hiabs (hiuv.add hr) hpoint
  have hupper : (∫ x, |u x * v x| ∂μ) ≤
      4 * M * (∫ x, max (-u x) 0 ∂μ) := by
    calc
      _ ≤ ∫ x, u x * v x + 2 * (M * (max (-u x) 0 + max (-v x) 0)) ∂μ := hle
      _ = _ := by
        rw [integral_add hiuv hr, hzero, integral_const_mul, integral_const_mul,
          integral_add hiu hiv, hneg]
        ring
  apply (le_of_mul_le_mul_left _ hM)
  nlinarith [hlower.trans hupper]

end F18
