import F18.SpinorPolynomial
import F18.PolynomialLog
import F18.AreaSupport

namespace F18
open scoped Polynomial

private noncomputable def radSquare : ℂ[X] := 1 - Polynomial.X ^ 2

private def radExp (d : Fin 3 →₀ ℕ) : ℕ := d 0 + d 1

private noncomputable def meridianTerm (P : MvPolynomial (Fin 3) ℂ)
    (a b : ℂ) (d : Fin 3 →₀ ℕ) : ℂ[X] :=
  Polynomial.C (P.coeff d * a ^ d 0 * b ^ d 1) * Polynomial.X ^ d 2 *
    radSquare ^ (radExp d / 2)

private noncomputable def meridianPart (P : MvPolynomial (Fin 3) ℂ)
    (a b : ℂ) (parity : ℕ) : ℂ[X] :=
  ∑ d ∈ P.support, if radExp d % 2 = parity then meridianTerm P a b d else 0

private def meridianVal (a b t s : ℂ) (i : Fin 3) : ℂ :=
  if i = 0 then a*s else if i = 1 then b*s else t

private theorem eval_meridianTerm (P : MvPolynomial (Fin 3) ℂ) (a b t s : ℂ)
    (d : Fin 3 →₀ ℕ) (hs : s ^ 2 = 1 - t ^ 2) :
    P.coeff d * ∏ i, meridianVal a b t s i ^ d i =
      (meridianTerm P a b d).eval t * s ^ (radExp d % 2) := by
  rw [Fin.prod_univ_three]
  simp only [meridianVal, Fin.zero_ne_one, Fin.reduceEq, if_true, if_false,
    meridianTerm, Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_pow,
    Polynomial.eval_X, radSquare, Polynomial.eval_sub, Polynomial.eval_one,
    ← hs, ← pow_mul, mul_pow]
  have he : s ^ d 0 * s ^ d 1 =
      s ^ (2 * (radExp d / 2)) * s ^ (radExp d % 2) := by
    rw [← pow_add, ← pow_add]
    congr 1
    exact (Nat.div_add_mod (radExp d) 2).symm
  calc
    _ = (P.coeff d * a ^ d 0 * b ^ d 1 * t ^ d 2) * (s ^ d 0 * s ^ d 1) := by ring
    _ = _ := by rw [he]; ring

private theorem eval_meridianParts (P : MvPolynomial (Fin 3) ℂ) (a b t s : ℂ)
    (hs : s ^ 2 = 1 - t ^ 2) :
    MvPolynomial.eval (meridianVal a b t s) P =
      (meridianPart P a b 0).eval t + (meridianPart P a b 1).eval t * s := by
  rw [← MvPolynomial.eval₂_id, MvPolynomial.eval₂_eq']
  unfold meridianPart
  simp only [RingHom.id_apply, Polynomial.eval_finset_sum, Finset.sum_mul, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro d _
  rw [eval_meridianTerm P a b t s d hs]
  have h : radExp d % 2 = 0 ∨ radExp d % 2 = 1 := by omega
  rcases h with h | h <;> simp [h]

private theorem meridianPart_degree (P : MvPolynomial (Fin 3) ℂ)
    (a b : ℂ) {N parity : ℕ} (hP : P.totalDegree ≤ N) (hpar : parity ≤ N) :
    (meridianPart P a b parity).natDegree ≤ N - parity := by
  unfold meridianPart
  apply Polynomial.natDegree_sum_le_of_forall_le
  intro d hd
  split_ifs with h
  · have hd' := (MvPolynomial.le_totalDegree hd).trans hP
    rw [Finsupp.sum_fintype _ _ (by simp), Fin.sum_univ_three] at hd'
    have hrad : radSquare.natDegree ≤ 2 := by
      unfold radSquare
      exact (Polynomial.natDegree_sub_le ..).trans (by simp)
    have hp : (radSquare ^ (radExp d / 2)).natDegree ≤ 2 * (radExp d / 2) :=
      Polynomial.natDegree_pow_le.trans (by simpa [Nat.mul_comm] using
        (Nat.mul_le_mul_left (radExp d / 2) hrad))
    unfold meridianTerm
    calc
      _ ≤ d 2 + 2 * (radExp d / 2) :=
        Polynomial.natDegree_mul_le.trans (Nat.add_le_add
          (Polynomial.natDegree_mul_le.trans (by simp only [Polynomial.natDegree_C,
            Polynomial.natDegree_X_pow, zero_add, le_refl])) hp)
      _ ≤ N - parity := by unfold radExp at *; omega
  · simp

/-- The product of the two opposite-meridian restrictions is polynomial in
the polar cosine. Its degree is at most twice the original Cartesian degree. -/
theorem opposite_meridian_poly (P : MvPolynomial (Fin 3) ℂ) (a b : ℂ)
    {N : ℕ} (hN : 0 < N) (hP : P.totalDegree ≤ N) :
    ∃ Q : ℂ[X], Q.natDegree ≤ 2*N ∧ ∀ (t s : ℂ), s ^ 2 = 1 - t ^ 2 →
      Q.eval t = MvPolynomial.eval (meridianVal a b t s) P *
        MvPolynomial.eval (meridianVal a b t (-s)) P := by
  let E := meridianPart P a b 0
  let O := meridianPart P a b 1
  refine ⟨E ^ 2 - radSquare * O ^ 2, ?_, ?_⟩
  · have hE : E.natDegree ≤ N := by simpa [E] using
        (meridianPart_degree P a b (parity := 0) hP (by omega))
    have hO : O.natDegree ≤ N - 1 := meridianPart_degree P a b hP (by omega)
    have hrad : radSquare.natDegree ≤ 2 := by
      unfold radSquare
      exact (Polynomial.natDegree_sub_le ..).trans (by simp)
    apply (Polynomial.natDegree_sub_le ..).trans
    apply max_le
    · exact Polynomial.natDegree_pow_le.trans (by omega)
    · exact Polynomial.natDegree_mul_le.trans (by
        have h₂ : (O ^ 2).natDegree ≤ 2 * O.natDegree := Polynomial.natDegree_pow_le
        omega)
  · intro t s hs
    rw [eval_meridianParts P a b t s hs, eval_meridianParts P a b t (-s) (by simpa using hs)]
    change _ = (E.eval t + O.eval t * s) * (E.eval t + O.eval t * (-s))
    simp only [Polynomial.eval_sub, Polynomial.eval_mul, Polynomial.eval_pow, radSquare,
      Polynomial.eval_one, Polynomial.eval_X]
    rw [← hs]
    ring


/-- For any azimuth, the product of the two concrete symbols at opposite
azimuths is a polynomial in the polar cosine of degree at most 2N. -/
theorem wigner_opposite_meridian {N : ℕ} (hN : 0 < N)
    (signs : Weight N → Bool) (ψ : State N) (φ : ℝ) :
    ∃ Q : ℂ[X], Q.natDegree ≤ 2*N ∧ ∀ t : ℝ, t ^ 2 ≤ 1 →
      Q.eval (t : ℂ) =
        (wigner signs ψ (sphereChart (t,φ)) : ℂ) *
          (wigner signs ψ (sphereChart (t,φ + Real.pi)) : ℂ) := by
  obtain ⟨Q,hQ,h⟩ := opposite_meridian_poly (wignerPoly signs ψ)
    (Real.cos φ : ℂ) (Real.sin φ : ℂ) hN (totalDegree_wignerPoly signs ψ)
  refine ⟨Q,hQ,?_⟩
  intro t ht
  let ρ := Real.sqrt (1-t^2)
  have hρ : (ρ : ℂ) ^ 2 = 1 - (t : ℂ) ^ 2 := by
    exact_mod_cast Real.sq_sqrt (sub_nonneg.mpr ht)
  have h₁ : meridianVal (Real.cos φ) (Real.sin φ) t ρ =
      sphereCoords (sphereChart (t,φ)) := by
    funext i
    rw [sphereCoords, sphereChart_val ht]
    fin_cases i <;> simp [meridianVal, ρ, mul_comm]
  have h₂ : meridianVal (Real.cos φ) (Real.sin φ) t (-(ρ : ℂ)) =
      sphereCoords (sphereChart (t,φ + Real.pi)) := by
    funext i
    rw [sphereCoords, sphereChart_val ht]
    fin_cases i <;> simp [meridianVal, ρ, Real.cos_add_pi, Real.sin_add_pi, mul_comm]
  rw [h _ _ hρ, h₁, h₂, eval_wignerPoly, eval_wignerPoly]


def northPoint : Sphere := ⟨(0, 0, 1), by norm_num⟩

theorem sphereChart_north (φ : ℝ) : sphereChart (1,φ) = northPoint := by
  apply Subtype.ext
  rw [sphereChart_val (q := (1,φ)) (by norm_num)]
  simp [northPoint]

/-- On the interval [0,1] the polar cosine is 1 - 2s. The opposite-meridian
product, normalized by the square of its north-pole value, starts at 1. -/
theorem normalized_wigner_meridian {N : ℕ} (hN : 0 < N)
    (signs : Weight N → Bool) (ψ : State N) (φ : ℝ) (h₀ : wigner signs ψ northPoint ≠ 0) :
    ∃ P : ℂ[X], P.eval 0 = 1 ∧ P.natDegree ≤ 2*N ∧
      ∀ s : ℝ, s ∈ Set.Icc 0 1 →
        P.eval (s : ℂ) =
          ((wigner signs ψ (sphereChart (1-2*s,φ)) *
            wigner signs ψ (sphereChart (1-2*s,φ + Real.pi))) : ℝ) /
          ((wigner signs ψ northPoint : ℝ) ^ 2 : ℝ) := by
  obtain ⟨Q, hQ, h⟩ := wigner_opposite_meridian hN signs ψ φ
  let L : ℂ[X] := 1 - Polynomial.C 2 * Polynomial.X
  let c : ℂ := (wigner signs ψ northPoint : ℂ) ^ 2
  have hc : c ≠ 0 := pow_ne_zero _ (by exact_mod_cast h₀)
  have hAt1 : Q.eval 1 = c := by
    simpa only [Complex.ofReal_one, sphereChart_north, c, pow_two] using h 1 (by norm_num)
  have hL (s : ℝ) : L.eval (s : ℂ) = ((1 - 2*s : ℝ) : ℂ) := by
    simp [L, Complex.ofReal_sub, Complex.ofReal_mul]
  refine ⟨Polynomial.C c⁻¹ * Q.comp L, ?_, ?_, ?_⟩
  · rw [Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_comp,
      ← Complex.ofReal_zero, hL]
    norm_num only [mul_zero, sub_zero, Complex.ofReal_one]
    rw [hAt1, inv_mul_cancel₀ hc]
  · have hd : L.natDegree ≤ 1 := by
      unfold L
      refine (Polynomial.natDegree_sub_le ..).trans (max_le (by simp) ?_)
      exact (Polynomial.natDegree_C_mul_le _ _).trans (by simp)
    apply (Polynomial.natDegree_C_mul_le ..).trans
    apply Polynomial.natDegree_comp_le.trans
    exact (Nat.mul_le_mul_left _ hd).trans (by simpa using hQ)
  · intro s hs
    have ht : (1-2*s)^2 ≤ 1 := (sq_le_one_iff_abs_le_one _).mpr
      (abs_le.mpr ⟨by linarith [hs.2], by linarith [hs.1]⟩)
    rw [Polynomial.eval_mul, Polynomial.eval_C, Polynomial.eval_comp, hL, h _ ht]
    push_cast
    rw [div_eq_mul_inv, mul_comm]


open Set MeasureTheory in
/-- The one-dimensional logarithmic estimate, with the original constant,
for the normalized product of opposite-meridian Wigner symbols. -/
theorem log_normalized_wigner_meridian {N : ℕ} (hN : 0 < N)
    (signs : Weight N → Bool) (ψ : State N) (φ : ℝ) (h₀ : wigner signs ψ northPoint ≠ 0) :
    let f : ℝ → ℝ := fun s =>
      wigner signs ψ (sphereChart (1-2*s,φ)) *
        wigner signs ψ (sphereChart (1-2*s,φ + Real.pi)) /
        (wigner signs ψ northPoint) ^ 2
    (∀ᵐ s ∂(volume.restrict (Icc (0 : ℝ) 1)), f s ≠ 0) ∧
      IntervalIntegrable (fun s => Real.log |f s|) volume 0 1 ∧
      -(2 * (N : ℝ)) * (1 + Real.exp (-1)) ≤ ∫ s in (0 : ℝ)..1, Real.log |f s| := by
  intro f
  obtain ⟨P, hP0, hPd, hP⟩ := normalized_wigner_meridian hN signs ψ φ h₀
  have he (s : ℝ) (hs : s ∈ Icc (0 : ℝ) 1) : P.eval (s : ℂ) = (f s : ℂ) := by
    simpa only [f, Complex.ofReal_div] using hP s hs
  have hne : P ≠ 0 := by rintro rfl; simp at hP0
  have hfin : {s : ℝ | P.eval (s : ℂ) = 0}.Finite :=
    (Polynomial.finite_setOf_isRoot hne).preimage Complex.ofReal_injective.injOn
  have hae : ∀ᵐ s : ℝ ∂volume, P.eval (s : ℂ) ≠ 0 := by
    rw [ae_iff]
    simpa only [not_not] using hfin.measure_zero volume
  constructor
  · rw [ae_restrict_iff' measurableSet_Icc]
    filter_upwards [hae] with s hn hs
    intro hz
    exact hn ((he s hs).trans (by rw [hz]; norm_num))
  have hfun : EqOn (fun s : ℝ => Real.log ‖P.eval (s : ℂ)‖)
      (fun s => Real.log |f s|) (uIcc 0 1) := by
    intro s hs
    rw [uIcc_of_le zero_le_one] at hs
    simp only [he s hs, Complex.norm_real, Real.norm_eq_abs]
  obtain ⟨hi, hlo⟩ := integral_log_polynomial_complex P hP0
  refine ⟨hi.congr ?_, ?_⟩
  · rw [Filter.EventuallyEq, ae_restrict_iff' measurableSet_uIoc]
    exact Filter.Eventually.of_forall fun s hs => hfun (uIoc_subset_uIcc hs)
  · rw [intervalIntegral.integral_congr hfun] at hlo
    have hdegree : (P.natDegree : ℝ) ≤ 2 * (N : ℝ) := by exact_mod_cast hPd
    exact (mul_le_mul_of_nonneg_right (neg_le_neg hdegree) (by positivity)).trans hlo

end F18
