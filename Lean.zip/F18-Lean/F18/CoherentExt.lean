import F18.SpinRepresentation

namespace F18
open Polynomial
open scoped Polynomial

private theorem eval_eq_zero_of_real_inputs (P : ℂ[X])
    (h : ∀ t : ℝ, P.eval (t : ℂ) = 0) : P = 0 := by
  apply Polynomial.eq_zero_of_infinite_isRoot
  refine (Set.infinite_range_of_injective Complex.ofReal_injective).mono ?_
  rintro _ ⟨t,rfl⟩
  exact h t

/-- The monomials z^r times conjugate(z)^s are linearly independent as
functions of z. This uses only univariate polynomial uniqueness twice. -/
theorem conjugate_monomials_ext (N : ℕ) (d : Weight N → Weight N → ℂ)
    (h : ∀ z : ℂ, (∑ r : Weight N, ∑ s : Weight N,
      d r s * z^r.val * (starRingEnd ℂ z)^s.val) = 0) : ∀ r s, d r s = 0 := by
  let B (z w : ℂ) := ∑ r : Weight N, ∑ s : Weight N, d r s * z^r.val * w^s.val
  have hXY (x y : ℂ) : B (x+Complex.I*y) (x-Complex.I*y) = 0 := by
    have hrealY (t : ℝ) (x : ℂ) : B (x+Complex.I*t) (x-Complex.I*t) = 0 := by
      let P : ℂ[X] := ∑ r : Weight N, ∑ s : Weight N, C (d r s) *
        (X+C (Complex.I*t))^r.val * (X-C (Complex.I*t))^s.val
      have hp (z : ℂ) : P.eval z = B (z+Complex.I*t) (z-Complex.I*t) := by
        simp only [P, B, eval_finset_sum, eval_mul, eval_pow, eval_add, eval_sub, eval_C, eval_X]
      have hP : P = 0 := by
        apply eval_eq_zero_of_real_inputs
        intro z
        rw [hp]
        have hz : starRingEnd ℂ ((z : ℂ)+Complex.I*t) = (z : ℂ)-Complex.I*t := by
          simp only [map_add, map_mul, Complex.conj_I, Complex.conj_ofReal]
          ring
        simpa only [B, hz] using h ((z : ℂ)+Complex.I*t)
      rw [← hp, hP, eval_zero]
    let Q : ℂ[X] := ∑ r : Weight N, ∑ s : Weight N, C (d r s) *
      (C x + C Complex.I*X)^r.val * (C x - C Complex.I*X)^s.val
    have hQ (z : ℂ) : Q.eval z = B (x+Complex.I*z) (x-Complex.I*z) := by
      simp only [Q, B, eval_finset_sum, eval_mul, eval_pow, eval_add, eval_sub, eval_C, eval_X]
    have hzero : Q = 0 := eval_eq_zero_of_real_inputs Q (fun t => (hQ t).trans (hrealY t x))
    rw [← hQ, hzero, eval_zero]
  have hB (z w : ℂ) : B z w = 0 := by
    have hp := hXY ((z+w)/2) ((z-w)/(2*Complex.I))
    have h₁ : (z+w)/2 + Complex.I*((z-w)/(2*Complex.I)) = z := by field_simp [Complex.I_ne_zero]; ring
    have h₂ : (z+w)/2 - Complex.I*((z-w)/(2*Complex.I)) = w := by field_simp [Complex.I_ne_zero]; ring
    rwa [h₁,h₂] at hp
  have hy (w : ℂ) :
      (fun r : Weight N => ∑ s : Weight N, d r s * w^s.val) = fun _ => 0 := by
    apply coefficients_eq_of_power_sum N
    intro z
    simp only [Finset.sum_mul, zero_mul, Finset.sum_const_zero]
    convert hB z w using 1
    apply Finset.sum_congr rfl
    intro r _
    apply Finset.sum_congr rfl
    intro s _
    ring
  intro r s
  have he : d r = fun _ => 0 := by
    apply coefficients_eq_of_power_sum N
    intro w
    simpa only [zero_mul, Finset.sum_const_zero] using congrFun (hy w) r
  exact congrFun he s


theorem coherentVec_smul_pair (N : ℕ) (c : ℂ) (z : ℂ × ℂ) :
    coherentVec N (c*z.1,c*z.2) = c^N • coherentVec N z := by
  funext r
  simp only [coherentVec, Pi.smul_apply, smul_eq_mul, mul_pow]
  have h : c ^ (N-r.val) * c ^ r.val = c^N := by
    rw [← pow_add, Nat.sub_add_cancel (Nat.le_of_lt_succ r.isLt)]
  linear_combination h * (rootChoose N r * z.1^(N-r.val) * z.2^r.val)

theorem projector_smul_state {N : ℕ} (c : ℂ) (ψ : State N) :
    projector (c • ψ) = (c * starRingEnd ℂ c) • projector ψ := by
  ext i j
  simp only [projector, Pi.smul_apply, smul_eq_mul, map_mul, Matrix.smul_apply]
  ring

private noncomputable def stereographicSpinor (z : ℂ) : UnitSpinor :=
  let a := (Real.sqrt (1+Complex.normSq z))⁻¹
  ⟨((a : ℂ),(a : ℂ)*z), by
    have hpos : 0 < 1+Complex.normSq z := by linarith [Complex.normSq_nonneg z]
    change Complex.normSq (a : ℂ) + Complex.normSq ((a : ℂ)*z) = 1
    dsimp only [a]
    simp only [Complex.normSq_mul, Complex.normSq_ofReal, ← pow_two, inv_pow,
      Real.sq_sqrt hpos.le]
    field_simp⟩

private theorem linear_vanishes_raw {N : ℕ} (L : Operator N →ₗ[ℂ] ℂ)
    (h : ∀ u : UnitSpinor, L (projector (coherentVec N u.val)) = 0) (z : ℂ) :
    L (projector (coherentVec N (1,z))) = 0 := by
  let a := (Real.sqrt (1+Complex.normSq z))⁻¹
  have ha : (a : ℂ) ≠ 0 := by
    exact_mod_cast inv_ne_zero (Real.sqrt_pos.mpr (by linarith [Complex.normSq_nonneg z] : 0 < 1+Complex.normSq z)).ne'
  have he := h (stereographicSpinor z)
  change L (projector (coherentVec N ((a : ℂ), (a : ℂ)*z))) = 0 at he
  have hh : ((a : ℂ), (a : ℂ)*z) = ((a : ℂ)*((1,z) : ℂ × ℂ).1, (a : ℂ)*((1,z) : ℂ × ℂ).2) := by simp
  rw [hh] at he
  rw [coherentVec_smul_pair, projector_smul_state, map_smul, smul_eq_mul] at he
  have hc : starRingEnd ℂ ((a : ℂ)^N) ≠ 0 := by
    exact (_root_.map_ne_zero (starRingEnd ℂ)).mpr (pow_ne_zero N ha)
  exact (mul_eq_zero.mp he).resolve_left (mul_ne_zero (pow_ne_zero N ha) hc)

private def matrixUnit {N : ℕ} (r s : Weight N) : Operator N :=
  fun i j => if i = r ∧ j = s then 1 else 0

private theorem matrix_unit_sum {N : ℕ} (A : Operator N) :
    (∑ r : Weight N, ∑ s : Weight N, A r s • matrixUnit r s) = A := by
  ext i j
  simp only [Matrix.sum_apply, Matrix.smul_apply, smul_eq_mul, matrixUnit]
  rw [Finset.sum_eq_single i]
  · rw [Finset.sum_eq_single j]
    · simp
    · intro s _ hs
      simp [Ne.symm hs]
    · simp
  · intro r _ hr
    simp [Ne.symm hr]
  · simp

/-- Coherent projectors separate complex-linear matrix functionals.
This is an exact coordinate statement, so the final overlap defect can
be tested twice without a separate abstract spanning theorem. -/
theorem linear_ext_coherent_projectors {N : ℕ} (L : Operator N →ₗ[ℂ] ℂ)
    (h : ∀ u : UnitSpinor, L (projector (coherentVec N u.val)) = 0) : ∀ A, L A = 0 := by
  let d : Weight N → Weight N → ℂ := fun r s =>
    L (matrixUnit r s) * rootChoose N r * rootChoose N s
  have he (z : ℂ) : (∑ r : Weight N, ∑ s : Weight N, d r s * z^r.val *
      (starRingEnd ℂ z)^s.val) = 0 := by
    have hz := linear_vanishes_raw L h z
    conv at hz => lhs; arg 2; rw [← matrix_unit_sum (projector (coherentVec N (1,z)))]
    simp only [map_sum, map_smul, smul_eq_mul, projector, coherentVec, one_pow, mul_one,
      map_mul, map_pow, rootChoose_star] at hz
    rw [← hz]
    apply Finset.sum_congr rfl
    intro r _
    apply Finset.sum_congr rfl
    intro s _
    unfold d
    ring
  have hd := conjugate_monomials_ext N d he
  have hm (r s : Weight N) : L (matrixUnit r s) = 0 := by
    have hz := hd r s
    exact ((mul_eq_zero.mp hz).resolve_right (rootChoose_ne_zero N s) |> mul_eq_zero.mp).resolve_right
      (rootChoose_ne_zero N r)
  intro A
  conv_lhs => arg 2; rw [← matrix_unit_sum A]
  simp [map_smul, hm]

end F18
