import F18.Quantitative
import Mathlib.MeasureTheory.Measure.Prod
import Mathlib.Tactic.FunProp
import Mathlib.Tactic.FieldSimp

namespace F18
open MeasureTheory Set

theorem measurable_sphereChart : Measurable sphereChart := by
  let S : Set (ℝ × ℝ) := {q | q.1 ^ 2 ≤ 1}
  let f : S → Sphere := fun q =>
    ⟨(Real.sqrt (1 - q.val.1 ^ 2) * Real.cos q.val.2,
      Real.sqrt (1 - q.val.1 ^ 2) * Real.sin q.val.2, q.val.1), by
      change (Real.sqrt (1 - q.val.1 ^ 2) * Real.cos q.val.2) ^ 2 +
        (Real.sqrt (1 - q.val.1 ^ 2) * Real.sin q.val.2) ^ 2 + q.val.1 ^ 2 = 1
      rw [mul_pow, mul_pow, ← mul_add, Real.cos_sq_add_sin_sq, mul_one,
        Real.sq_sqrt (sub_nonneg.mpr q.property)]
      ring⟩
  let g : (Sᶜ : Set (ℝ × ℝ)) → Sphere := fun _ => ⟨(0, 0, 1), by norm_num⟩
  have hf : Measurable f := by
    unfold f
    apply Measurable.subtype_mk
    fun_prop
  have hg : Measurable g := measurable_const
  have hS : MeasurableSet S := measurableSet_le (measurable_fst.pow_const 2) measurable_const
  exact Measurable.dite hf hg hS

theorem areaProbability_mass : areaProbability univ = 1 := by
  unfold areaProbability
  rw [Measure.smul_apply, Measure.map_apply measurable_sphereChart MeasurableSet.univ,
    preimage_univ, Measure.restrict_apply MeasurableSet.univ, univ_inter,
    Measure.volume_eq_prod, Measure.prod_prod]
  simp only [Real.volume_Icc, sub_neg_eq_add, sub_zero, smul_eq_mul]
  have hp : 0 < Real.pi := Real.pi_pos
  have hM : 0 ≤ (4 * Real.pi)⁻¹ := by positivity
  have h₂ : 0 ≤ (1 : ℝ) + 1 := by norm_num
  rw [← ENNReal.ofReal_mul h₂, ← ENNReal.ofReal_mul hM]
  have heq : (4 * Real.pi)⁻¹ * ((1 + 1) * (2 * Real.pi)) = 1 := by
    field_simp
    all_goals ring
  rw [heq, ENNReal.ofReal_one]

theorem spinMeasure_mass (N : ℕ) : spinMeasure N univ = ((N + 1 : ℕ) : ENNReal) := by
  simp [spinMeasure, Measure.smul_apply, areaProbability_mass]

end F18
