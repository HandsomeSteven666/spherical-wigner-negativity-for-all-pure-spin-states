import Mathlib.Analysis.SpecialFunctions.Integrals
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

namespace F18
open MeasureTheory

/-- A real logarithm integral in the proof of the manuscript's logarithmic mean. -/
theorem integral_log_linear_exact (a : ℝ) (ha : a ≠ 0) :
    (∫ s in (0 : ℝ)..1, Real.log |1 - a * s|) =
      -1 + (a - 1) * Real.log (1 - a) / a := by
  simp only [Real.log_abs]
  rw [intervalIntegral.integral_comp_sub_mul Real.log ha 1, integral_log]
  simp only [mul_one, mul_zero, sub_zero, Real.log_one, smul_eq_mul]
  field_simp
  all_goals ring

theorem mul_log_lower (x : ℝ) (hx : 0 < x) :
    -Real.exp (-1) ≤ x * Real.log x := by
  have he := Real.exp_pos (-1)
  have h := Real.log_le_sub_one_of_pos (div_pos he hx)
  rw [Real.log_div he.ne' hx.ne', Real.log_exp] at h
  have h' := mul_le_mul_of_nonneg_left h hx.le
  have hm : x * (Real.exp (-1) / x) = Real.exp (-1) := by
    field_simp
  simp only [mul_sub, hm] at h'
  linarith

/-- The linear real factor has the exact bound used in the manuscript. -/
theorem integral_log_linear_lower (a : ℝ) (ha : 0 ≤ a) :
    -(1 + Real.exp (-1)) ≤ ∫ s in (0 : ℝ)..1, Real.log |1 - a * s| := by
  have he := Real.exp_pos (-1)
  rcases eq_or_lt_of_le ha with rfl | ha'
  · simp
    linarith
  rw [integral_log_linear_exact a ha'.ne']
  by_cases h : a ≤ 1
  · have hn : 0 ≤ (a - 1) * Real.log (1 - a) :=
      mul_nonneg_of_nonpos_of_nonpos (sub_nonpos.mpr h)
        (Real.log_nonpos (sub_nonneg.mpr h) (by linarith))
    have := div_nonneg hn ha
    linarith
  · have hlt : 1 < a := lt_of_not_ge h
    rw [show 1 - a = -(a - 1) by ring, Real.log_neg_eq_log]
    have hp := mul_log_lower (a - 1) (sub_pos.mpr hlt)
    have hq : -Real.exp (-1) * a ≤ -Real.exp (-1) := by
      nlinarith [mul_nonneg he.le (sub_nonneg.mpr hlt.le)]
    have hr := (le_div_iff₀ ha').2 (hq.trans hp)
    linarith

theorem integral_log_linear_lower_all (a : ℝ) :
    -(1 + Real.exp (-1)) ≤ ∫ s in (0 : ℝ)..1, Real.log |1 - a * s| := by
  by_cases ha : 0 ≤ a
  · exact integral_log_linear_lower a ha
  have hz := intervalIntegral.integral_nonneg (μ := volume) (by norm_num : (0 : ℝ) ≤ 1)
    (f := fun s => Real.log |1 - a * s|) (fun s hs => by
      have hs0 : 0 ≤ s := hs.1
      have hh : 0 ≤ -(a * s) := neg_nonneg.mpr (mul_nonpos_of_nonpos_of_nonneg (le_of_not_ge ha) hs0)
      apply Real.log_nonneg
      exact (show (1 : ℝ) ≤ 1 - a * s by linarith).trans (le_abs_self _))
  exact (neg_nonpos.mpr (add_nonneg zero_le_one (Real.exp_pos _).le)).trans hz

end F18
