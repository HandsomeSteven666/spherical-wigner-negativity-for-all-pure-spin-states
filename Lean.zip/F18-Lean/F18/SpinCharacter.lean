import F18.SpinRepresentation
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Algebra.GeomSum

namespace F18
open scoped Matrix

/-- Fundamental diagonal rotation with entries exp(it), exp(-it). -/
noncomputable def torusSpinor (t : ℝ) : UnitSpinor :=
  ⟨(Complex.exp ((t : ℂ) * Complex.I), 0), by
    simp [Complex.normSq_eq_norm_sq, Complex.norm_exp, Complex.mul_re]⟩

private noncomputable def torusRatio (t : ℝ) : ℂ :=
  Complex.exp ((-2 * (t : ℂ)) * Complex.I)

noncomputable def torusWeight (N : ℕ) (t : ℝ) (r : Weight N) : ℂ :=
  (torusSpinor t).val.1 ^ N * torusRatio t ^ r.val

theorem spinMatrix_torus (N : ℕ) (t : ℝ) :
    spinMatrix N (torusSpinor t).val.1 (torusSpinor t).val.2 =
      Matrix.diagonal (torusWeight N t) := by
  ext r s
  change spinMatrix N (torusSpinor t).val.1 0 r s = _
  rw [spinMatrix_diagonal_entry, Matrix.diagonal_apply]
  by_cases h : r = s
  · subst s
    simp only [if_pos rfl]
    let a := (torusSpinor t).val.1
    have hc : starRingEnd ℂ a = a * torusRatio t := by
      change starRingEnd ℂ (Complex.exp ((t : ℂ) * Complex.I)) =
        Complex.exp ((t : ℂ) * Complex.I) * Complex.exp ((-2 * (t : ℂ)) * Complex.I)
      rw [← Complex.exp_conj, ← Complex.exp_add]
      congr 1
      simp only [map_mul, Complex.conj_ofReal, Complex.conj_I]
      ring
    change a^(N-r.val) * (starRingEnd ℂ a)^r.val = a^N * torusRatio t ^ r.val
    rw [hc, mul_pow, ← mul_assoc, ← pow_add, Nat.sub_add_cancel (Nat.le_of_lt_succ r.isLt)]
  · simp [h]

noncomputable def characterAngle (N : ℕ) : ℝ := Real.pi / ((N : ℝ) + 1)

private theorem characterAngle_pos (N : ℕ) : 0 < characterAngle N :=
  div_pos Real.pi_pos (by positivity)

private theorem ratio_powers_distinct (N : ℕ) (r s : Weight N)
    (h : torusRatio (characterAngle N) ^ r.val = torusRatio (characterAngle N) ^ s.val) :
    r = s := by
  unfold torusRatio at h
  rw [← Complex.exp_nat_mul, ← Complex.exp_nat_mul] at h
  obtain ⟨k, hk⟩ := Complex.exp_eq_exp_iff_exists_int.mp h
  have hi := congrArg Complex.im hk
  simp [Complex.add_im, Complex.mul_im, Complex.mul_re] at hi
  have hA : (((r.val : ℝ) - s.val) * (-2 * characterAngle N)) =
      (k : ℝ) * (2 * Real.pi) := by linarith
  have hden : ((N : ℝ) + 1) ≠ 0 := by positivity
  have hB := hA
  unfold characterAngle at hB
  field_simp [hden] at hB
  have hπ : Real.pi ≠ 0 := Real.pi_pos.ne'
  have hsimp : -((r.val : ℝ) - s.val) = (k : ℝ) * ((N : ℝ)+1) := by
    apply (mul_right_cancel₀ (show 2*Real.pi ≠ 0 by positivity))
    linear_combination hB
  have hr : (r.val : ℝ) ≤ N := by exact_mod_cast Nat.le_of_lt_succ r.isLt
  have hs : (s.val : ℝ) ≤ N := by exact_mod_cast Nat.le_of_lt_succ s.isLt
  have hr0 : 0 ≤ (r.val : ℝ) := by positivity
  have hs0 : 0 ≤ (s.val : ℝ) := by positivity
  have hklo : (-1 : ℝ) < (k : ℝ) := by
    by_contra! hn
    have := mul_le_mul_of_nonneg_right hn (show 0 ≤ (N : ℝ)+1 by positivity)
    linarith
  have hkhi : (k : ℝ) < 1 := by
    by_contra! hn
    have := mul_le_mul_of_nonneg_right hn (show 0 ≤ (N : ℝ)+1 by positivity)
    linarith
  have hk0 : k = 0 := by
    have h₁ : (-1 : ℤ) < k := by exact_mod_cast hklo
    have h₂ : k < (1 : ℤ) := by exact_mod_cast hkhi
    omega
  rw [hk0, Int.cast_zero, zero_mul] at hsimp
  apply Fin.ext
  exact_mod_cast (show (r.val : ℝ) = s.val by linarith)

theorem torusWeight_injective (N : ℕ) :
    Function.Injective (torusWeight N (characterAngle N)) := by
  intro r s h
  apply ratio_powers_distinct N r s
  have hn : (torusSpinor (characterAngle N)).val.1 ^ N ≠ 0 :=
    pow_ne_zero _ (Complex.exp_ne_zero _)
  exact mul_left_cancel₀ hn h

private theorem characterRatio_pow (N : ℕ) :
    torusRatio (characterAngle N) ^ (N+1) = 1 := by
  unfold torusRatio characterAngle
  rw [← Complex.exp_nat_mul]
  have he : ((N+1 : ℕ) : ℂ) * (-2 * (((Real.pi / ((N : ℝ)+1)) : ℝ) : ℂ) * Complex.I) =
      -(2 * (Real.pi : ℂ) * Complex.I) := by
    push_cast
    have hn : ((N : ℂ) + 1) ≠ 0 := by exact_mod_cast (show (N : ℝ)+1 ≠ 0 by positivity)
    field_simp [hn]
    ring
  rw [he, Complex.exp_neg, Complex.exp_two_pi_mul_I, inv_one]

theorem spinMatrix_torus_trace_zero {N : ℕ} (hN : 0 < N) :
    Matrix.trace (spinMatrix N (torusSpinor (characterAngle N)).val.1
      (torusSpinor (characterAngle N)).val.2) = 0 := by
  rw [spinMatrix_torus, Matrix.trace_diagonal]
  unfold torusWeight
  rw [← Finset.mul_sum, Fin.sum_univ_eq_sum_range]
  have hn : torusRatio (characterAngle N) ≠ 1 := by
    intro h
    have hr := ratio_powers_distinct N (0 : Weight N) ⟨1, by omega⟩
      (by simp [h])
    have hv := congrArg Fin.val hr
    exact Nat.zero_ne_one hv
  rw [geom_sum_eq hn, characterRatio_pow, sub_self, zero_div, mul_zero]


private noncomputable def mixingSpinor : UnitSpinor :=
  ⟨(((3/5 : ℝ) : ℂ), ((4/5 : ℝ) : ℂ)), by norm_num [Complex.normSq_ofReal]⟩

/-- An operator commuting with the exact spin representation is scalar.
The torus separates weights and one mixing rotation connects them all to the
highest weight. No irreducibility assumption is used. -/
theorem spin_commutant_scalar {N : ℕ} (A : Operator N)
    (h : ∀ u : UnitSpinor,
      A * spinMatrix N u.val.1 u.val.2 = spinMatrix N u.val.1 u.val.2 * A) :
    ∃ c : ℂ, A = Matrix.diagonal (fun _ : Weight N => c) := by
  have htorus := h (torusSpinor (characterAngle N))
  rw [spinMatrix_torus] at htorus
  have hoff (r s : Weight N) (hrs : r ≠ s) : A r s = 0 := by
    have he := congrArg (fun B : Operator N => B r s) htorus
    simp only [Matrix.mul_diagonal, Matrix.diagonal_mul] at he
    have hd : torusWeight N (characterAngle N) s ≠ torusWeight N (characterAngle N) r :=
      fun h => hrs ((torusWeight_injective N h).symm)
    have hz : A r s * (torusWeight N (characterAngle N) s -
        torusWeight N (characterAngle N) r) = 0 := by
      linear_combination he
    exact (mul_eq_zero.mp hz).resolve_right (sub_ne_zero.mpr hd)
  have hdiag : A = Matrix.diagonal (fun r => A r r) := by
    ext r s
    rw [Matrix.diagonal_apply]
    by_cases e : r = s
    · subst s; simp
    · rw [if_neg e, hoff r s e]
  let U := spinMatrix N mixingSpinor.val.1 mixingSpinor.val.2
  have hmix : A * U = U * A := h mixingSpinor
  have hcols (r : Weight N) : A r r = A 0 0 := by
    have he := congrArg (fun B : Operator N => B r 0) hmix
    have hh : A r r * U r 0 = U r 0 * A 0 0 := by
      calc
        A r r * U r 0 = (Matrix.diagonal (fun r => A r r) * U) r 0 :=
          (Matrix.diagonal_mul ..).symm
        _ = (A * U) r 0 := by nth_rw 2 [hdiag]
        _ = (U * A) r 0 := he
        _ = (U * Matrix.diagonal (fun r => A r r)) r 0 := by nth_rw 1 [hdiag]
        _ = _ := Matrix.mul_diagonal ..
    have hn : U r 0 ≠ 0 := spinMatrix_column_zero_ne_zero N
      (by norm_num [mixingSpinor]) (by norm_num [mixingSpinor]) r
    rw [mul_comm (U r 0)] at hh
    exact mul_right_cancel₀ hn hh
  refine ⟨A 0 0, hdiag.trans ?_⟩
  exact congrArg Matrix.diagonal (funext hcols)

end F18
