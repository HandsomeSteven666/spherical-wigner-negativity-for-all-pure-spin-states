import F18.AreaRadial

namespace F18
open scoped Matrix

noncomputable instance : MetricSpace UnitSpinor := by
  unfold UnitSpinor
  infer_instance

theorem continuous_unitSpinorMul : Continuous (fun p : UnitSpinor × UnitSpinor => unitSpinorMul p.1 p.2) := by
  unfold unitSpinorMul
  apply Continuous.subtype_mk
  have hc : Continuous (starRingEnd ℂ : ℂ → ℂ) := continuous_star
  fun_prop

theorem unitSpinorInv_mul (u : UnitSpinor) : unitSpinorMul (unitSpinorInv u) u = unitSpinorOne := by
  have h : unitSpinorInv (unitSpinorInv u) = u := by
    apply Subtype.ext
    simp [unitSpinorInv]
  simpa only [h] using unitSpinorMul_inv (unitSpinorInv u)

/-- Exact unit-spinor coordinates for the conjugacy class with real part a. -/
noncomputable def spinClass (a b : ℝ) (hab : a^2+b^2 = 1) (y : Sphere) : UnitSpinor :=
  ⟨(⟨a,b*y.val.2.2⟩, ⟨-b*y.val.2.1,b*y.val.1⟩), by
    simp only [Complex.normSq_apply, pow_two, neg_mul, neg_mul_neg]
    linear_combination hab + b^2 * y.property⟩

private noncomputable def classPole (a b : ℝ) (hab : a^2+b^2 = 1) : UnitSpinor :=
  ⟨(⟨a,b⟩,0), by simpa [Complex.normSq_apply, pow_two] using hab⟩

theorem continuous_spinClass (a b : ℝ) (hab : a^2+b^2 = 1) : Continuous (spinClass a b hab) := by
  unfold spinClass
  apply Continuous.subtype_mk
  simp only [Complex.mk_eq_add_mul_I]
  fun_prop

theorem spinClass_bloch (a b : ℝ) (hab : a^2+b^2 = 1) (u : UnitSpinor) :
    spinClass a b hab (bloch u) =
      unitSpinorMul (unitSpinorMul u (classPole a b hab)) (unitSpinorInv u) := by
  apply Subtype.ext
  have h := u.property
  rw [Complex.normSq_apply, Complex.normSq_apply] at h
  apply Prod.ext <;> apply Complex.ext
  all_goals
    simp only [spinClass, bloch, unitSpinorMul, unitSpinorInv, classPole, Complex.normSq_apply,
      Complex.add_re, Complex.add_im, Complex.sub_re, Complex.sub_im, Complex.mul_re,
      Complex.mul_im, Complex.conj_re, Complex.conj_im, Complex.neg_re, Complex.neg_im,
      Complex.zero_re, Complex.zero_im]
    norm_num
    first | (ring; done) | linear_combination -a * h

theorem spinClass_rotation (a b : ℝ) (hab : a^2+b^2 = 1) (u : UnitSpinor) (y : Sphere) :
    spinClass a b hab (spinorRotation u y) =
      unitSpinorMul (unitSpinorMul u (spinClass a b hab y)) (unitSpinorInv u) := by
  let v := liftSpinor y
  have hy : bloch v = y := bloch_liftSpinor y
  have hInv : unitSpinorInv (unitSpinorMul u v) = unitSpinorMul (unitSpinorInv v) (unitSpinorInv u) := by
    apply Subtype.ext
    simp only [unitSpinorInv, unitSpinorMul, map_add, map_sub, map_mul, map_neg, Complex.conj_conj]
    congr 1 <;> ring
  rw [← hy, spinorRotation_bloch, spinClass_bloch, spinClass_bloch, hInv]
  simp only [unitSpinorMul_assoc]

theorem spinClass_antipode (a b : ℝ) (hab : a^2+b^2 = 1) (y : Sphere) :
    spinClass a b hab (sphereAntipode y) = unitSpinorInv (spinClass a b hab y) := by
  apply Subtype.ext
  apply Prod.ext <;> apply Complex.ext <;> simp [spinClass, sphereAntipode, unitSpinorInv]

theorem spinClass_torus (t : ℝ) (y : Sphere) :
    spinClass (Real.cos t) (Real.sin t) (Real.cos_sq_add_sin_sq t) y =
      unitSpinorMul (unitSpinorMul (liftSpinor y) (torusSpinor t)) (unitSpinorInv (liftSpinor y)) := by
  conv_lhs => rw [← bloch_liftSpinor y]
  rw [spinClass_bloch]
  congr 2
  apply Subtype.ext
  simp [classPole, torusSpinor, Complex.exp_mul_I]
  apply Complex.ext <;> simp [← Complex.ofReal_cos, ← Complex.ofReal_sin]


open MeasureTheory

noncomputable def spinAction (N : ℕ) (u : UnitSpinor) : Operator N :=
  spinMatrix N u.val.1 u.val.2

theorem continuous_spinAction (N : ℕ) : Continuous (spinAction N) := by
  unfold spinAction
  exact (continuous_spinMatrix N).comp continuous_subtype_val

theorem spinAction_mul (N : ℕ) (u v : UnitSpinor) :
    spinAction N (unitSpinorMul u v) = spinAction N u * spinAction N v :=
  spinMatrix_mul_unitSpinor N u v

theorem spinAction_inv (N : ℕ) (u : UnitSpinor) :
    spinAction N (unitSpinorInv u) = (spinAction N u)ᴴ :=
  spinMatrix_inv_eq_conjTranspose N u

private theorem integral_spinClass_entry_integrable (N : ℕ) (a b : ℝ)
    (hab : a^2+b^2 = 1) (i j : Weight N) :
    Integrable (fun y => spinAction N (spinClass a b hab y) i j) areaProbability := by
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  letI : IsFiniteMeasure areaProbability := ⟨by simp [areaProbability_mass]⟩
  have hc := ((continuous_spinAction N).comp (continuous_spinClass a b hab)).matrix_elem i j
  exact hc.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)

noncomputable def spinClassAverage (N : ℕ) (a b : ℝ) (hab : a^2+b^2 = 1) : Operator N :=
  operatorIntegral areaProbability (fun y => spinAction N (spinClass a b hab y))

private theorem spinClassAverage_conj (N : ℕ) (a b : ℝ) (hab : a^2+b^2 = 1)
    (u : UnitSpinor) :
    spinClassAverage N a b hab =
      spinAction N u * spinClassAverage N a b hab * (spinAction N u)ᴴ := by
  let F (y : Sphere) := spinAction N (spinClass a b hab y)
  let U := spinAction N u
  have hF : Continuous F := (continuous_spinAction N).comp (continuous_spinClass a b hab)
  have hi (i j : Weight N) : Integrable (fun y => F y i j) areaProbability :=
    integral_spinClass_entry_integrable N a b hab i j
  have hiL (i j : Weight N) : Integrable (fun y => (U * F y) i j) areaProbability := by
    simp only [Matrix.mul_apply]
    exact integrable_finset_sum _ (fun k _ => (hi k j).const_mul (U i k))
  calc
    _ = operatorIntegral areaProbability (fun y => F (spinorRotation u y)) := by
      ext i j
      unfold spinClassAverage operatorIntegral
      change (∫ y, F y i j ∂areaProbability) = _
      have hr := sphereRotationInvariant u
      rw [← integral_map hr.measurable.aemeasurable (hF.matrix_elem i j).measurable.aestronglyMeasurable,
        hr.map_eq]
    _ = operatorIntegral areaProbability (fun y => U * F y * Uᴴ) := by
      apply congrArg (operatorIntegral areaProbability)
      funext y
      simp only [F,U,spinClass_rotation,spinAction_mul,spinAction_inv]
    _ = _ := by
      rw [operatorIntegral_mul_right _ _ _ hiL, operatorIntegral_mul_left _ _ _ hi]
      rfl

private theorem spinClassAverage_selfAdjoint (N : ℕ) (a b : ℝ) (hab : a^2+b^2 = 1) :
    (spinClassAverage N a b hab)ᴴ = spinClassAverage N a b hab := by
  let F (y : Sphere) := spinAction N (spinClass a b hab y)
  have hF : Continuous F := (continuous_spinAction N).comp (continuous_spinClass a b hab)
  ext i j
  change starRingEnd ℂ (∫ y, F y j i ∂areaProbability) = ∫ y, F y i j ∂areaProbability
  rw [← integral_conj]
  have h (y : Sphere) : starRingEnd ℂ (F y j i) = F (sphereAntipode y) i j := by
    simp only [F, spinClass_antipode, spinAction_inv, Matrix.conjTranspose_apply]
    rfl
  simp_rw [h]
  have hr := sphereAntipode_preserves_area
  rw [← integral_map hr.measurable.aemeasurable (hF.matrix_elem i j).measurable.aestronglyMeasurable,
    hr.map_eq]

theorem spinClassAverage_real_scalar (N : ℕ) (a b : ℝ) (hab : a^2+b^2 = 1) :
    ∃ c : ℝ, spinClassAverage N a b hab = (c : ℂ) • (1 : Operator N) := by
  let A := spinClassAverage N a b hab
  have hc (u : UnitSpinor) : A * spinAction N u = spinAction N u * A := by
    let U := spinAction N u
    calc
      A * U = (U * A * Uᴴ) * U := congrArg (· * U) (spinClassAverage_conj N a b hab u)
      _ = U * A := by
        have hU : Uᴴ * U = 1 := spinMatrix_conjTranspose_mul_self N u
        rw [Matrix.mul_assoc _ Uᴴ U, hU, mul_one]
  obtain ⟨z,hz⟩ := spin_commutant_scalar A hc
  have h := spinClassAverage_selfAdjoint N a b hab
  change Aᴴ = A at h
  rw [hz] at h
  have he := congrArg (fun B : Operator N => B 0 0) h
  simp only [Matrix.conjTranspose_apply, Matrix.diagonal_apply_eq] at he
  have hzi : z.im = 0 := by
    have hh := congrArg Complex.im he
    change -z.im = z.im at hh
    linarith
  refine ⟨z.re,?_⟩
  change A = _
  rw [hz, show ((z.re : ℝ) : ℂ) = z by apply Complex.ext <;> simp [hzi]]
  ext i j
  by_cases hij : i = j <;> simp [Matrix.diagonal_apply, Matrix.one_apply, hij]

theorem spinClassAverage_characterAngle_zero {N : ℕ} (hN : 0 < N) :
    spinClassAverage N (Real.cos (characterAngle N)) (Real.sin (characterAngle N))
      (Real.cos_sq_add_sin_sq (characterAngle N)) = 0 := by
  let t := characterAngle N
  let A := spinClassAverage N (Real.cos t) (Real.sin t) (Real.cos_sq_add_sin_sq t)
  obtain ⟨c,hc⟩ := spinClassAverage_real_scalar N (Real.cos t) (Real.sin t) (Real.cos_sq_add_sin_sq t)
  have htr : Matrix.trace A = 0 := by
    unfold A spinClassAverage
    rw [trace_operatorIntegral _ _ (fun i => integral_spinClass_entry_integrable N _ _ _ i i)]
    have hp (y : Sphere) : Matrix.trace (spinAction N (spinClass (Real.cos t) (Real.sin t)
        (Real.cos_sq_add_sin_sq t) y)) = 0 := by
      have hu : (spinAction N (liftSpinor y))ᴴ * spinAction N (liftSpinor y) = 1 :=
        spinMatrix_conjTranspose_mul_self N (liftSpinor y)
      rw [spinClass_torus, spinAction_mul, spinAction_mul, spinAction_inv, Matrix.trace_mul_comm,
        ← Matrix.mul_assoc, hu, one_mul]
      exact spinMatrix_torus_trace_zero hN
    simp_rw [hp, integral_zero]
  change A = 0
  change A = _ at hc
  rw [hc, Matrix.trace_smul, Matrix.trace_one] at htr
  have hdim : (Fintype.card (Weight N) : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
  have hz : (c : ℂ) = 0 := (mul_eq_zero.mp (show (c:ℂ) * _ = 0 from htr)).resolve_right hdim
  rw [hc,hz,zero_smul]


theorem spinClass_re (a b : ℝ) (hab : a^2+b^2 = 1) (y : Sphere) :
    (spinClass a b hab y).val.1.re = a := rfl

theorem exists_spinClass_repr (v : UnitSpinor) :
    ∃ (a b : ℝ) (hab : a^2+b^2 = 1) (y : Sphere),
      spinClass a b hab y = v := by
  let a := v.val.1.re
  have h := v.property
  simp only [Complex.normSq_apply, ← pow_two] at h
  have h' : a^2 + (v.val.1.im^2+v.val.2.re^2+v.val.2.im^2) = 1 := by
    dsimp [a]
    linarith
  let b := Real.sqrt (v.val.1.im^2+v.val.2.re^2+v.val.2.im^2)
  have hb : b^2 = v.val.1.im^2+v.val.2.re^2+v.val.2.im^2 := Real.sq_sqrt (by positivity)
  have hab : a^2+b^2 = 1 := by rw [hb,h']
  by_cases hz : b = 0
  · have he : v.val.1.im = 0 ∧ v.val.2.re = 0 ∧ v.val.2.im = 0 := by
      rw [hz] at hb
      constructor
      · nlinarith [sq_nonneg v.val.2.re, sq_nonneg v.val.2.im]
      · constructor <;> nlinarith [sq_nonneg v.val.1.im, sq_nonneg v.val.2.re, sq_nonneg v.val.2.im]
    refine ⟨a,b,hab,northPoint,?_⟩
    apply Subtype.ext
    apply Prod.ext <;> apply Complex.ext <;> simp [spinClass, a, hz, he.1, he.2.1, he.2.2]
  · let y : Sphere := ⟨(v.val.2.im/b,-v.val.2.re/b,v.val.1.im/b),by
      dsimp
      rw [div_pow, div_pow, div_pow, neg_sq, ← add_div, ← add_div]
      apply (div_eq_one_iff_eq (pow_ne_zero 2 hz)).2
      linear_combination -hb⟩
    refine ⟨a,b,hab,y,?_⟩
    apply Subtype.ext
    apply Prod.ext <;> apply Complex.ext <;> simp [spinClass, a, y, hz] <;>
      field_simp [hz]

theorem spinor_dist_one_le (v : UnitSpinor) (δ : ℝ) (hδ : 0 < δ)
    (h : 1-δ^2/2 < v.val.1.re) : dist v unitSpinorOne < δ := by
  have he : ‖v.val.1-1‖^2 + ‖v.val.2‖^2 = 2*(1-v.val.1.re) := by
    rw [Complex.sq_norm, Complex.sq_norm]
    have h := v.property
    simp only [Complex.normSq_apply, Complex.sub_re, Complex.sub_im, Complex.one_re,
      Complex.one_im, sub_zero] at h ⊢
    linear_combination h
  change dist v.val ((1,0) : ℂ × ℂ) < δ
  rw [Prod.dist_eq, max_lt_iff, dist_eq_norm, dist_zero_right]
  constructor <;> nlinarith [sq_nonneg ‖v.val.1-1‖, sq_nonneg ‖v.val.2‖,
    norm_nonneg (v.val.1-1),norm_nonneg v.val.2]

end F18
