import F18.Geometry
import F18.Phase
import Mathlib.Tactic.FunProp

namespace F18

/-- A unit spinor represents a point of the exact Cartesian sphere in F18. -/
def UnitSpinor :=
  {ab : ℂ × ℂ // Complex.normSq ab.1 + Complex.normSq ab.2 = 1}

/-- The original section, now regarded as a unit spinor. -/
noncomputable def liftSpinor (p : Sphere) : UnitSpinor :=
  ⟨spinor p, spinor_unit p⟩

/-- The Bloch projection identifies common unit phases. -/
noncomputable def bloch (u : UnitSpinor) : Sphere :=
  let c := 2 * starRingEnd ℂ u.val.1 * u.val.2
  ⟨(c.re, c.im, Complex.normSq u.val.1 - Complex.normSq u.val.2), by
    have h : Complex.normSq c =
        4 * Complex.normSq u.val.1 * Complex.normSq u.val.2 := by
      simp [c, Complex.normSq_mul, Complex.normSq_conj, Complex.normSq_ofNat, mul_assoc]
      ring
    have he : c.re ^ 2 + c.im ^ 2 = Complex.normSq c := by
      rw [Complex.normSq_apply, pow_two, pow_two]
    change c.re ^ 2 + c.im ^ 2 + (Complex.normSq u.val.1 - Complex.normSq u.val.2) ^ 2 = 1
    rw [he, h]
    calc
      _ = (Complex.normSq u.val.1 + Complex.normSq u.val.2) ^ 2 := by ring
      _ = 1 := by rw [u.property]; norm_num⟩

theorem bloch_liftSpinor (p : Sphere) : bloch (liftSpinor p) = p := by
  apply Subtype.ext
  have he := spinor_equator p
  have hA := (spinor_norms p).1
  have hB := (spinor_norms p).2
  change ((2 * starRingEnd ℂ (spinor p).1 * (spinor p).2).re,
    (2 * starRingEnd ℂ (spinor p).1 * (spinor p).2).im,
    Complex.normSq (spinor p).1 - Complex.normSq (spinor p).2) = p.val
  have hZ : (1 + p.val.2.2) / 2 - (1 - p.val.2.2) / 2 = p.val.2.2 := by ring
  rw [he, hA, hB, hZ]
  simp

theorem kernel_bloch (N : ℕ) (signs : Weight N → Bool) (u : UnitSpinor) :
    kernel N signs (bloch u) = kernelFromSpinor N signs u.val.1 u.val.2 := by
  rw [kernel_eq_kernelFromSpinor]
  symm
  refine kernelFromSpinor_bloch_eq N signs (spinor (bloch u)).1 (spinor (bloch u)).2
    u.val.1 u.val.2 (spinor_unit (bloch u)) u.property ?_ ?_
  · rw [(spinor_norms (bloch u)).1]
    change (1 + (Complex.normSq u.val.1 - Complex.normSq u.val.2)) / 2 =
      Complex.normSq u.val.1
    linarith [u.property]
  · have he := spinor_equator (bloch u)
    have hc (c : ℂ) : (c.re : ℂ) + (c.im : ℂ) * Complex.I = c := by
      apply Complex.ext <;> simp
    change 2 * starRingEnd ℂ (spinor (bloch u)).1 * (spinor (bloch u)).2 =
      (((2 * starRingEnd ℂ u.val.1 * u.val.2).re : ℝ) : ℂ) +
      (((2 * starRingEnd ℂ u.val.1 * u.val.2).im : ℝ) : ℂ) * Complex.I at he
    rw [hc] at he
    linear_combination he / 2


/-- The first column of the product of two SU(2) matrices in the spinor
convention of the manuscript. -/
noncomputable def unitSpinorMul (u v : UnitSpinor) : UnitSpinor :=
  ⟨(u.val.1 * v.val.1 - starRingEnd ℂ u.val.2 * v.val.2,
    u.val.2 * v.val.1 + starRingEnd ℂ u.val.1 * v.val.2), by
    calc
      _ = (Complex.normSq u.val.1 + Complex.normSq u.val.2) *
          (Complex.normSq v.val.1 + Complex.normSq v.val.2) := by
        simp only [Complex.normSq_apply, Complex.add_re, Complex.add_im, Complex.sub_re,
          Complex.sub_im, Complex.mul_re, Complex.mul_im, Complex.conj_re, Complex.conj_im]
        ring
      _ = 1 := by rw [u.property, v.property, mul_one]⟩

noncomputable def unitSpinorInv (u : UnitSpinor) : UnitSpinor :=
  ⟨(starRingEnd ℂ u.val.1, -u.val.2), by
    change Complex.normSq (starRingEnd ℂ u.val.1) + Complex.normSq (-u.val.2) = 1
    simpa [Complex.normSq_apply] using u.property⟩

def unitSpinorOne : UnitSpinor := ⟨(1,0), by norm_num⟩

theorem unitSpinorMul_one (u : UnitSpinor) : unitSpinorMul u unitSpinorOne = u := by
  apply Subtype.ext
  simp [unitSpinorMul, unitSpinorOne]

theorem unitSpinorMul_inv (u : UnitSpinor) : unitSpinorMul u (unitSpinorInv u) = unitSpinorOne := by
  apply Subtype.ext
  have hu : (Complex.normSq u.val.1 : ℂ) + (Complex.normSq u.val.2 : ℂ) = 1 := by
    exact_mod_cast u.property
  change (u.val.1 * starRingEnd ℂ u.val.1 - starRingEnd ℂ u.val.2 * (-u.val.2),
    u.val.2 * starRingEnd ℂ u.val.1 + starRingEnd ℂ u.val.1 * (-u.val.2)) = (1,0)
  rw [Complex.mul_conj, mul_neg, sub_neg_eq_add, mul_comm (starRingEnd ℂ u.val.2) u.val.2,
    Complex.mul_conj, hu]
  congr 1
  ring

theorem unitSpinorMul_assoc (u v w : UnitSpinor) :
    unitSpinorMul (unitSpinorMul u v) w = unitSpinorMul u (unitSpinorMul v w) := by
  apply Subtype.ext
  simp only [unitSpinorMul, map_add, map_sub, map_mul, Complex.conj_conj]
  congr 1 <;> ring


def sphereDot (p q : Sphere) : ℝ :=
  p.val.1*q.val.1 + p.val.2.1*q.val.2.1 + p.val.2.2*q.val.2.2

noncomputable def spinorInner (u v : UnitSpinor) : ℂ :=
  starRingEnd ℂ u.val.1 * v.val.1 + starRingEnd ℂ u.val.2 * v.val.2

theorem spinorInner_left_mul (a u v : UnitSpinor) :
    spinorInner (unitSpinorMul a u) (unitSpinorMul a v) = spinorInner u v := by
  have ha : (Complex.normSq a.val.1 : ℂ) + (Complex.normSq a.val.2 : ℂ) = 1 := by
    exact_mod_cast a.property
  calc
    _ = spinorInner u v *
        (a.val.1 * starRingEnd ℂ a.val.1 + a.val.2 * starRingEnd ℂ a.val.2) := by
      simp only [spinorInner, unitSpinorMul, map_add, map_sub, map_mul, Complex.conj_conj]
      ring
    _ = _ := by rw [Complex.mul_conj, Complex.mul_conj, ha, mul_one]

theorem sphereDot_bloch (u v : UnitSpinor) :
    sphereDot (bloch u) (bloch v) = 2 * Complex.normSq (spinorInner u v) - 1 := by
  calc
    _ = 2 * Complex.normSq (spinorInner u v) -
        (Complex.normSq u.val.1 + Complex.normSq u.val.2) *
          (Complex.normSq v.val.1 + Complex.normSq v.val.2) := by
      simp only [sphereDot, bloch, spinorInner, Complex.normSq_apply, Complex.add_re,
        Complex.add_im, Complex.mul_re, Complex.mul_im, Complex.conj_re, Complex.conj_im]
      norm_num
      ring
    _ = _ := by rw [u.property, v.property, mul_one]

theorem sphereDot_self (p : Sphere) : sphereDot p p = 1 := by
  simpa [sphereDot, pow_two] using p.property

theorem eq_of_sphereDot_eq_one {p q : Sphere} (h : sphereDot p q = 1) : p = q := by
  rcases p with ⟨⟨x,y,z⟩,hp⟩
  rcases q with ⟨⟨a,b,c⟩,hq⟩
  change x^2 + y^2 + z^2 = 1 at hp
  change a^2 + b^2 + c^2 = 1 at hq
  change x*a + y*b + z*c = 1 at h
  have hh : (x-a)^2 + (y-b)^2 + (z-c)^2 = 0 := by nlinarith
  have hxa : x=a := by nlinarith [sq_nonneg (y-b), sq_nonneg (z-c)]
  have hyb : y=b := by nlinarith [sq_nonneg (x-a), sq_nonneg (z-c)]
  have hzc : z=c := by nlinarith [sq_nonneg (x-a), sq_nonneg (y-b)]
  exact Subtype.ext (by simp [hxa,hyb,hzc])

/-- The induced action on the original Cartesian sphere. -/
noncomputable def spinorRotation (u : UnitSpinor) (p : Sphere) : Sphere :=
  bloch (unitSpinorMul u (liftSpinor p))

theorem spinorRotation_bloch (a u : UnitSpinor) :
    spinorRotation a (bloch u) = bloch (unitSpinorMul a u) := by
  apply eq_of_sphereDot_eq_one
  unfold spinorRotation
  rw [sphereDot_bloch, spinorInner_left_mul, ← sphereDot_bloch, bloch_liftSpinor, sphereDot_self]

theorem spinorRotation_dot (u : UnitSpinor) (p q : Sphere) :
    sphereDot (spinorRotation u p) (spinorRotation u q) = sphereDot p q := by
  unfold spinorRotation
  rw [sphereDot_bloch, spinorInner_left_mul, ← sphereDot_bloch, bloch_liftSpinor, bloch_liftSpinor]

theorem spinorRotation_comp (u v : UnitSpinor) (p : Sphere) :
    spinorRotation u (spinorRotation v p) = spinorRotation (unitSpinorMul u v) p := by
  change spinorRotation u (bloch (unitSpinorMul v (liftSpinor p))) = _
  rw [spinorRotation_bloch, ← unitSpinorMul_assoc]
  rfl

theorem spinorRotation_bloch_one (u : UnitSpinor) :
    spinorRotation u (bloch unitSpinorOne) = bloch u := by
  rw [spinorRotation_bloch, unitSpinorMul_one]


theorem unitSpinor_one_mul (u : UnitSpinor) : unitSpinorMul unitSpinorOne u = u := by
  apply Subtype.ext
  simp [unitSpinorMul, unitSpinorOne]

theorem spinorRotation_one (p : Sphere) : spinorRotation unitSpinorOne p = p := by
  unfold spinorRotation
  rw [unitSpinor_one_mul, bloch_liftSpinor]

theorem spinorRotation_inv_right (u : UnitSpinor) (p : Sphere) :
    spinorRotation u (spinorRotation (unitSpinorInv u) p) = p := by
  rw [spinorRotation_comp, unitSpinorMul_inv, spinorRotation_one]

theorem continuous_sphereDot_left (q : Sphere) : Continuous (fun p => sphereDot p q) := by
  unfold sphereDot
  fun_prop

private def axisX : Sphere := ⟨(1,0,0), by norm_num⟩
private def axisY : Sphere := ⟨(0,1,0), by norm_num⟩
private def axisZ : Sphere := ⟨(0,0,1), by norm_num⟩

/-- Dot preservation reconstructs all three coordinates from fixed dot
products, even where the chosen spinor section is discontinuous. -/
theorem continuous_spinorRotation (u : UnitSpinor) : Continuous (spinorRotation u) := by
  let v := unitSpinorInv u
  have h (p q : Sphere) : sphereDot (spinorRotation u p) q =
      sphereDot p (spinorRotation v q) := by
    conv_lhs => rw [← spinorRotation_inv_right u q]
    exact spinorRotation_dot u p (spinorRotation v q)
  have he (p : Sphere) : (spinorRotation u p).val =
      (sphereDot p (spinorRotation v axisX),
       sphereDot p (spinorRotation v axisY),
       sphereDot p (spinorRotation v axisZ)) := by
    rw [← h, ← h, ← h]
    simp [sphereDot, axisX, axisY, axisZ]
  apply Topology.IsInducing.subtypeVal.continuous_iff.mpr
  change Continuous (fun p => (spinorRotation u p).val)
  simp_rw [he]
  exact (continuous_sphereDot_left _).prodMk
    ((continuous_sphereDot_left _).prodMk (continuous_sphereDot_left _))

end F18
