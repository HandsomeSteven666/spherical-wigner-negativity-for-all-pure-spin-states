import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.Topology.Closure
import Mathlib.Tactic.Push

/-! The completed, generic analytic step in the manuscript's contradiction.
Its input facts are explicit obligations, not extra hypotheses on OriginalF18. -/
namespace F18
open MeasureTheory Set

theorem negative_of_rotated_zero_overlap
    {X : Type*} [TopologicalSpace X] [MeasurableSpace X]
    (μ : Measure X) [Measure.IsOpenPosMeasure μ]
    (u v : X → ℝ) (rotate : X → X)
    (hu : Continuous u) (hv : Continuous v)
    (hcov : ∀ x, v x = u (rotate x))
    (hpoint : ∃ x, u x ≠ 0)
    (hunique : Dense {x | v x ≠ 0})
    (hint : Integrable (fun x => u x * v x) μ)
    (hoverlap : ∫ x, u x * v x ∂μ = 0) :
    ∃ x, u x < 0 := by
  by_contra hn
  push_neg at hn
  have hvn (x : X) : 0 ≤ v x := hcov x ▸ hn (rotate x)
  obtain ⟨x, hx⟩ := hpoint
  have hOpen : IsOpen {x : X | 0 < u x} := isOpen_lt continuous_const hu
  have hNE : Set.Nonempty {x : X | 0 < u x} :=
    ⟨x, lt_of_le_of_ne (hn x) (Ne.symm hx)⟩
  obtain ⟨y, hy, hyv⟩ := hunique.inter_open_nonempty _ hOpen hNE
  have hyu : 0 < u y := hy
  have hyv' : 0 < v y := lt_of_le_of_ne (hvn y) (Ne.symm hyv)
  have hpos : 0 < ∫ x, u x * v x ∂μ :=
    integral_pos_of_integrable_nonneg_nonzero (hu.mul hv) hint
      (fun x => mul_nonneg (hn x) (hvn x)) (ne_of_gt (mul_pos hyu hyv'))
  exact (ne_of_gt hpos) hoverlap

end F18
