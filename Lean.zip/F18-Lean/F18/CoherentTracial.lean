import F18.CoherentExt
import F18.ClosingAssembly

namespace F18
open MeasureTheory

private noncomputable def symbol {N : ℕ} (signs : Weight N → Bool)
    (A : Operator N) (p : Sphere) : ℂ :=
  Matrix.trace (A * kernel N signs p)

private theorem continuous_symbol {N : ℕ} (signs : Weight N → Bool) (A : Operator N) :
    Continuous (symbol signs A) := by
  unfold symbol Matrix.trace Matrix.diag
  exact continuous_finset_sum _ fun i _ =>
    (continuous_const.matrix_mul (continuous_kernel N signs)).matrix_elem i i

private theorem integrable_symbol_product {N : ℕ}
    (signs : Weight N → Bool) (A B : Operator N) :
    Integrable (fun p => symbol signs A p * symbol signs B p) (spinMeasure N) := by
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  exact ((continuous_symbol signs A).mul (continuous_symbol signs B)).integrable_of_hasCompactSupport
    (HasCompactSupport.of_compactSpace _)

private noncomputable def defect {N : ℕ} (signs : Weight N → Bool) (A B : Operator N) : ℂ :=
  (∫ p, symbol signs A p * symbol signs B p ∂spinMeasure N) - Matrix.trace (A * B)

private theorem defect_comm {N : ℕ} (signs : Weight N → Bool) (A B : Operator N) :
    defect signs A B = defect signs B A := by
  unfold defect
  rw [Matrix.trace_mul_comm A B]
  simp only [mul_comm]

private noncomputable def defectLinear {N : ℕ} (signs : Weight N → Bool)
    (B : Operator N) : Operator N →ₗ[ℂ] ℂ where
  toFun A := defect signs A B
  map_add' A C := by
    unfold defect symbol
    simp only [Matrix.add_mul, Matrix.trace_add, add_mul]
    have hiA := integrable_symbol_product signs A B
    have hiC := integrable_symbol_product signs C B
    unfold symbol at hiA hiC
    rw [integral_add hiA hiC]
    ring
  map_smul' c A := by
    unfold defect symbol
    simp only [Matrix.smul_mul, Matrix.trace_smul, smul_eq_mul, RingHom.id_apply, mul_assoc,
      integral_const_mul]
    ring

private theorem defect_projectors {N : ℕ} (signs : Weight N → Bool) (ψ φ : State N) :
    defect signs (projector ψ) (projector φ) =
      ((∫ p, wigner signs ψ p * wigner signs φ p ∂spinMeasure N : ℝ) : ℂ) -
        Matrix.trace (projector ψ * projector φ) := by
  unfold defect symbol
  simp_rw [complex_trace_eq_wigner, ← Complex.ofReal_mul, integral_complex_ofReal]

/-- Checking the coherent-pair overlap suffices for full traciality for the
original symbols. The extension is by two exact linear-functional tests. -/
theorem spinWignerTracial_of_coherent
    (h : ∀ (N : ℕ) (signs : Weight N → Bool) (u v : UnitSpinor),
      ((∫ p, wigner signs (coherentVec N u.val) p *
        wigner signs (coherentVec N v.val) p ∂spinMeasure N : ℝ) : ℂ) =
      Matrix.trace (projector (coherentVec N u.val) * projector (coherentVec N v.val))) :
    SpinWignerTracial := by
  intro N signs ψ φ
  have h₁ (u v : UnitSpinor) :
      defect signs (projector (coherentVec N u.val)) (projector (coherentVec N v.val)) = 0 := by
    rw [defect_projectors, h N signs u v, sub_self]
  have h₂ (v : UnitSpinor) (A : Operator N) :
      defect signs A (projector (coherentVec N v.val)) = 0 :=
    linear_ext_coherent_projectors (defectLinear signs (projector (coherentVec N v.val)))
      (fun u => h₁ u v) A
  have h₃ (A B : Operator N) : defect signs A B = 0 := by
    rw [defect_comm signs A B]
    exact linear_ext_coherent_projectors (defectLinear signs A) (fun v => by
      change defect signs (projector (coherentVec N v.val)) A = 0
      rw [defect_comm signs _ A]
      exact h₂ v A) B
  exact sub_eq_zero.mp ((defect_projectors signs ψ φ).symm.trans (h₃ _ _))

end F18
