import F18.ShiftedLegendre
import F18.SphereLog

open scoped Polynomial
namespace F18
open Polynomial

/-- The even and odd parts in the radial factor, reduced modulo R² = S. -/
private noncomputable def radialParts {K : Type*} [CommRing K]
    (A S : K[X]) (b : K) : ℕ → K[X] × K[X]
  | 0 => (1, 0)
  | k+1 =>
    let (E, O) := radialParts A S b k
    (A*E + S*C b*O, C b*E + A*O)

private theorem radialParts_eval {K : Type*} [CommRing K]
    (A S : K[X]) (b t r : K) (hr : r^2 = S.eval t) (k : ℕ) :
    (A.eval t + r*b)^k = (radialParts A S b k).1.eval t +
      r*(radialParts A S b k).2.eval t := by
  induction k with
  | zero => simp [radialParts]
  | succ k ih =>
    rw [pow_succ, ih]
    simp only [radialParts, eval_add, eval_mul, eval_C, ← hr]
    ring

private theorem radialParts_degree (A S : ℝ[X]) (b : ℝ)
    (hA : A.natDegree ≤ 1) (hS : S.natDegree ≤ 2) (k : ℕ) :
    (radialParts A S b k).1.natDegree ≤ k ∧ (radialParts A S b k).2.natDegree ≤ k-1 := by
  induction k with
  | zero => simp [radialParts]
  | succ k ih =>
    cases k with
    | zero =>
      simp [radialParts]
      exact hA
    | succ j =>


      let E := (radialParts A S b (j+1)).1
      let O := (radialParts A S b (j+1)).2
      have h₀ : E.natDegree ≤ j+1 := ih.1
      have h₁ : O.natDegree ≤ j+1-1 := ih.2
      change (A*E + S*C b*O).natDegree ≤ j+1+1 ∧
        (C b*E + A*O).natDegree ≤ j+1+1-1
      have hb := natDegree_C_mul_le b E
      have hsb := natDegree_mul_le (p := S) (q := C b)
      rw [natDegree_C, add_zero] at hsb
      constructor <;> apply natDegree_add_le_of_degree_le
      · exact natDegree_mul_le.trans (by omega)
      · exact natDegree_mul_le.trans (by omega)
      · exact hb.trans (by omega)
      · exact natDegree_mul_le.trans (by omega)

private theorem radialParts_map {K L : Type*} [CommRing K] [CommRing L]
    (f : K →+* L) (A S : K[X]) (b : K) (k : ℕ) :
    (map f (radialParts A S b k).1, map f (radialParts A S b k).2) =
      radialParts (map f A) (map f S) (f b) k := by
  induction k with
  | zero => simp [radialParts]
  | succ k ih =>
    have h₁ := congrArg Prod.fst ih
    have h₂ := congrArg Prod.snd ih
    simp only [Prod.fst, Prod.snd] at h₁ h₂
    simp only [radialParts, Polynomial.map_add, Polynomial.map_mul, map_C, h₁, h₂]

/-- Averaging the two signs of the radial factor is evaluation of a polynomial
of no higher degree than the input. -/
private noncomputable def radialEven {K : Type*} [CommRing K]
    (Q A S : K[X]) (b : K) (k : ℕ) : K[X] :=
  ∑ j ∈ Finset.range (k+1), C (Q.coeff j) * (radialParts A S b j).1

private theorem radialEven_map {K L : Type*} [CommRing K] [CommRing L]
    (f : K →+* L) (Q A S : K[X]) (b : K) (k : ℕ) :
    map f (radialEven Q A S b k) = radialEven (map f Q) (map f A) (map f S) (f b) k := by
  simp only [radialEven, Polynomial.map_sum, Polynomial.map_mul, map_C, coeff_map]
  apply Finset.sum_congr rfl
  intro j _
  rw [show map f (radialParts A S b j).1 = _ from congrArg Prod.fst (radialParts_map f A S b j)]

private theorem radialEven_degree (Q A S : ℝ[X]) (b : ℝ)
    (hA : A.natDegree ≤ 1) (hS : S.natDegree ≤ 2) (k : ℕ) :
    (radialEven Q A S b k).natDegree ≤ k := by
  unfold radialEven
  apply natDegree_sum_le_of_forall_le
  intro j hj
  exact (natDegree_C_mul_le _ _).trans ((radialParts_degree A S b hA hS j).1.trans
    (Nat.le_of_lt_succ (Finset.mem_range.mp hj)))

private theorem eval_bounded_expansion (Q : ℝ[X]) (t : ℝ) {k : ℕ}
    (hQ : Q.natDegree ≤ k) :
    Q.eval t = ∑ j ∈ Finset.range (k+1), Q.coeff j * t^j := by
  conv_lhs => rw [Q.as_sum_range_C_mul_X_pow]
  simp only [eval_finset_sum, eval_mul, eval_C, eval_pow, eval_X]
  apply Finset.sum_subset (Finset.range_mono (by omega))
  intro j hj hj'
  have h : ¬ j < Q.natDegree+1 := fun hjlt => hj' (Finset.mem_range.mpr hjlt)
  rw [coeff_eq_zero_of_natDegree_lt (by omega), zero_mul]

private theorem radialEven_eval (Q A S : ℝ[X]) (b t r : ℝ)
    (hr : r^2 = S.eval t) (k : ℕ) (hQ : Q.natDegree ≤ k) :
    (radialEven Q A S b k).eval t =
      (Q.eval (A.eval t + r*b) + Q.eval (A.eval t - r*b))/2 := by
  rw [eval_bounded_expansion Q (A.eval t + r*b) hQ,
    eval_bounded_expansion Q (A.eval t - r*b) hQ, ← Finset.sum_add_distrib]
  unfold radialEven
  simp only [eval_finset_sum, eval_mul, eval_C]
  rw [div_eq_mul_inv, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro j _
  rw [radialParts_eval A S b t r hr, sub_eq_add_neg,
    show -(r*b) = (-r)*b by ring,
    radialParts_eval A S b t (-r) (by simpa using hr)]
  ring


open MeasureTheory Set

/-- Integrating the even part coefficient by coefficient gives a polynomial
in the polar coordinate. The scalar azimuth coefficient need only be continuous. -/
theorem azimuth_even_integral_polynomial (Q A S : ℝ[X])
    (B : ℝ → ℝ) (hB : Continuous B) (b₀ b₁ : ℝ)
    {k : ℕ} (hQ : Q.natDegree ≤ k) (hA : A.natDegree ≤ 1) (hS : S.natDegree ≤ 2) :
    ∃ P : ℝ[X], P.natDegree ≤ k ∧ ∀ (t r : ℝ), r^2 = S.eval t →
      P.eval t = ∫ φ in b₀..b₁,
        (Q.eval (A.eval t + r*B φ) + Q.eval (A.eval t - r*B φ))/2 := by
  let Pφ (φ : ℝ) := radialEven Q A S (B φ) k
  let emb := C (R := ℝ)
  let polyB := radialEven (map emb Q) (map emb A) (map emb S) (X : ℝ[X]) k
  have hPφ (φ : ℝ) : map (evalRingHom (B φ)) polyB = Pφ φ := by
    unfold polyB Pφ
    rw [radialEven_map]
    have h (T : ℝ[X]) : map (evalRingHom (B φ)) (map emb T) = T := by
      rw [map_map]
      have he : (evalRingHom (B φ)).comp emb = RingHom.id ℝ := by
        ext z
        simp [emb]
      rw [he, map_id]
    simp only [h]; congr 1; exact eval_X
  have hc (j : ℕ) : Continuous (fun φ => (Pφ φ).coeff j) := by
    convert (polyB.coeff j).continuous.comp hB using 1
    ext φ
    rw [← hPφ, coeff_map]
    rfl
  let c (j : ℕ) := ∫ φ in b₀..b₁, (Pφ φ).coeff j
  refine ⟨∑ j ∈ Finset.range (k+1), C (c j) * X^j, ?_, ?_⟩
  · apply natDegree_sum_le_of_forall_le
    intro j hj
    exact (natDegree_C_mul_X_pow_le (c j) j).trans
      (Nat.le_of_lt_succ (Finset.mem_range.mp hj))
  · intro t r hr
    simp only [eval_finset_sum, eval_mul, eval_C, eval_pow, eval_X]
    simp_rw [← radialEven_eval Q A S _ t r hr k hQ]
    change _ = ∫ φ in b₀..b₁, (Pφ φ).eval t
    simp_rw [fun φ => eval_bounded_expansion (Pφ φ) t (radialEven_degree Q A S (B φ) hA hS k)]
    rw [intervalIntegral.integral_finset_sum]
    · simp_rw [intervalIntegral.integral_mul_const]; rfl
    · intro j _
      exact ((hc j).mul continuous_const).intervalIntegrable _ _


/-- The normalized azimuth mean of any zonal polynomial in the original
sphere chart is again a bounded-degree polynomial in normalized latitude. -/
theorem zonal_azimuth_polynomial (Q : ℝ[X]) (y : Sphere) :
    ∃ P : ℝ[X], P.natDegree ≤ Q.natDegree ∧ ∀ t ∈ Icc (0 : ℝ) 1,
      P.eval t = (2*Real.pi)⁻¹ * ∫ φ in (0:ℝ)..(2*Real.pi),
        Q.eval ((1-sphereDot y (unitPolarChart (φ,t)))/2) := by
  let A : ℝ[X] := C ((1-y.val.2.2)/2) + C y.val.2.2 * X
  let S : ℝ[X] := 1-(1-C 2 * X)^2
  let B (φ : ℝ) := -(y.val.1 * Real.cos φ + y.val.2.1 * Real.sin φ)/2
  have hB : Continuous B := by unfold B; fun_prop
  have hA : A.natDegree ≤ 1 := by
    apply natDegree_add_le_of_degree_le
    · simp
    · exact (natDegree_C_mul_le _ _).trans (by simp)
  have hS : S.natDegree ≤ 2 := by
    unfold S
    have he : ((1 : ℝ[X])-C 2*X).natDegree ≤ 1 :=
      (natDegree_sub_le _ _).trans (max_le (by simp)
        ((natDegree_C_mul_le _ _).trans (by simp)))
    exact (natDegree_sub_le _ _).trans (max_le (by simp)
      (natDegree_pow_le.trans (by omega)))
  obtain ⟨P,hP,hE⟩ := azimuth_even_integral_polynomial Q A S B hB 0 (2*Real.pi)
    le_rfl hA hS
  refine ⟨C ((2*Real.pi)⁻¹) * P, (natDegree_C_mul_le _ _).trans hP, ?_⟩
  intro t ht
  have ht' : (1-2*t)^2 ≤ 1 := by
    have h₀ := ht.1
    have h₁ := ht.2
    nlinarith [mul_nonneg h₀ (sub_nonneg.mpr h₁)]
  let r := Real.sqrt (1-(1-2*t)^2)
  have hr : r^2 = S.eval t := by
    rw [show r^2 = 1-(1-2*t)^2 from Real.sq_sqrt (sub_nonneg.mpr ht')]
    simp [S]
  let F (φ : ℝ) := Q.eval (A.eval t + r*B φ)
  let G (φ : ℝ) := Q.eval (A.eval t - r*B φ)
  have hchart (φ : ℝ) :
      (1-sphereDot y (unitPolarChart (φ,t)))/2 = A.eval t + r*B φ := by
    unfold unitPolarChart sphereDot
    rw [sphereChart_val ht']
    simp only [A, eval_add, eval_mul, eval_C, eval_X]
    dsimp [B, r]
    ring
  have hshift (φ : ℝ) : F (φ+Real.pi) = G φ := by
    unfold F G B
    rw [Real.cos_add_pi, Real.sin_add_pi]
    congr 1
    ring
  have hper : Function.Periodic F (2*Real.pi) := by
    intro φ
    simp [F, B, Real.cos_add_two_pi, Real.sin_add_two_pi]
  have hEq : (∫ φ in (0:ℝ)..(2*Real.pi), G φ) = ∫ φ in (0:ℝ)..(2*Real.pi), F φ := by
    simp_rw [← hshift]
    rw [intervalIntegral.integral_comp_add_right F Real.pi]
    simpa [add_comm (2*Real.pi) Real.pi] using
      (hper.intervalIntegral_add_eq_of_pos (by positivity : 0 < 2*Real.pi) 0 Real.pi).symm
  have hiF : Continuous F := Q.continuous.comp (continuous_const.add (continuous_const.mul hB))
  have hiG : Continuous G := Q.continuous.comp (continuous_const.sub (continuous_const.mul hB))
  simp only [eval_mul, eval_C, hchart]
  rw [hE t r hr]
  change _ * (∫ φ in (0:ℝ)..(2*Real.pi), (F φ+G φ)/2) = _
  rw [intervalIntegral.integral_div, intervalIntegral.integral_add
    (hiF.intervalIntegrable _ _) (hiG.intervalIntegrable _ _), hEq]
  ring


noncomputable def axisPolynomial (Q : ℝ[X]) (y p : Sphere) : ℝ :=
  Q.eval ((1-sphereDot y p)/2)

theorem continuous_axisPolynomial (Q : ℝ[X]) (y : Sphere) :
    Continuous (axisPolynomial Q y) :=
  Q.continuous.comp (by unfold sphereDot; fun_prop)

theorem unitPolarChart_north_param (t φ : ℝ) (ht : t ∈ Icc (0:ℝ) 1) :
    (1-sphereDot northPoint (unitPolarChart (φ,t)))/2 = t := by
  have h₀ := ht.1
  have h₁ := ht.2
  have ht' : (1-2*t)^2 ≤ 1 := by
    nlinarith [mul_nonneg h₀ (sub_nonneg.mpr h₁)]
  unfold unitPolarChart sphereDot
  rw [sphereChart_val ht']
  norm_num [northPoint]

/-- Profile of the angular average and its pairing with every north-axis
test polynomial, using the original polar area definition. -/
theorem north_axisPolynomial_pairing (Q : ℝ[X]) (y : Sphere) :
    ∃ P : ℝ[X], P.natDegree ≤ Q.natDegree ∧ P.eval 0 = axisPolynomial Q y northPoint ∧
      ∀ R : ℝ[X], (∫ p, axisPolynomial R northPoint p * axisPolynomial Q y p ∂areaProbability) =
        polynomialIntegral (R*P) := by
  obtain ⟨P,hD,hP⟩ := zonal_azimuth_polynomial Q y
  have hπ : 0 < 2*Real.pi := by positivity
  refine ⟨P,hD,?_,?_⟩
  · rw [hP 0 (by simp)]
    simp only [unitPolarChart, mul_zero, sub_zero, sphereChart_north]
    change (2*Real.pi)⁻¹ * (∫ _ in (0:ℝ)..(2*Real.pi), axisPolynomial Q y northPoint) = _
    rw [intervalIntegral.integral_const, sub_zero, smul_eq_mul, ← mul_assoc,
      inv_mul_cancel₀ hπ.ne', one_mul]
  · intro R
    let f : Sphere → ℝ := fun p => axisPolynomial R northPoint p * axisPolynomial Q y p
    let μ := azimuthMeasure.prod polarUnitMeasure
    have hf : Continuous f := (continuous_axisPolynomial ..).mul (continuous_axisPolynomial ..)
    letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
    letI : IsFiniteMeasure areaProbability := ⟨by simp [areaProbability_mass]⟩
    have hi : Integrable f areaProbability := hf.integrable_of_hasCompactSupport
      (HasCompactSupport.of_compactSpace _)
    rw [areaProbability_unitPolarChart, integrable_smul_measure
      (by positivity : ENNReal.ofReal ((2*Real.pi)⁻¹) ≠ 0) ENNReal.ofReal_ne_top] at hi
    have hi' : Integrable (f ∘ unitPolarChart) μ :=
      (integrable_map_measure hf.measurable.aestronglyMeasurable
        measurable_unitPolarChart.aemeasurable).mp hi
    change (∫ p, f p ∂areaProbability) = _
    rw [areaProbability_unitPolarChart, integral_smul_measure,
      integral_map measurable_unitPolarChart.aemeasurable hf.measurable.aestronglyMeasurable,
      ENNReal.toReal_ofReal (by positivity), smul_eq_mul]
    rw [integral_prod_symm _ (show Integrable (fun q => f (unitPolarChart q))
      (azimuthMeasure.prod polarUnitMeasure) from hi')]
    unfold polynomialIntegral
    simp_rw [eval_mul]
    rw [← integral_restrict_eq_interval (by norm_num : (0:ℝ) ≤ 1), ← integral_const_mul]
    apply integral_congr_ae
    filter_upwards [ae_restrict_mem (μ := volume) (s := Icc (0:ℝ) 1) measurableSet_Icc] with t ht
    change (2*Real.pi)⁻¹ * (∫ φ, f (unitPolarChart (φ,t)) ∂azimuthMeasure) =
      R.eval t * P.eval t
    have hφ (φ : ℝ) : f (unitPolarChart (φ,t)) =
        R.eval t * axisPolynomial Q y (unitPolarChart (φ,t)) := by
      simp only [f, axisPolynomial]
      rw [unitPolarChart_north_param t φ ht]
    simp_rw [hφ, integral_const_mul]
    rw [show azimuthMeasure = volume.restrict (Icc 0 (2*Real.pi)) from rfl,
      integral_restrict_eq_interval hπ.le, hP t ht]
    simp only [axisPolynomial]
    ring

end F18
