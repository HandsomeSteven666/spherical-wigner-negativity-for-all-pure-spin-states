import F18.LinearLog
import Mathlib.MeasureTheory.Function.SpecialFunctions.Basic
import Mathlib.Tactic.FunProp

namespace F18
open MeasureTheory Set

private theorem integrable_real_log_affine (a : ℝ) :
    IntervalIntegrable (fun s : ℝ => Real.log |1 - a * s|) volume 0 1 := by
  simp only [Real.log_abs]
  by_cases ha : a = 0
  · simp [ha]
  have hi : IntervalIntegrable Real.log volume 1 (1 - a) := intervalIntegral.intervalIntegrable_log'
  have h2 := (hi.comp_sub_left 1).comp_mul_left a
  simpa [ha] using h2

private theorem affine_real_ae_nonzero (a : ℝ) :
    ∀ᵐ s : ℝ ∂volume, 1 - a * s ≠ 0 := by
  by_cases ha : a = 0
  · simp [ha]
  have hs : ∀ᵐ s : ℝ ∂volume, s ≠ 1 / a := by
    rw [ae_iff]
    simp
  filter_upwards [hs] with s hs
  intro h
  apply hs
  apply (eq_div_iff ha).2
  linarith [mul_comm a s]

private theorem log_complex_ge_real (z : ℂ) :
    (fun s : ℝ => Real.log |1 - z.re * s|) ≤ᵐ[volume]
      fun s : ℝ => Real.log ‖(1 : ℂ) - z * (s : ℂ)‖ := by
  filter_upwards [affine_real_ae_nonzero z.re] with s hs
  apply Real.log_le_log (abs_pos.mpr hs)
  have h := Complex.abs_re_le_norm ((1 : ℂ) - z * (s : ℂ))
  simpa [Complex.mul_re] using h

/-- A single complex linear factor is log-integrable, including factors with a real root. -/
theorem intervalIntegrable_complex_log_affine (z : ℂ) :
    IntervalIntegrable (fun s : ℝ => Real.log ‖(1 : ℂ) - z * (s : ℂ)‖) volume 0 1 := by
  let A : Set ℝ := Icc 0 1
  let L : ℝ → ℝ := fun s => Real.log |1 - z.re * s|
  let C := Real.log (1 + ‖z‖)
  let F : ℝ → ℝ := fun s => Real.log ‖(1 : ℂ) - z * (s : ℂ)‖
  have hi : Integrable L (volume.restrict A) :=
    (intervalIntegrable_iff_integrableOn_Icc_of_le (by norm_num : (0 : ℝ) ≤ 1)).1
      (integrable_real_log_affine z.re)
  rw [intervalIntegrable_iff_integrableOn_Icc_of_le (by norm_num : (0 : ℝ) ≤ 1)]
  change Integrable F (volume.restrict A)
  have hμ : IsFiniteMeasure (volume.restrict A) := isFiniteMeasure_restrict.mpr (by
    unfold A
    rw [Real.volume_Icc]
    exact ENNReal.ofReal_ne_top)
  have hm : Measurable F := by
    unfold F
    apply Real.measurable_log.comp
    fun_prop
  refine (hi.abs.add (integrable_const C)).mono' hm.aestronglyMeasurable ?_
  filter_upwards [ae_restrict_mem (show MeasurableSet A from measurableSet_Icc),
    (log_complex_ge_real z).filter_mono (ae_mono Measure.restrict_le_self),
    (affine_real_ae_nonzero z.re).filter_mono (ae_mono Measure.restrict_le_self)] with s hs hlo hn
  change L s ≤ F s at hlo
  have hC : 0 ≤ C := Real.log_nonneg (le_add_of_nonneg_right (norm_nonneg z))
  have hpos : 0 < ‖(1 : ℂ) - z * (s : ℂ)‖ := by
    have h := Complex.abs_re_le_norm ((1 : ℂ) - z * (s : ℂ))
    have hh : |1 - z.re * s| ≤ ‖(1 : ℂ) - z * (s : ℂ)‖ := by
      simpa [Complex.mul_re] using h
    exact (abs_pos.mpr hn).trans_le hh
  have hu : F s ≤ C := by
    apply Real.log_le_log hpos
    change ‖(1 : ℂ) - z * (s : ℂ)‖ ≤ 1 + ‖z‖
    calc
      _ ≤ ‖(1 : ℂ)‖ + ‖z * (s : ℂ)‖ := norm_sub_le _ _
      _ ≤ _ := by
        have hsn : |s| ≤ 1 := by rw [abs_of_nonneg hs.1]; exact hs.2
        simp only [norm_one, norm_mul, Complex.norm_real, Real.norm_eq_abs]
        exact add_le_add_left (mul_le_of_le_one_right (norm_nonneg _) hsn) _
  rw [Real.norm_eq_abs]
  change |F s| ≤ |L s| + C
  exact abs_le.mpr ⟨by linarith [neg_abs_le (L s)], by linarith [abs_nonneg (L s)]⟩

/-- Complex linear factors have the exact same lower bound required by the manuscript. -/
theorem integral_log_complex_affine_lower (z : ℂ) :
    -(1 + Real.exp (-1)) ≤ ∫ s in (0 : ℝ)..1, Real.log ‖(1 : ℂ) - z * (s : ℂ)‖ := by
  exact (integral_log_linear_lower_all z.re).trans
    (intervalIntegral.integral_mono_ae (by norm_num)
      (integrable_real_log_affine z.re) (intervalIntegrable_complex_log_affine z)
      (log_complex_ge_real z))

private theorem affine_complex_ae_nonzero (z : ℂ) :
    ∀ᵐ s : ℝ ∂volume, (1 : ℂ) - z * (s : ℂ) ≠ 0 := by
  filter_upwards [affine_real_ae_nonzero z.re] with x hx
  intro he
  apply hx
  have hr := congrArg Complex.re he
  simpa [Complex.mul_re] using hr

/-- The log estimate for any finite product of normalized complex linear factors. -/
theorem integral_log_linear_factors {ι : Type*} (S : Finset ι) (z : ι → ℂ) :
    IntervalIntegrable (fun s : ℝ => Real.log ‖∏ i ∈ S, ((1 : ℂ) - z i * (s : ℂ))‖)
      volume 0 1 ∧
    -(S.card : ℝ) * (1 + Real.exp (-1)) ≤
      ∫ s in (0 : ℝ)..1, Real.log ‖∏ i ∈ S, ((1 : ℂ) - z i * (s : ℂ))‖ := by
  classical
  let f : ι → ℝ → ℝ := fun i s => Real.log ‖(1 : ℂ) - z i * (s : ℂ)‖
  have h : ∀ i ∈ S, IntervalIntegrable (f i) volume 0 1 :=
    fun i _ => intervalIntegrable_complex_log_affine (z i)
  have hn : ∀ᵐ s : ℝ ∂volume, ∀ i ∈ S, ‖(1 : ℂ) - z i * (s : ℂ)‖ ≠ 0 := by
    rw [Filter.eventually_all_finset]
    intro i _
    filter_upwards [affine_complex_ae_nonzero (z i)] with s hs
    exact norm_ne_zero_iff.mpr hs
  have hsum : (fun s : ℝ => ∑ i ∈ S, f i s) =ᵐ[volume]
      fun s : ℝ => Real.log ‖∏ i ∈ S, ((1 : ℂ) - z i * (s : ℂ))‖ := by
    filter_upwards [hn] with s hs
    change (∑ i ∈ S, Real.log ‖(1 : ℂ) - z i * (s : ℂ)‖) =
      Real.log ‖∏ i ∈ S, ((1 : ℂ) - z i * (s : ℂ))‖
    rw [norm_prod, Real.log_prod S _ hs]
  have hs : IntervalIntegrable (∑ i ∈ S, f i) volume 0 1 := IntervalIntegrable.sum S h
  have hsum' : (∑ i ∈ S, f i) =ᵐ[volume]
      fun s : ℝ => Real.log ‖∏ i ∈ S, ((1 : ℂ) - z i * (s : ℂ))‖ := by
    filter_upwards [hsum] with s he
    rwa [Finset.sum_apply]
  refine ⟨hs.congr (hsum'.filter_mono (ae_mono Measure.restrict_le_self)), ?_⟩
  have hEq : (∫ s in (0 : ℝ)..1, (∑ i ∈ S, f i) s) =
      ∫ s in (0 : ℝ)..1, Real.log ‖∏ i ∈ S, ((1 : ℂ) - z i * (s : ℂ))‖ :=
    intervalIntegral.integral_congr_ae (hsum'.mono fun _ h _ => h)
  rw [← hEq]
  simp_rw [Finset.sum_apply, intervalIntegral.integral_finset_sum h]
  calc
    _ = ∑ _ ∈ S, -(1 + Real.exp (-1)) := by
      rw [Finset.sum_const, nsmul_eq_mul]
      ring
    _ ≤ _ := Finset.sum_le_sum fun i _ => integral_log_complex_affine_lower (z i)

end F18
