import F18.MeridianPolynomial
import Mathlib.MeasureTheory.Integral.Prod
import Mathlib.MeasureTheory.Integral.IntervalIntegral.Periodic

namespace F18
open MeasureTheory Set Filter

/-- The polar chart with azimuth first and normalized polar coordinate second. -/
noncomputable def unitPolarChart (q : ℝ × ℝ) : Sphere :=
  sphereChart (1 - 2*q.2, q.1)

theorem measurable_unitPolarChart : Measurable unitPolarChart := by
  exact measurable_sphereChart.comp (by fun_prop)

private theorem sphereChart_periodic (t : ℝ) :
    Function.Periodic (fun φ => sphereChart (t,φ)) (2*Real.pi) := by
  intro φ
  by_cases ht : t ^ 2 ≤ 1
  · apply Subtype.ext
    rw [sphereChart_val ht, sphereChart_val ht]
    simp [Real.cos_add_two_pi, Real.sin_add_two_pi]
  · simp [sphereChart, ht]

noncomputable def polarUnitMeasure : Measure ℝ := volume.restrict (Icc 0 1)
noncomputable def azimuthMeasure : Measure ℝ := volume.restrict (Icc 0 (2*Real.pi))

private instance : IsFiniteMeasure polarUnitMeasure := by
  unfold polarUnitMeasure
  infer_instance

private instance : IsFiniteMeasure azimuthMeasure := by
  unfold azimuthMeasure
  infer_instance

private theorem polarUnitMeasure_real_univ : polarUnitMeasure.real univ = 1 := by
  simp [polarUnitMeasure, measureReal_def, Real.volume_Icc]

private theorem azimuthMeasure_real_univ : azimuthMeasure.real univ = 2*Real.pi := by
  simp [azimuthMeasure, measureReal_def, Real.volume_Icc, Real.pi_pos.le]

theorem integral_restrict_eq_interval {a b : ℝ} (h : a ≤ b) (f : ℝ → ℝ) :
    (∫ x, f x ∂volume.restrict (Icc a b)) = ∫ x in a..b, f x := by
  rw [intervalIntegral.integral_of_le h, restrict_Ioc_eq_restrict_Icc]

private noncomputable def deficit (M y : ℝ) : ℝ := max (Real.log M - Real.log |y|) 0

private theorem measurable_deficit (M : ℝ) : Measurable (deficit M) :=
  (measurable_const.sub (Real.measurable_log.comp continuous_abs.measurable)).max measurable_const

private theorem deficit_eq {M y : ℝ} (hy : y ≠ 0) (hyM : |y| ≤ M) :
    deficit M y = Real.log M - Real.log |y| :=
  max_eq_left (sub_nonneg.mpr (Real.log_le_log (abs_pos.mpr hy) hyM))

private theorem deficit_nonneg (M y : ℝ) : 0 ≤ deficit M y := le_max_right _ _

set_option maxHeartbeats 800000 in
/-- The full rectangular log estimate for a symbol with nonzero north value.
This proof uses finite zeros of each meridian and does not assume joint
integrability of the logarithm before applying Fubini. -/
theorem log_mean_unitPolarChart {N : ℕ} (hN : 0 < N)
    (signs : Weight N → Bool) (ψ : State N)
    (h₀ : wigner signs ψ northPoint ≠ 0) (M : ℝ) (hM : ∀ p, |wigner signs ψ p| ≤ M) :
    let μ := azimuthMeasure.prod polarUnitMeasure
    (∀ᵐ q ∂μ, wigner signs ψ (unitPolarChart q) ≠ 0) ∧
    Integrable (fun q => Real.log |wigner signs ψ (unitPolarChart q)|) μ ∧
    (2*Real.pi) * (Real.log |wigner signs ψ northPoint| -
      (N : ℝ)*(1 + Real.exp (-1))) ≤
      ∫ q, Real.log |wigner signs ψ (unitPolarChart q)| ∂μ := by
  intro μ
  let w := wigner signs ψ
  let b := |w northPoint|
  let K := 2 * (Real.log M - Real.log b) + (2 * (N : ℝ)) * (1 + Real.exp (-1))
  let f : ℝ × ℝ → ℝ := fun q => w (unitPolarChart q)
  let g : ℝ × ℝ → ℝ := fun q => f (q.1+Real.pi,q.2)
  let F : ℝ × ℝ → ℝ := fun q => deficit M (f q)
  let G : ℝ × ℝ → ℝ := fun q => deficit M (g q)
  have mf : Measurable f := (continuous_wigner signs ψ).measurable.comp measurable_unitPolarChart
  have mg : Measurable g := mf.comp (by fun_prop)
  have mF : Measurable F := (measurable_deficit M).comp mf
  have mG : Measurable G := (measurable_deficit M).comp mg
  have nF (q) : 0 ≤ F q := deficit_nonneg _ _
  have nG (q) : 0 ≤ G q := deficit_nonneg _ _
  have hsect (φ : ℝ) :
      (∀ᵐ s ∂polarUnitMeasure, f (φ,s) ≠ 0 ∧ g (φ,s) ≠ 0) ∧
      Integrable (fun s => F (φ,s) + G (φ,s)) polarUnitMeasure ∧
      (∫ s, F (φ,s) + G (φ,s) ∂polarUnitMeasure) ≤ K := by
    obtain ⟨hne, hi, hlo⟩ := log_normalized_wigner_meridian hN signs ψ φ h₀
    let L : ℝ → ℝ := fun s => Real.log |f (φ,s) * g (φ,s) / w northPoint ^ 2|
    change (∀ᵐ s ∂polarUnitMeasure, f (φ,s) * g (φ,s) / w northPoint ^ 2 ≠ 0) at hne
    change IntervalIntegrable L volume 0 1 at hi
    change _ ≤ ∫ s in (0:ℝ)..1, L s at hlo
    have hn : ∀ᵐ s ∂polarUnitMeasure, f (φ,s) ≠ 0 ∧ g (φ,s) ≠ 0 := by
      filter_upwards [hne] with s hs
      exact ⟨fun he => hs (by simp [he]), fun he => hs (by simp [he])⟩
    have hL : Integrable L polarUnitMeasure :=
      (intervalIntegrable_iff_integrableOn_Icc_of_le zero_le_one).mp hi
    have hcongr : (fun s => 2 * (Real.log M - Real.log b) - L s) =ᵐ[polarUnitMeasure]
        fun s => F (φ,s) + G (φ,s) := by
      filter_upwards [hn] with s hs
      have hfl := deficit_eq hs.1 (hM _)
      have hgl := deficit_eq hs.2 (hM _)
      change _ = deficit M (f (φ,s)) + deficit M (g (φ,s))
      rw [hfl, hgl]
      unfold L b
      rw [abs_div, abs_mul, abs_pow,
        Real.log_div (mul_ne_zero (abs_ne_zero.mpr hs.1) (abs_ne_zero.mpr hs.2))
          (pow_ne_zero _ (abs_ne_zero.mpr h₀)),
        Real.log_mul (abs_ne_zero.mpr hs.1) (abs_ne_zero.mpr hs.2), Real.log_pow]
      ring
    refine ⟨hn, ((integrable_const _).sub hL).congr hcongr, ?_⟩
    rw [← integral_congr_ae hcongr, integral_sub (integrable_const _) hL,
      integral_const, polarUnitMeasure_real_univ, one_smul,
      show (∫ s, L s ∂polarUnitMeasure) = ∫ s in (0:ℝ)..1, L s from
        integral_restrict_eq_interval zero_le_one L]
    unfold K
    linarith
  have hne : ∀ᵐ q ∂μ, f q ≠ 0 ∧ g q ≠ 0 := by
    apply (Measure.ae_prod_iff_ae_ae
      ((measurableSet_singleton (0 : ℝ)).compl.preimage mf |>.inter
        ((measurableSet_singleton (0 : ℝ)).compl.preimage mg))).mpr
    exact Eventually.of_forall fun φ => (hsect φ).1
  have hiFG : Integrable (fun q => F q + G q) μ := by
    have hm := (mF.add mG).aestronglyMeasurable (μ := μ)
    apply (integrable_prod_iff hm).mpr
    refine ⟨Eventually.of_forall fun φ => (hsect φ).2.1, ?_⟩
    apply (integrable_const K).mono' hm.norm.integral_prod_right'
    apply Eventually.of_forall
    intro φ
    have he : (∫ s, ‖F (φ,s) + G (φ,s)‖ ∂polarUnitMeasure) =
        ∫ s, F (φ,s) + G (φ,s) ∂polarUnitMeasure :=
      integral_congr_ae (Eventually.of_forall fun s =>
        Real.norm_of_nonneg (add_nonneg (nF _) (nG _)))
    rw [he, Real.norm_of_nonneg (integral_nonneg (fun s => add_nonneg (nF _) (nG _)))]
    exact (hsect φ).2.2
  have hiF : Integrable F μ :=
    hiFG.mono' mF.aestronglyMeasurable <| Eventually.of_forall fun q => by
      rw [Real.norm_of_nonneg (nF q)]
      linarith [nG q]
  have hiG : Integrable G μ :=
    hiFG.mono' mG.aestronglyMeasurable <| Eventually.of_forall fun q => by
      rw [Real.norm_of_nonneg (nG q)]
      linarith [nF q]
  have hshift : (∫ q, F q ∂μ) = ∫ q, G q ∂μ := by
    rw [integral_prod_symm _ hiF, integral_prod_symm _ hiG]
    apply integral_congr_ae
    apply Eventually.of_forall
    intro s
    have hper : Function.Periodic (fun φ => F (φ,s)) (2*Real.pi) :=
      fun φ => congrArg (fun q => deficit M (w q)) (sphereChart_periodic (1-2*s) φ)
    change (∫ φ, F (φ,s) ∂azimuthMeasure) =
      ∫ φ, F (φ+Real.pi,s) ∂azimuthMeasure
    have hπ : 0 < 2*Real.pi := by positivity
    rw [show azimuthMeasure = volume.restrict (Icc 0 (2*Real.pi)) from rfl]
    rw [integral_restrict_eq_interval hπ.le, integral_restrict_eq_interval hπ.le]
    rw [intervalIntegral.integral_comp_add_right (fun φ => F (φ,s)) Real.pi]
    simpa [add_comm (2*Real.pi) Real.pi] using hper.intervalIntegral_add_eq_of_pos hπ 0 Real.pi
  have htotal : (∫ q, F q ∂μ) + (∫ q, G q ∂μ) ≤ (2*Real.pi)*K := by
    have hconst : (∫ _ : ℝ, K ∂azimuthMeasure) = (2*Real.pi)*K := by
      rw [integral_const, azimuthMeasure_real_univ]
      rfl
    rw [← integral_add hiF hiG, integral_prod _ hiFG, ← hconst]
    have hh : Integrable (fun φ : ℝ => ∫ s, F (φ,s) + G (φ,s) ∂polarUnitMeasure)
        azimuthMeasure := hiFG.integral_prod_left
    exact integral_mono hh (integrable_const K) (fun φ => (hsect φ).2.2)
  have hlog : (fun q => Real.log M - F q) =ᵐ[μ] fun q => Real.log |f q| := by
    filter_upwards [hne] with q hq
    change Real.log M - deficit M (f q) = _
    rw [deficit_eq hq.1 (hM _)]
    ring
  have hiLog := ((integrable_const _).sub hiF).congr hlog
  refine ⟨hne.mono fun q hq => hq.1, hiLog, ?_⟩
  change _ ≤ ∫ q, Real.log |f q| ∂μ
  rw [← integral_congr_ae hlog, integral_sub (integrable_const _) hiF, integral_const]
  have hmass : μ.real univ = 2*Real.pi := by
    rw [← azimuthMeasure_real_univ, ← mul_one (azimuthMeasure.real univ),
      ← polarUnitMeasure_real_univ]
    simp only [μ, measureReal_def, Measure.prod_apply, MeasurableSet.univ,
      preimage_univ, lintegral_const, ENNReal.toReal_mul, mul_comm]
  rw [hmass, smul_eq_mul]
  rw [← hshift] at htotal
  unfold K at htotal
  ring_nf at htotal ⊢
  linarith


private theorem map_polarUnitMeasure :
    Measure.map (fun s : ℝ => 1 - 2*s) polarUnitMeasure =
      ENNReal.ofReal (1/2) • volume.restrict (Icc (-1 : ℝ) 1) := by
  let T : ℝ → ℝ := fun s => 1 - 2*s
  have mT : Measurable T := by unfold T; fun_prop
  have ht : T ⁻¹' Icc (-1) 1 = Icc 0 1 := by
    ext x
    change (-1 ≤ 1 - 2*x ∧ 1 - 2*x ≤ 1) ↔ (0 ≤ x ∧ x ≤ 1)
    constructor <;> rintro ⟨h₁,h₂⟩ <;> constructor <;> linarith
  have hmap : Measure.map T volume = ENNReal.ofReal (1/2) • (volume : Measure ℝ) := by
    have hcomp : T = (fun x : ℝ => 1+x) ∘ fun y : ℝ => (-2)*y := by
      funext y
      unfold T
      simp only [Function.comp_apply]
      ring
    rw [hcomp, ← Measure.map_map (by fun_prop) (by fun_prop),
      Real.map_volume_mul_left (by norm_num : (-2:ℝ) ≠ 0), Measure.map_smul]
    rw [map_add_left_eq_self]
    norm_num [abs_of_nonneg (by norm_num : (0 : ℝ) ≤ 1 / 2)]
  change Measure.map T (volume.restrict _) = _
  rw [← ht, ← Measure.restrict_map mT measurableSet_Icc, hmap, Measure.restrict_smul]

/-- The original area measure in the normalized chart, with no change in
normalization and no appeal to spherical symmetry. -/
theorem areaProbability_unitPolarChart :
    areaProbability = ENNReal.ofReal ((2*Real.pi)⁻¹) •
      Measure.map unitPolarChart (azimuthMeasure.prod polarUnitMeasure) := by
  let T : ℝ → ℝ := fun s => 1 - 2*s
  have mT : Measurable T := by unfold T; fun_prop
  have mS : Measurable (Prod.map T (id : ℝ → ℝ)) := mT.prodMap measurable_id
  let μ := volume.restrict (Icc (-1 : ℝ) 1)
  let ν := azimuthMeasure
  let ρ := polarUnitMeasure
  let c := ENNReal.ofReal (1/2)
  letI : IsFiniteMeasure μ := by unfold μ; infer_instance
  letI : IsFiniteMeasure (c • μ) :=
    ⟨by rw [Measure.smul_apply, smul_eq_mul];
         exact ENNReal.mul_lt_top ENNReal.ofReal_lt_top (measure_lt_top μ univ)⟩
  have hprod : (c • μ).prod ν = c • μ.prod ν := by
    apply Measure.prod_eq
    intro s t _ _
    simp only [Measure.smul_apply, Measure.prod_prod, smul_eq_mul, mul_assoc]
  have hmap : Measure.map (Prod.map T (id : ℝ → ℝ)) (ρ.prod ν) = c • μ.prod ν := by
    rw [← Measure.map_prod_map ρ ν mT measurable_id, Measure.map_id,
      show Measure.map T ρ = c • μ from map_polarUnitMeasure]
    exact hprod
  have hchart : unitPolarChart = sphereChart ∘ Prod.map T (id : ℝ → ℝ) ∘ Prod.swap := rfl
  have hscaled : Measure.map unitPolarChart (ν.prod ρ) = c • Measure.map sphereChart (μ.prod ν) := by
    rw [hchart, ← Measure.map_map measurable_sphereChart (mS.comp measurable_swap),
      ← Measure.map_map mS measurable_swap, Measure.prod_swap, hmap, Measure.map_smul]
  have hvol : (volume : Measure (ℝ × ℝ)).restrict polarRectangle = μ.prod ν := by
    unfold polarRectangle μ ν azimuthMeasure
    rw [Measure.volume_eq_prod, Measure.prod_restrict]
  unfold areaProbability
  change ENNReal.ofReal ((4 * Real.pi)⁻¹) •
    Measure.map sphereChart (volume.restrict polarRectangle) = _
  rw [hvol, hscaled, smul_smul]
  congr 1
  unfold c
  rw [← ENNReal.ofReal_mul (by positivity : 0 ≤ (2*Real.pi)⁻¹)]
  congr 1
  have hπ : Real.pi ≠ 0 := Real.pi_pos.ne'
  field_simp
  all_goals ring

set_option maxHeartbeats 800000 in
/-- Exact logarithmic mean with the north-pole value on the right.
A later rotation can put a maximum-modulus point at the north pole. -/
theorem log_mean_area_of_north_ne_zero {N : ℕ} (hN : 0 < N)
    (signs : Weight N → Bool) (ψ : State N)
    (h₀ : wigner signs ψ northPoint ≠ 0) (M : ℝ) (hM : ∀ p, |wigner signs ψ p| ≤ M) :
    (∀ᵐ p ∂areaProbability, wigner signs ψ p ≠ 0) ∧
    Integrable (fun p => Real.log |wigner signs ψ p|) areaProbability ∧
    Real.log |wigner signs ψ northPoint| - (N : ℝ)*(1+Real.exp (-1)) ≤
      ∫ p, Real.log |wigner signs ψ p| ∂areaProbability := by
  obtain ⟨hne, hi, hlo⟩ := log_mean_unitPolarChart hN signs ψ h₀ M hM
  let L : Sphere → ℝ := fun p => Real.log |wigner signs ψ p|
  have mW := (continuous_wigner signs ψ).measurable
  have mL : Measurable L := Real.measurable_log.comp (continuous_abs.measurable.comp mW)
  have me : MeasurableSet {p : Sphere | wigner signs ψ p ≠ 0} :=
    ((measurableSet_singleton (0:ℝ)).compl.preimage mW)
  rw [areaProbability_unitPolarChart]
  refine ⟨?_, ?_, ?_⟩
  · exact Measure.ae_smul_measure ((ae_map_iff measurable_unitPolarChart.aemeasurable me).mpr hne) _
  · exact ((integrable_map_measure mL.aestronglyMeasurable
      measurable_unitPolarChart.aemeasurable).mpr hi).smul_measure ENNReal.ofReal_ne_top
  · change _ ≤ ∫ p, L p ∂ENNReal.ofReal ((2*Real.pi)⁻¹) • _
    rw [integral_smul_measure, ENNReal.toReal_ofReal (by positivity), smul_eq_mul,
      integral_map measurable_unitPolarChart.aemeasurable mL.aestronglyMeasurable]
    have hπ : 0 < 2*Real.pi := by positivity
    exact (le_inv_mul_iff₀ hπ).mpr (by simpa only [mul_comm] using hlo)


/-- Compactness gives an actual maximizer for the absolute symbol, including
the case in which it vanishes identically. -/
theorem exists_max_abs_wigner {N : ℕ} (signs : Weight N → Bool) (ψ : State N) :
    ∃ p : Sphere, ∀ q : Sphere, |wigner signs ψ q| ≤ |wigner signs ψ p| := by
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  obtain ⟨p, _, hp⟩ := isCompact_univ.exists_isMaxOn
    (show (univ : Set Sphere).Nonempty from ⟨northPoint, trivial⟩)
    (continuous_wigner signs ψ).abs.continuousOn
  exact ⟨p, fun q => hp (mem_univ q)⟩

/-- A.e. nonvanishing implies dense nonvanishing on the original sphere by
the previously checked full-support property, without analytic continuation. -/
theorem dense_of_ae_nonzero_area (f : Sphere → ℝ)
    (h : ∀ᵐ p ∂areaProbability, f p ≠ 0) :
    Dense {p : Sphere | f p ≠ 0} := by
  intro p
  apply mem_closure_iff.mpr
  intro U hU hp
  by_contra hh
  have hs : U ⊆ {x : Sphere | ¬ f x ≠ 0} := by
    intro x hx hn
    exact hh ⟨x, hx, hn⟩
  have hz : areaProbability {x : Sphere | ¬ f x ≠ 0} = 0 := ae_iff.mp h
  exact not_le_of_gt (areaProbability_pos_of_open hU ⟨p,hp⟩) (hz ▸ measure_mono hs)

/-- The already-proved spherical log estimate, transported along a verified
measure-preserving symmetry. Future spin-representation lemmas provide
this symmetry and covariance for the actual rotated state. -/
theorem log_mean_area_transport {N : ℕ} (hN : 0 < N)
    (signs : Weight N → Bool) (ψ ψ' : State N) (rot : Sphere → Sphere)
    (hrot : MeasurePreserving rot areaProbability areaProbability)
    (hcov : ∀ p, wigner signs ψ' p = wigner signs ψ (rot p))
    (h₀ : wigner signs ψ (rot northPoint) ≠ 0)
    (M : ℝ) (hM : ∀ p, |wigner signs ψ p| ≤ M) :
    let L := fun p : Sphere => Real.log |wigner signs ψ p|
    (∀ᵐ p ∂areaProbability, wigner signs ψ p ≠ 0) ∧ Integrable L areaProbability ∧
      Real.log |wigner signs ψ (rot northPoint)| - (N : ℝ)*(1+Real.exp (-1)) ≤
        ∫ p, L p ∂areaProbability := by
  intro L
  obtain ⟨hne, hi, hlo⟩ := log_mean_area_of_north_ne_zero hN signs ψ'
    (hcov northPoint ▸ h₀) M (fun p => hcov p ▸ hM (rot p))
  have hw := (continuous_wigner signs ψ).measurable
  have mL : Measurable L := Real.measurable_log.comp (continuous_abs.measurable.comp hw)
  have me : MeasurableSet {p : Sphere | wigner signs ψ p ≠ 0} :=
    (measurableSet_singleton (0:ℝ)).compl.preimage hw
  have he : (L ∘ rot) = fun p => Real.log |wigner signs ψ' p| := by
    funext p
    exact congrArg (fun y : ℝ => Real.log |y|) (hcov p).symm
  refine ⟨?_, ?_, ?_⟩
  · rw [← hrot.map_eq, ae_map_iff hrot.measurable.aemeasurable me]
    filter_upwards [hne] with p h using (hcov p ▸ h)
  · rw [← hrot.map_eq, integrable_map_measure mL.aestronglyMeasurable
      hrot.measurable.aemeasurable, he]
    exact hi
  · change _ ≤ ∫ p, L p ∂areaProbability
    rw [← hrot.map_eq, integral_map hrot.measurable.aemeasurable mL.aestronglyMeasurable,
      show (fun p => L (rot p)) = _ from he]
    rw [hcov northPoint] at hlo
    exact hlo

end F18
