import F18.SpinOrthogonality

namespace F18

/-- Manuscript quantitative volume and depth bounds for the concrete kernel. -/
theorem originalQuantitativeBounds : OriginalQuantitativeBounds :=
  originalQuantitative_of_rotationInvariant_orthogonal sphereRotationInvariant spinOrthogonalRotation

/-- The attained minimum of the concrete Wigner function is negative. -/
theorem originalMinimumNegativity : OriginalMinimumNegativity :=
  minimumNegativity_of_originalQuantitative originalQuantitativeBounds

/-- Pointwise negativity for all rank-sign choices occurring in the manuscript. -/
theorem originalAllSigns : OriginalAllSigns :=
  allSigns_of_minimum originalMinimumNegativity

/-- Catalogue F18 for the original standard spherical Wigner kernel. -/
theorem originalF18 : OriginalF18 :=
  original_of_allSigns originalAllSigns

end F18
