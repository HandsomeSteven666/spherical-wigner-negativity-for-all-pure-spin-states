import F18.Definition
import Mathlib.MeasureTheory.Integral.Bochner.Basic
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum

namespace F18
open MeasureTheory Set

/-- Equal-area coordinates: first input is the polar cosine and second is azimuth.
The extension outside the integration rectangle is not used. -/
noncomputable def sphereChart (q : ℝ × ℝ) : Sphere :=
  if h : q.1 ^ 2 ≤ 1 then
    ⟨(Real.sqrt (1 - q.1 ^ 2) * Real.cos q.2,
      Real.sqrt (1 - q.1 ^ 2) * Real.sin q.2, q.1), by
        change (Real.sqrt (1 - q.1 ^ 2) * Real.cos q.2) ^ 2 +
          (Real.sqrt (1 - q.1 ^ 2) * Real.sin q.2) ^ 2 + q.1 ^ 2 = 1
        rw [mul_pow, mul_pow, ← mul_add, Real.cos_sq_add_sin_sq,
          mul_one, Real.sq_sqrt (sub_nonneg.mpr h)]
        ring⟩
  else ⟨(0, 0, 1), by norm_num⟩

/-- Normalized spherical area, as the pushforward of uniform polar cosine and azimuth. -/
noncomputable def areaProbability : Measure Sphere :=
  ENNReal.ofReal ((4 * Real.pi)⁻¹) •
    Measure.map sphereChart
      ((volume : Measure (ℝ × ℝ)).restrict (Icc (-1) 1 ×ˢ Icc 0 (2 * Real.pi)))

/-- Manuscript measure dμ_j = (2j+1) dη. -/
noncomputable def spinMeasure (N : ℕ) : Measure Sphere :=
  ((N + 1 : ℕ) : ENNReal) • areaProbability

noncomputable def negativeVolume {N : ℕ} (signs : Weight N → Bool) (ψ : State N) : ℝ :=
  ∫ p, max (-wigner signs ψ p) 0 ∂spinMeasure N

noncomputable def boundFactor (N : ℕ) : ℝ :=
  Real.exp (-2 * (1 + Real.exp (-1)) * (N : ℝ))

/-- The two inequalities of the manuscript, recorded as a proof target.
A minimizing point is expressed by its exact order property, without a choice of optimizer. -/
def OriginalQuantitativeBounds : Prop :=
  ∀ (N : ℕ), 0 < N → ∀ (signs : Weight N → Bool) (ψ : State N), squaredNorm ψ = 1 →
    Real.sqrt ((N + 1 : ℕ) : ℝ) / 4 * boundFactor N ≤ negativeVolume signs ψ ∧
    ∃ p : Sphere, (∀ q : Sphere, wigner signs ψ p ≤ wigner signs ψ q) ∧
      boundFactor N / (4 * Real.sqrt ((N + 1 : ℕ) : ℝ)) ≤ -wigner signs ψ p

end F18
