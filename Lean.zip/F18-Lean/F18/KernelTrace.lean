import F18.Pole
import F18.SpinRepresentation
import Mathlib.Data.Nat.Choose.Sum

namespace F18

/-- Shifted Vandermonde identity: choose k+m+1 objects, splitting at object k+1. -/
theorem sum_choose_reverse_choose (n k m : ℕ) :
    (∑ r ∈ Finset.range (n+1), r.choose k * (n-r).choose m) = (n+1).choose (k+m+1) := by
  induction n generalizing m with
  | zero =>
      cases m with
      | zero => simp [Nat.choose_succ_succ']
      | succ m =>
        rw [Finset.sum_range_one]
        simp only [Nat.sub_self, Nat.choose_zero_succ, mul_zero, zero_add]
        exact (Nat.choose_eq_zero_of_lt (by omega)).symm
  | succ n ih =>
      rw [Finset.sum_range_succ]
      cases m with
      | zero =>
        simp only [Nat.choose_zero_right, mul_one, Nat.add_zero]
        have h := ih 0
        simp only [Nat.choose_zero_right, mul_one, Nat.add_zero] at h
        rw [h, Nat.choose_succ_succ' (n+1) k]
        exact Nat.add_comm _ _
      | succ m =>
        simp only [Nat.sub_self, Nat.choose_zero_succ, mul_zero, add_zero]
        have hs : (∑ r ∈ Finset.range (n+1), r.choose k * (n+1-r).choose (m+1)) =
            ∑ r ∈ Finset.range (n+1), (r.choose k * (n-r).choose m +
              r.choose k * (n-r).choose (m+1)) := by
          apply Finset.sum_congr rfl
          intro r hr
          have hr' := Finset.mem_range.mp hr
          rw [show n+1-r = (n-r)+1 by omega, Nat.choose_succ_succ', Nat.mul_add]
        rw [hs, Finset.sum_add_distrib, ih, ih,
          show k+(m+1)+1 = (k+m+1)+1 by omega, Nat.choose_succ_succ' (n+1) (k+m+1)]

noncomputable def cgScale (N l : ℕ) : ℝ :=
  Real.sqrt (((N+1 : ℕ) : ℝ) * (Nat.factorial (N-l) : ℝ) *
    (Nat.factorial l : ℝ)^2 / (Nat.factorial (N+l+1) : ℝ))

/-- The original factorial CG diagonal rewritten with binomial coefficients.
No normalization is changed. -/
theorem northCG_choose (N : ℕ) (r l : Weight N) :
    northCG N r l = cgScale N l.val *
      ∑ q ∈ Finset.range (l.val+1), (-1 : ℝ)^q *
        (l.val.choose q : ℝ) * (r.val.choose q : ℝ) * ((N-r.val).choose (l.val-q) : ℝ) := by
  unfold northCG cgScale
  let K := Real.sqrt (((N+1 : ℕ) : ℝ) * (Nat.factorial (N-l.val) : ℝ) *
    (Nat.factorial l.val : ℝ)^2 / (Nat.factorial (N+l.val+1) : ℝ))
  change K * _ * _ * _ * _ = K * _
  rw [mul_assoc K, mul_assoc K, mul_assoc K]
  congr 1
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro q hq
  have hql : q ≤ l.val := Nat.le_of_lt_succ (Finset.mem_range.mp hq)
  have hrN : r.val ≤ N := Nat.le_of_lt_succ r.isLt
  by_cases h : q ≤ r.val ∧ l.val+r.val ≤ N+q
  · have hle : l.val-q ≤ N-r.val := by omega
    have he : N+q-l.val-r.val = N-r.val-(l.val-q) := by omega
    have hf (n k : ℕ) (hle : k ≤ n) :
        (n.choose k : ℝ) = (n.factorial : ℝ) / (k.factorial * (n-k).factorial : ℕ) := by
      rw [Nat.cast_mul, eq_div_iff (by positivity)]
      exact_mod_cast (by rw [← Nat.mul_assoc, Nat.choose_mul_factorial_mul_factorial hle] :
        n.choose k * (k.factorial * (n-k).factorial) = n.factorial)
    rw [if_pos h, he, hf _ _ hle, hf _ _ h.1, hf _ _ hql]
    push_cast
    have fp (i : ℕ) : (i.factorial : ℝ) ≠ 0 := by positivity
    field_simp [fp]
    ring
  · rw [if_neg h, mul_zero]
    by_cases hqr : q ≤ r.val
    · have ht : N-r.val < l.val-q := by omega
      rw [Nat.choose_eq_zero_of_lt ht, Nat.cast_zero, mul_zero]
    · rw [Nat.choose_eq_zero_of_lt (by omega : r.val < q), Nat.cast_zero, mul_zero, zero_mul]


/-- All positive ranks in the concrete north-pole CG matrix have zero trace. -/
theorem sum_northCG_eq_zero (N : ℕ) (l : Weight N) (hl : l.val ≠ 0) :
    (∑ r : Weight N, northCG N r l) = 0 := by
  simp only [northCG_choose, ← Finset.mul_sum]
  rw [Finset.sum_comm]
  have hh : (∑ q ∈ Finset.range (l.val+1), ∑ r : Weight N, (-1 : ℝ)^q *
      (l.val.choose q : ℝ) * (r.val.choose q : ℝ) * ((N-r.val).choose (l.val-q) : ℝ)) =
      ((N+1).choose (l.val+1) : ℝ) *
        ∑ q ∈ Finset.range (l.val+1), (-1 : ℝ)^q * (l.val.choose q : ℝ) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro q hq
    have hq' : q ≤ l.val := Nat.le_of_lt_succ (Finset.mem_range.mp hq)
    have hs : (∑ r : Weight N, (r.val.choose q : ℝ) *
        ((N-r.val).choose (l.val-q) : ℝ)) = ((N+1).choose (l.val+1) : ℝ) := by
      rw [Fin.sum_univ_eq_sum_range (fun r : ℕ => (r.choose q : ℝ) * ((N-r).choose (l.val-q) : ℝ)) (N+1)]
      exact_mod_cast (by simpa only [Nat.add_sub_of_le hq'] using
        sum_choose_reverse_choose N q (l.val-q))
    rw [← hs, Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro r _
    ring
  rw [hh]
  have hzero : (∑ q ∈ Finset.range (l.val+1), (-1 : ℝ)^q * (l.val.choose q : ℝ)) = 0 := by
    have h := add_pow (-1 : ℝ) 1 l.val
    simpa only [one_pow, mul_one, neg_add_cancel, zero_pow hl] using h.symm
  rw [hzero, mul_zero, mul_zero]

theorem sum_poleEigenvalue (N : ℕ) (signs : Weight N → Bool) :
    (∑ r : Weight N, poleEigenvalue N signs r) = 1 := by
  unfold poleEigenvalue
  rw [Finset.sum_comm, Finset.sum_eq_single (0 : Weight N)]
  · simp only [northCG_rankZero, Fin.val_zero, mul_zero, zero_add, Nat.cast_one,
      mul_one, Finset.sum_const, Finset.card_univ, Fintype.card_fin, nsmul_eq_mul]
    have hn : ((N : ℝ) + 1) ≠ 0 := by positivity
    simp only [rankSign, Fin.val_zero, true_or, if_true, Nat.cast_add, Nat.cast_one]
    field_simp [hn]
  · intro l _ hl
    rw [← Finset.mul_sum, sum_northCG_eq_zero]
    · simp
    · exact fun h => hl (Fin.ext h)
  · simp

/-- The trace of the actual Wigner kernel is one at every point and rank-sign choice. -/
theorem kernel_trace_eq_one (N : ℕ) (signs : Weight N → Bool) (p : Sphere) :
    Matrix.trace (kernel N signs p) = 1 := by
  let U := spinMatrix N (spinor p).1 (spinor p).2
  let D : Operator N := Matrix.diagonal (fun r => (poleEigenvalue N signs r : ℂ))
  change Matrix.trace (U * D * U.conjTranspose) = 1
  have hU : U.conjTranspose * U = 1 := spinMatrix_conjTranspose_mul_self N (liftSpinor p)
  rw [Matrix.trace_mul_cycle, hU, one_mul, Matrix.trace_diagonal, ← Complex.ofReal_sum,
    sum_poleEigenvalue, Complex.ofReal_one]

end F18
