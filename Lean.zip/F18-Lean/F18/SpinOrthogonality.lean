import F18.SpinPhase
import Mathlib.MeasureTheory.Integral.Bochner.ContinuousLinearMap

namespace F18
open MeasureTheory Metric Set Filter
open scoped Matrix

private noncomputable def matrixCoeff {N : ℕ} (ψ : State N) (A : Operator N) : ℂ :=
  ∑ i, starRingEnd ℂ (ψ i) * (A *ᵥ ψ) i

private theorem continuous_matrixCoeff {N : ℕ} (ψ : State N) :
    Continuous (matrixCoeff ψ) := by
  unfold matrixCoeff Matrix.mulVec dotProduct
  apply continuous_finset_sum
  intro i _
  apply continuous_const.mul
  exact continuous_finset_sum _ fun j _ => ((continuous_apply j).comp (continuous_apply i)).mul continuous_const

private theorem matrixCoeff_complex_smul {N : ℕ} (ψ : State N) (A : Operator N) (z : ℂ) :
    matrixCoeff ψ (z • A) = z * matrixCoeff ψ A := by
  simp only [matrixCoeff, Matrix.smul_mulVec_assoc, Pi.smul_apply, smul_eq_mul, Finset.mul_sum]
  exact Finset.sum_congr rfl (fun _ _ => by ring)

private theorem matrixCoeff_operatorIntegral {N : ℕ} (ψ : State N)
    (F : Sphere → Operator N) (hi : ∀ i j, Integrable (fun p => F p i j) areaProbability) :
    matrixCoeff ψ (operatorIntegral areaProbability F) =
      ∫ y, matrixCoeff ψ (F y) ∂areaProbability := by
  simp only [matrixCoeff, Matrix.mulVec, dotProduct, operatorIntegral]
  rw [integral_finset_sum]
  · apply Finset.sum_congr rfl
    intro i _
    rw [integral_const_mul, integral_finset_sum _ (fun j _ => (hi i j).mul_const (ψ j))]
    simp only [integral_mul_const]
  · intro i _
    exact (integrable_finset_sum _ (fun j _ => (hi i j).mul_const (ψ j))).const_mul _

private theorem integrable_continuous_area {E : Type*} [NormedAddCommGroup E]
    {F : Sphere → E} (hF : Continuous F) : Integrable F areaProbability := by
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  letI : IsFiniteMeasure areaProbability := ⟨by simp [areaProbability_mass]⟩
  exact hF.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)

private noncomputable def stateSpinCoeff {N : ℕ} (ψ : State N) (u : UnitSpinor) : ℂ :=
  matrixCoeff ψ (spinAction N u)

private theorem continuous_stateSpinCoeff {N : ℕ} (ψ : State N) :
    Continuous (stateSpinCoeff ψ) := (continuous_matrixCoeff ψ).comp (continuous_spinAction N)

private theorem spinCoeff_class_integral {N : ℕ} (ψ : State N) (u : UnitSpinor)
    (a b : ℝ) (hab : a^2+b^2 = 1) :
    (∫ y, stateSpinCoeff ψ (unitSpinorMul u (spinClass a b hab y)) ∂areaProbability) =
      matrixCoeff ψ (spinAction N u * spinClassAverage N a b hab) := by
  let F (y : Sphere) := spinAction N (spinClass a b hab y)
  have hF : Continuous F := (continuous_spinAction N).comp (continuous_spinClass a b hab)
  have hG : Continuous (fun y => spinAction N u * F y) := continuous_const.matrix_mul hF
  simp only [stateSpinCoeff, spinAction_mul]
  change (∫ y, matrixCoeff ψ (spinAction N u * F y) ∂areaProbability) = _
  rw [← matrixCoeff_operatorIntegral _ _ (fun i j => integrable_continuous_area (hG.matrix_elem i j)),
    operatorIntegral_mul_left _ _ _ (fun i j => integrable_continuous_area (hF.matrix_elem i j))]
  rfl

private theorem continuous_positive_integral_zero {f : Sphere → ℝ}
    (hf : Continuous f) (hn : ∀ p, 0 ≤ f p)
    (hz : (∫ p, f p ∂areaProbability) = 0) : ∀ p, f p = 0 := by
  have hae := (integral_eq_zero_iff_of_nonneg_ae (Eventually.of_forall hn)
      (integrable_continuous_area hf)).mp hz
  intro p
  by_contra hp
  have hs : IsOpen {q | 0 < f q} := isOpen_lt continuous_const hf
  have hpos := areaProbability_pos_of_open hs ⟨p,lt_of_le_of_ne (hn p) (Ne.symm hp)⟩
  have hz' : areaProbability {q | ¬ f q = 0} = 0 := ae_iff.mp hae
  have hl : {q | 0 < f q} ⊆ {q | ¬ f q = 0} := fun q hq => ne_of_gt hq
  exact (not_le_of_gt hpos) (hz' ▸ measure_mono hl)

private theorem phase_im_rotated (f : UnitSpinor → ℂ) (θ : UnitSpinor → ℝ)
    (hθ : ∀ u, f u = (‖f u‖ : ℂ) * Complex.exp ((θ u : ℂ)*Complex.I))
    (u : UnitSpinor) (B : ℝ) :
    (Complex.exp (-(B:ℂ)*Complex.I) * f u).im = ‖f u‖ * Real.sin (θ u-B) := by
  rw [hθ u]
  nth_rw 2 [← hθ u]
  rw [mul_left_comm, ← Complex.exp_add]
  have h : -(B:ℂ)*Complex.I + (θ u:ℂ)*Complex.I = ((θ u-B:ℝ):ℂ)*Complex.I := by
    push_cast
    ring
  rw [h,Complex.exp_mul_I, ← Complex.ofReal_cos, ← Complex.ofReal_sin]
  simp only [Complex.mul_im, Complex.mul_re, Complex.add_re, Complex.add_im,
    Complex.ofReal_re, Complex.ofReal_im, Complex.I_re, Complex.I_im, zero_mul,
    mul_zero, mul_one, zero_add, add_zero, sub_zero]


private theorem continuous_spinorRe : Continuous (fun u : UnitSpinor => u.val.1.re) :=
  Complex.continuous_re.comp (continuous_fst.comp continuous_subtype_val)

private theorem continuous_left_spinor (g : UnitSpinor) :
    Continuous (unitSpinorMul g) :=
  continuous_unitSpinorMul.comp (continuous_const.prodMk continuous_id)

private theorem spinor_left_inverse_apply (g u : UnitSpinor) :
    unitSpinorMul g (unitSpinorMul (unitSpinorInv g) u) = u := by
  rw [← unitSpinorMul_assoc, unitSpinorMul_inv, unitSpinor_one_mul]

private theorem class_phase_maximum {N : ℕ} (ψ : State N) (θ : UnitSpinor → ℝ)
    (hθ : ∀ u, stateSpinCoeff ψ u = (‖stateSpinCoeff ψ u‖ : ℂ) *
      Complex.exp ((θ u : ℂ)*Complex.I))
    (hn : ∀ u, stateSpinCoeff ψ u ≠ 0) (B : ℝ)
    (hb : ∀ u, θ u ≤ B) (g : UnitSpinor) (hg : θ g = B)
    (a b : ℝ) (hab : a^2+b^2 = 1)
    (hl : ∀ y : Sphere, B-Real.pi < θ (unitSpinorMul g (spinClass a b hab y))) :
    ∀ y : Sphere, θ (unitSpinorMul g (spinClass a b hab y)) = B := by
  let F (y : Sphere) := Complex.exp (-(B:ℂ)*Complex.I) *
    stateSpinCoeff ψ (unitSpinorMul g (spinClass a b hab y))
  have hF : Continuous F := continuous_const.mul ((continuous_stateSpinCoeff ψ).comp
    ((continuous_left_spinor g).comp (continuous_spinClass a b hab)))
  have hfrm (y : Sphere) : (F y).im = ‖stateSpinCoeff ψ (unitSpinorMul g (spinClass a b hab y))‖ *
      Real.sin (θ (unitSpinorMul g (spinClass a b hab y))-B) :=
    phase_im_rotated _ θ hθ _ B
  have hIs : (∫ y, (F y).im ∂areaProbability) = 0 := by
    have hIi := integral_im (integrable_continuous_area hF)
    change (∫ y, (F y).im ∂areaProbability) = (∫ y, F y ∂areaProbability).im at hIi
    rw [hIi]
    unfold F
    rw [integral_const_mul, spinCoeff_class_integral]
    obtain ⟨r,hr⟩ := spinClassAverage_real_scalar N a b hab
    rw [hr, Matrix.mul_smul, mul_one, matrixCoeff_complex_smul]
    change (Complex.exp (-(B:ℂ)*Complex.I) * ((r:ℂ) * stateSpinCoeff ψ g)).im = 0
    rw [mul_left_comm, Complex.mul_im, Complex.ofReal_re, Complex.ofReal_im, zero_mul,
      add_zero, phase_im_rotated _ θ hθ _ B, hg, sub_self, Real.sin_zero, mul_zero, mul_zero]
  have hz : ∀ y, -(F y).im = 0 := by
    apply continuous_positive_integral_zero (Complex.continuous_im.comp hF).neg
    · intro y
      change 0 ≤ -(F y).im
      rw [hfrm]
      have hs : Real.sin (θ (unitSpinorMul g (spinClass a b hab y))-B) ≤ 0 :=
        Real.sin_nonpos_of_nonnpos_of_neg_pi_le (sub_nonpos.mpr (hb _)) (by linarith [hl y])
      exact neg_nonneg.mpr (mul_nonpos_of_nonneg_of_nonpos (norm_nonneg _) hs)
    · change (∫ y, -(F y).im ∂areaProbability) = 0
      rw [integral_neg, hIs, neg_zero]
  intro y
  apply le_antisymm (hb _)
  by_contra h
  have hh : θ (unitSpinorMul g (spinClass a b hab y)) < B := lt_of_not_ge h
  have hsin : Real.sin (θ (unitSpinorMul g (spinClass a b hab y))-B) < 0 :=
    Real.sin_neg_of_neg_of_neg_pi_lt (sub_neg.mpr hh) (by linarith [hl y])
  have hneg := mul_neg_of_pos_of_neg (norm_pos_iff.mpr (hn (unitSpinorMul g (spinClass a b hab y)))) hsin
  rw [← hfrm] at hneg
  have hyp := hz y
  linarith

private theorem phase_constant {N : ℕ} (ψ : State N) (θ : UnitSpinor → ℝ)
    (hc : Continuous θ)
    (hθ : ∀ u, stateSpinCoeff ψ u = (‖stateSpinCoeff ψ u‖ : ℂ) *
      Complex.exp ((θ u : ℂ)*Complex.I))
    (hn : ∀ u, stateSpinCoeff ψ u ≠ 0) : ∃ B : ℝ, ∀ u, θ u = B := by
  obtain ⟨u₀,_,hmax⟩ := isCompact_univ.exists_isMaxOn
    (show (univ : Set UnitSpinor).Nonempty from ⟨unitSpinorOne, trivial⟩) hc.continuousOn
  let B := θ u₀
  have hb (u : UnitSpinor) : θ u ≤ B := hmax (mem_univ u)
  let S : Set UnitSpinor := {u | θ u = B}
  have hs : IsClosed S := isClosed_eq hc continuous_const
  have hopen : IsOpen S := by
    apply isOpen_iff_mem_nhds.mpr
    intro g hg
    change θ g = B at hg
    let G := fun v => θ (unitSpinorMul g v)
    have hG : Continuous G := hc.comp (continuous_left_spinor g)
    obtain ⟨δ,hδ,hd⟩ := (Metric.continuousAt_iff.mp hG.continuousAt) Real.pi Real.pi_pos
    have hbase : G unitSpinorOne = B := by unfold G; rw [unitSpinorMul_one,hg]
    have hlow (v : UnitSpinor) (hv : 1-δ^2/2 < v.val.1.re) : B-Real.pi < G v := by
      have he := hd (spinor_dist_one_le v δ hδ hv)
      rw [hbase, Real.dist_eq] at he
      linarith [(abs_lt.mp he).1]
    let U : Set UnitSpinor := {u | 1-δ^2/2 < (unitSpinorMul (unitSpinorInv g) u).val.1.re}
    have hU : IsOpen U := isOpen_lt continuous_const
      (continuous_spinorRe.comp (continuous_left_spinor (unitSpinorInv g)))
    have hgU : g ∈ U := by
      change 1-δ^2/2 < (unitSpinorMul (unitSpinorInv g) g).val.1.re
      rw [unitSpinorInv_mul]
      change 1-δ^2/2 < 1
      nlinarith
    apply Filter.mem_of_superset (hU.mem_nhds hgU)
    intro u hu
    let v := unitSpinorMul (unitSpinorInv g) u
    have hv : 1-δ^2/2 < v.val.1.re := hu
    obtain ⟨a,b,hab,y,hy⟩ := exists_spinClass_repr v
    have ha : v.val.1.re = a := (congrArg (fun q : UnitSpinor => q.val.1.re) hy).symm
    change θ u = B
    have hloc (x : Sphere) : B-Real.pi < θ (unitSpinorMul g (spinClass a b hab x)) :=
      hlow _ (by rw [spinClass_re, ← ha]; exact hv)
    have he := class_phase_maximum ψ θ hθ hn B hb g hg a b hab hloc y
    rw [hy, spinor_left_inverse_apply g u] at he
    exact he
  have he := IsClopen.eq_univ ⟨hs,hopen⟩ (show S.Nonempty from ⟨u₀,rfl⟩)
  exact ⟨B,fun u => show u ∈ S from he.symm ▸ mem_univ u⟩

/-- Every state at positive spin has an orthogonal partner on its exact
spin-rotation orbit. -/
theorem spinOrthogonalRotation : SpinOrthogonalRotation := by
  intro N hN ψ _hψ
  by_contra! h
  have hn (u : UnitSpinor) : stateSpinCoeff ψ u ≠ 0 := by
    intro hz
    apply h (unitSpinorInv u)
    change matrixCoeff ψ (spinAction N (unitSpinorInv u))ᴴ = 0
    rw [← spinAction_inv]
    have hinv : unitSpinorInv (unitSpinorInv u) = u := by
      apply Subtype.ext
      simp [unitSpinorInv]
    rwa [hinv]
  let f := stateSpinCoeff ψ
  have hf : Continuous f := continuous_stateSpinCoeff ψ
  let c (u : UnitSpinor) := f u / (‖f u‖ : ℂ)
  have hc : Continuous c := hf.div (Complex.continuous_ofReal.comp hf.norm)
    (fun u => Complex.ofReal_ne_zero.mpr (norm_ne_zero_iff.mpr (hn u)))
  have hc₁ (u : UnitSpinor) : ‖c u‖ = 1 := by
    unfold c
    rw [norm_div, Complex.norm_real, Real.norm_eq_abs, abs_of_nonneg (norm_nonneg _),
      div_self (norm_ne_zero_iff.mpr (hn u))]
  obtain ⟨θ,hθc,hθe⟩ := unitSpinor_phase_lift c hc hc₁
  have hθ (u : UnitSpinor) : f u = (‖f u‖ : ℂ) * Complex.exp ((θ u:ℂ)*Complex.I) := by
    rw [hθe, show c u = f u / (‖f u‖ : ℂ) from rfl]
    rw [← mul_div_assoc]
    exact (mul_div_cancel_left₀ _ (Complex.ofReal_ne_zero.mpr (norm_ne_zero_iff.mpr (hn u)))).symm
  obtain ⟨B,hB⟩ := phase_constant ψ θ hθc hθ hn
  let t := characterAngle N
  let K := spinClass (Real.cos t) (Real.sin t) (Real.cos_sq_add_sin_sq t)
  let F (y : Sphere) := Complex.exp (-(B:ℂ)*Complex.I) * f (K y)
  have hF : Continuous F := continuous_const.mul (hf.comp (continuous_spinClass ..))
  have hK (y : Sphere) : F y = (‖f (K y)‖:ℂ) := by
    unfold F
    conv_lhs => rw [hθ (K y)]
    rw [hB, mul_left_comm, ← Complex.exp_add,
      show -(B:ℂ)*Complex.I + (B:ℂ)*Complex.I = 0 by ring, Complex.exp_zero, mul_one]
  have hi : (∫ y, F y ∂areaProbability) = 0 := by
    have he := spinCoeff_class_integral ψ unitSpinorOne (Real.cos t) (Real.sin t)
      (Real.cos_sq_add_sin_sq t)
    simp only [unitSpinor_one_mul] at he
    change (∫ y, f (K y) ∂areaProbability) = _ at he
    rw [spinClassAverage_characterAngle_zero hN, mul_zero] at he
    have hzero : matrixCoeff ψ (0 : Operator N) = 0 := by simp [matrixCoeff]
    unfold F
    rw [integral_const_mul, he,hzero,mul_zero]
  have hre := integral_re (integrable_continuous_area hF)
  change (∫ y, (F y).re ∂areaProbability) = _ at hre
  rw [hi] at hre
  simp_rw [hK, Complex.ofReal_re] at hre
  have hz := continuous_positive_integral_zero (hf.comp (continuous_spinClass ..)).norm
    (fun _ => norm_nonneg _) hre
  exact hn (K northPoint) (norm_eq_zero.mp (hz northPoint))

end F18
