import F18.Definition
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

namespace F18

/-- The concrete rank-zero Clebsch–Gordan coefficient is exactly one
for every spin and every weight. -/
theorem northCG_rankZero (N : ℕ) (r : Weight N) : northCG N r 0 = 1 := by
  have hr : r.val ≤ N := Nat.le_of_lt_succ r.isLt
  unfold northCG
  simp only [Fin.val_zero, Nat.sub_zero, Nat.factorial_zero, Nat.cast_one, one_pow,
    mul_one, zero_add, Finset.sum_range_one, zero_le, true_and, if_pos hr,
    pow_zero, one_mul, Nat.add_zero]
  rw [Nat.factorial_succ, Nat.cast_mul]
  have hf : (Nat.factorial N : ℝ) ≠ 0 := by positivity
  have hN : (((N + 1 : ℕ) : ℝ)) ≠ 0 := by positivity
  rw [div_self (mul_ne_zero hN hf), Real.sqrt_one, one_mul]
  have hNr : (Nat.factorial (N - r.val) : ℝ) ≠ 0 := by positivity
  have hrr : (Nat.factorial r.val : ℝ) ≠ 0 := by positivity
  field_simp
  ring

end F18
