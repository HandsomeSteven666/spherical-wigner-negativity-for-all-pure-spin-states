import F18.EuclideanRotation
import Mathlib.Analysis.SpecialFunctions.Complex.Log
import Mathlib.Topology.UniformSpace.HeineCantor

namespace F18
open Metric Set

abbrev PhaseBall := closedBall (0:E3) 1

noncomputable def phaseBallZero : PhaseBall := ⟨0, by simp⟩

private noncomputable def phaseBallStep (m i : ℕ) (x : PhaseBall) : PhaseBall :=
  ⟨min ((i:ℝ)/((m:ℝ)+1)) 1 • x.val, by
    rw [mem_closedBall, dist_zero_right, norm_smul, Real.norm_eq_abs, abs_of_nonneg (by positivity)]
    exact mul_le_one₀ (min_le_right ..) (norm_nonneg _) (mem_closedBall_zero_iff.mp x.property)⟩

private theorem continuous_phaseBallStep (m i : ℕ) : Continuous (phaseBallStep m i) := by
  unfold phaseBallStep
  exact (continuous_const.smul continuous_subtype_val).subtype_mk _

private theorem phaseBallStep_zero (m : ℕ) (x : PhaseBall) :
    phaseBallStep m 0 x = phaseBallZero := by
  apply Subtype.ext
  simp [phaseBallStep, phaseBallZero]

private theorem phaseBallStep_end (m : ℕ) (x : PhaseBall) :
    phaseBallStep m (m+1) x = x := by
  apply Subtype.ext
  simp [phaseBallStep, show (m:ℝ)+1 ≠ 0 by positivity]

private theorem phaseBallStep_dist (m i : ℕ) (hi : i ≤ m) (x : PhaseBall) :
    dist (phaseBallStep m (i+1) x) (phaseBallStep m i x) ≤ 1/((m:ℝ)+1) := by
  have hm : 0 < (m:ℝ)+1 := by positivity
  have hi₁ : (i:ℝ) ≤ (m:ℝ) := by exact_mod_cast hi
  have h₀ : (i:ℝ)/((m:ℝ)+1) ≤ 1 := (div_le_one hm).mpr (by linarith)
  have h₁ : ((i+1:ℕ):ℝ)/((m:ℝ)+1) ≤ 1 := (div_le_one hm).mpr (by push_cast; linarith)
  change dist (min (((i+1:ℕ):ℝ)/((m:ℝ)+1)) 1 • x.val)
    (min ((i:ℝ)/((m:ℝ)+1)) 1 • x.val) ≤ _
  rw [min_eq_left h₀, min_eq_left h₁, dist_eq_norm, ← sub_smul, ← sub_div,
    show (((i+1:ℕ):ℝ)-(i:ℝ)) = 1 by push_cast; ring, norm_smul, Real.norm_eq_abs,
    abs_of_pos (one_div_pos.mpr hm)]
  exact mul_le_of_le_one_right (by positivity) (mem_closedBall_zero_iff.mp x.property)

/-- A continuous map from the closed ball into unit complex numbers has a
continuous real phase, constructed by increments of principal argument. -/
theorem phaseBall_lift (c : PhaseBall → ℂ) (hc : Continuous c) (hc₁ : ∀ x, ‖c x‖ = 1) :
    ∃ θ : PhaseBall → ℝ, Continuous θ ∧ ∀ x, Complex.exp ((θ x : ℂ)*Complex.I) = c x := by
  letI : CompactSpace PhaseBall := isCompact_iff_compactSpace.mp (isCompact_closedBall (0:E3) 1)
  obtain ⟨δ,hδ,huc⟩ := (Metric.uniformContinuous_iff.mp (CompactSpace.uniformContinuous_of_continuous hc)) 1 zero_lt_one
  obtain ⟨m,hm⟩ := exists_nat_one_div_lt hδ
  let s := phaseBallStep m
  let d (i : ℕ) (x : PhaseBall) := c (s (i+1) x) / c (s i x)
  have hn (x : PhaseBall) : c x ≠ 0 := by intro h; have hh := hc₁ x; simp [h] at hh
  have hd₁ (i : ℕ) (x : PhaseBall) : ‖d i x‖ = 1 := by simp [d, hc₁]
  have hd (i : ℕ) (hi : i < m+1) (x : PhaseBall) : d i x ∈ Complex.slitPlane := by
    have ht := huc ((phaseBallStep_dist m i (by omega) x).trans_lt hm)
    have he : d i x - 1 = (c (s (i+1) x) - c (s i x)) / c (s i x) := by
      unfold d
      rw [sub_div, div_self (hn _)]
    have hz : ‖d i x - 1‖ < 1 := by
      rw [he, norm_div, hc₁, div_one]
      simpa only [dist_eq_norm] using ht
    have hz' := Complex.mem_slitPlane_of_norm_lt_one hz
    rwa [show 1 + (d i x - 1) = d i x by ring] at hz'
  have ha (i : ℕ) (hi : i ∈ Finset.range (m+1)) : Continuous (fun x => (d i x).arg) := by
    apply continuous_iff_continuousAt.mpr
    intro x
    exact (Complex.continuousAt_arg (hd i (Finset.mem_range.mp hi) x)).comp
      (((hc.comp (continuous_phaseBallStep m (i+1))).div
        (hc.comp (continuous_phaseBallStep m i)) (fun x => hn _)).continuousAt)
  let θ (x : PhaseBall) := (c phaseBallZero).arg + ∑ i ∈ Finset.range (m+1), (d i x).arg
  refine ⟨θ,continuous_const.add (continuous_finset_sum _ ha),?_⟩
  intro x
  have harg (z : ℂ) (hz : ‖z‖ = 1) : Complex.exp ((z.arg : ℂ)*Complex.I) = z := by
    simpa [hz] using Complex.norm_mul_exp_arg_mul_I z
  have he (n : ℕ) : Complex.exp (((∑ i ∈ Finset.range n, (d i x).arg : ℝ) : ℂ)*Complex.I) =
      c (s n x) / c (s 0 x) := by
    induction n with
    | zero => simp [hn]
    | succ n ih =>
      rw [Finset.sum_range_succ, Complex.ofReal_add, add_mul, Complex.exp_add, ih,
        harg _ (hd₁ n x)]
      unfold d
      field_simp [hn]
      ring
  unfold θ
  rw [Complex.ofReal_add, add_mul, Complex.exp_add, harg _ (hc₁ _), he]
  change _ * (c (phaseBallStep m (m+1) x) / c (phaseBallStep m 0 x)) = _
  rw [phaseBallStep_end, phaseBallStep_zero]
  field_simp [hn]

end F18
