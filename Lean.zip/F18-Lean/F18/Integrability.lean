import F18.Area
import F18.Continuity
import Mathlib.MeasureTheory.Integral.Bochner.Set

namespace F18
open MeasureTheory
instance sphere_opensMeasurable : OpensMeasurableSpace Sphere := Subtype.opensMeasurableSpace _


/-- The concrete measure is finite with the mass computed in Area. -/
instance spinMeasure_finite (N : ℕ) : IsFiniteMeasure (spinMeasure N) where
  measure_univ_lt_top := by
    rw [spinMeasure_mass]
    exact ENNReal.natCast_lt_top (N + 1)

theorem integrable_spin_of_continuous {N : ℕ} (f : Sphere → ℝ) (hf : Continuous f) :
    Integrable f (spinMeasure N) := by
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  exact hf.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace f)

theorem integrable_wigner {N : ℕ} (signs : Weight N → Bool) (ψ : State N) :
    Integrable (wigner signs ψ) (spinMeasure N) :=
  integrable_spin_of_continuous _ (continuous_wigner signs ψ)

theorem integrable_wigner_product {N : ℕ} (signs : Weight N → Bool) (ψ φ : State N) :
    Integrable (fun p => wigner signs ψ p * wigner signs φ p) (spinMeasure N) :=
  integrable_spin_of_continuous _ ((continuous_wigner signs ψ).mul (continuous_wigner signs φ))

theorem integrable_wigner_negative_part {N : ℕ} (signs : Weight N → Bool) (ψ : State N) :
    Integrable (fun p => max (-wigner signs ψ p) 0) (spinMeasure N) :=
  integrable_spin_of_continuous _ ((continuous_wigner signs ψ).neg.max continuous_const)

end F18
