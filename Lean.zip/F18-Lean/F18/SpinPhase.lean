import F18.BallPhase
import F18.SpinClass
import Mathlib.Analysis.NormedSpace.Connected
import Mathlib.Analysis.Normed.Module.Convex

namespace F18
open Metric Set

private theorem normSq_re_im (u : UnitSpinor) :
    u.val.1.re^2 + u.val.1.im^2 + u.val.2.re^2 + u.val.2.im^2 = 1 := by
  simpa only [Complex.normSq_apply, pow_two, add_assoc] using u.property

private def spinPhaseCoordinates (u : UnitSpinor) : E3 :=
  (WithLp.equiv 2 _).symm ![u.val.1.im,u.val.2.re,u.val.2.im]

private theorem spinPhaseCoordinates_norm_sq (u : UnitSpinor) :
    ‖spinPhaseCoordinates u‖^2 = u.val.1.im^2 + u.val.2.re^2 + u.val.2.im^2 := by
  rw [EuclideanSpace.norm_eq, Fin.sum_univ_three]
  change (Real.sqrt (‖u.val.1.im‖^2 + ‖u.val.2.re‖^2 + ‖u.val.2.im‖^2))^2 = _
  rw [Real.sq_sqrt (by positivity)]
  simp only [Real.norm_eq_abs, sq_abs]

private noncomputable def spinPhaseProject (u : UnitSpinor) : PhaseBall :=
  ⟨spinPhaseCoordinates u, mem_closedBall_zero_iff.mpr (by
    nlinarith [spinPhaseCoordinates_norm_sq u, normSq_re_im u,
      sq_nonneg u.val.1.re, norm_nonneg (spinPhaseCoordinates u)])⟩

private theorem continuous_spinPhaseProject : Continuous spinPhaseProject := by
  unfold spinPhaseProject spinPhaseCoordinates
  apply Continuous.subtype_mk
  apply (PiLp.continuous_equiv_symm 2 (fun _ : Fin 3 => ℝ)).comp
  apply continuous_pi
  intro i
  fin_cases i <;> simp <;> fun_prop

private noncomputable def phaseBallSection (ε : ℝ) (hε : ε^2 = 1) (x : PhaseBall) : UnitSpinor :=
  ⟨(⟨ε*Real.sqrt (1-‖x.val‖^2),x.val 0⟩, ⟨x.val 1,x.val 2⟩), by
    have hx := mem_closedBall_zero_iff.mp x.property
    have hx' : 0 ≤ 1-‖x.val‖^2 := by nlinarith [norm_nonneg x.val]
    have hn : ‖x.val‖^2 = (x.val 0)^2+(x.val 1)^2+(x.val 2)^2 := by
      rw [EuclideanSpace.norm_eq, Fin.sum_univ_three, Real.sq_sqrt (by positivity)]
      simp only [Real.norm_eq_abs, sq_abs]
    simp only [Complex.normSq_apply, ← pow_two, mul_pow, hε, one_mul, Real.sq_sqrt hx']
    linarith⟩

private noncomputable def phaseBallPlus := phaseBallSection 1 (by norm_num)
private noncomputable def phaseBallMinus := phaseBallSection (-1) (by norm_num)

private theorem continuous_phaseBallSection (ε : ℝ) (hε : ε^2 = 1) :
    Continuous (phaseBallSection ε hε) := by
  unfold phaseBallSection
  apply Continuous.subtype_mk
  simp only [Complex.mk_eq_add_mul_I]
  have h (i : Fin 3) : Continuous (fun x : PhaseBall => x.val i) :=
    (continuous_apply i).comp ((PiLp.continuous_equiv 2 (fun _ : Fin 3 => ℝ)).comp continuous_subtype_val)
  have hs : Continuous (fun x : PhaseBall => Real.sqrt (1-‖x.val‖^2)) :=
    Real.continuous_sqrt.comp (continuous_const.sub (continuous_subtype_val.norm.pow 2))
  exact ((Complex.continuous_ofReal.comp (continuous_const.mul hs)).add
    ((Complex.continuous_ofReal.comp (h 0)).mul continuous_const)).prodMk
    ((Complex.continuous_ofReal.comp (h 1)).add ((Complex.continuous_ofReal.comp (h 2)).mul continuous_const))

private theorem continuous_phaseBallPlus : Continuous phaseBallPlus := continuous_phaseBallSection ..
private theorem continuous_phaseBallMinus : Continuous phaseBallMinus := continuous_phaseBallSection ..

private theorem phaseBallProject_sqrt (u : UnitSpinor) :
    Real.sqrt (1-‖(spinPhaseProject u).val‖^2) = |u.val.1.re| := by
  change Real.sqrt (1 - ‖spinPhaseCoordinates u‖^2) = _
  rw [spinPhaseCoordinates_norm_sq]
  rw [show 1 - (u.val.1.im^2 + u.val.2.re^2 + u.val.2.im^2) = u.val.1.re^2 by
    linarith [normSq_re_im u], Real.sqrt_sq_eq_abs]

private theorem phaseBallPlus_proj (u : UnitSpinor) (h : 0 ≤ u.val.1.re) :
    phaseBallPlus (spinPhaseProject u) = u := by
  apply Subtype.ext
  apply Prod.ext <;> apply Complex.ext
  · change 1 * Real.sqrt (1 - ‖(spinPhaseProject u).val‖^2) = _
    rw [one_mul, phaseBallProject_sqrt, abs_of_nonneg h]
  all_goals rfl

private theorem phaseBallMinus_proj (u : UnitSpinor) (h : u.val.1.re ≤ 0) :
    phaseBallMinus (spinPhaseProject u) = u := by
  apply Subtype.ext
  apply Prod.ext <;> apply Complex.ext
  · change (-1) * Real.sqrt (1 - ‖(spinPhaseProject u).val‖^2) = _
    rw [neg_one_mul, phaseBallProject_sqrt, abs_of_nonpos h, neg_neg]
  all_goals rfl

private noncomputable def equatorToBall (x : sphere (0:E3) 1) : PhaseBall :=
  ⟨x.val, mem_closedBall_zero_iff.mpr (mem_sphere_zero_iff_norm.mp x.property).le⟩

private theorem spinEquator_range :
    {u : UnitSpinor | u.val.1.re = 0} = range (phaseBallPlus ∘ equatorToBall) := by
  ext u
  constructor
  · intro hu
    change u.val.1.re = 0 at hu
    have hq : ‖spinPhaseCoordinates u‖^2 = 1 := by
      rw [spinPhaseCoordinates_norm_sq]
      nlinarith [normSq_re_im u]
    have hn : ‖spinPhaseCoordinates u‖ = 1 := by nlinarith [norm_nonneg (spinPhaseCoordinates u)]
    refine ⟨⟨spinPhaseCoordinates u, mem_sphere_zero_iff_norm.mpr hn⟩,?_⟩
    exact phaseBallPlus_proj u (le_of_eq hu.symm)
  · rintro ⟨x,rfl⟩
    have hn := mem_sphere_zero_iff_norm.mp x.property
    change 1 * Real.sqrt (1-‖x.val‖^2) = 0
    rw [hn]
    norm_num

private theorem connected_spinEquator : IsConnected {u : UnitSpinor | u.val.1.re = 0} := by
  have hr : 1 < Module.rank ℝ E3 := by
    rw [← Module.finrank_eq_rank]
    norm_num [E3, finrank_euclideanSpace]
  letI : ConnectedSpace (sphere (0:E3) 1) :=
    isConnected_iff_connectedSpace.mp (isConnected_sphere hr 0 zero_le_one)
  rw [spinEquator_range]
  apply isConnected_range
  exact continuous_phaseBallPlus.comp (continuous_subtype_val.subtype_mk _)

private theorem spinPhase_chart_cover :
    range phaseBallPlus ∪ range phaseBallMinus = (univ : Set UnitSpinor) := by
  apply eq_univ_of_forall
  intro u
  rcases le_total 0 u.val.1.re with h|h
  · exact Or.inl ⟨spinPhaseProject u, phaseBallPlus_proj u h⟩
  · exact Or.inr ⟨spinPhaseProject u, phaseBallMinus_proj u h⟩

instance : CompactSpace UnitSpinor := by
  letI : CompactSpace PhaseBall := isCompact_iff_compactSpace.mp (isCompact_closedBall (0:E3) 1)
  refine ⟨?_⟩
  change IsCompact (univ : Set UnitSpinor)
  rw [← spinPhase_chart_cover]
  exact (isCompact_range continuous_phaseBallPlus).union (isCompact_range continuous_phaseBallMinus)

instance : ConnectedSpace UnitSpinor := by
  letI : ConnectedSpace PhaseBall := isConnected_iff_connectedSpace.mp
    ((convex_closedBall (0:E3) 1).isConnected (nonempty_closedBall.mpr zero_le_one))
  apply connectedSpace_iff_univ.mpr
  rw [← spinPhase_chart_cover]
  obtain ⟨u,hu⟩ := connected_spinEquator.nonempty
  change u.val.1.re = 0 at hu
  exact IsConnected.union ⟨u,⟨spinPhaseProject u,phaseBallPlus_proj u hu.ge⟩,
      ⟨spinPhaseProject u,phaseBallMinus_proj u hu.le⟩⟩
    (isConnected_range continuous_phaseBallPlus) (isConnected_range continuous_phaseBallMinus)


private theorem phase_difference_mem_period (a b : ℝ)
    (h : Complex.exp ((a:ℂ)*Complex.I) = Complex.exp ((b:ℂ)*Complex.I)) :
    ∃ n : ℤ, a-b = (n:ℝ)*(2*Real.pi) := by
  obtain ⟨n,hn⟩ := Complex.exp_eq_exp_iff_exists_int.mp h
  refine ⟨n,?_⟩
  have he := congrArg Complex.im hn
  simp [Complex.mul_im, Complex.mul_re] at he
  linarith

/-- A unit complex-valued map on the exact first-column SU(2) sphere has
a global continuous real phase. No differentiability is used. -/
theorem unitSpinor_phase_lift (f : UnitSpinor → ℂ) (hf : Continuous f)
    (hn : ∀ u, ‖f u‖ = 1) :
    ∃ θ : UnitSpinor → ℝ, Continuous θ ∧
      ∀ u, Complex.exp ((θ u : ℂ)*Complex.I) = f u := by
  obtain ⟨p,hp,hpe⟩ := phaseBall_lift (f ∘ phaseBallPlus) (hf.comp continuous_phaseBallPlus)
    (fun x => hn (phaseBallPlus x))
  obtain ⟨m,hm,hme⟩ := phaseBall_lift (f ∘ phaseBallMinus) (hf.comp continuous_phaseBallMinus)
    (fun x => hn (phaseBallMinus x))
  let P := p ∘ spinPhaseProject
  let M := m ∘ spinPhaseProject
  have hP : Continuous P := hp.comp continuous_spinPhaseProject
  have hM : Continuous M := hm.comp continuous_spinPhaseProject
  have hpos (u : UnitSpinor) (hu : 0 ≤ u.val.1.re) :
      Complex.exp ((P u : ℂ)*Complex.I) = f u := by
    exact (hpe (spinPhaseProject u)).trans (congrArg f (phaseBallPlus_proj u hu))
  have hneg (u : UnitSpinor) (hu : u.val.1.re ≤ 0) :
      Complex.exp ((M u : ℂ)*Complex.I) = f u := by
    exact (hme (spinPhaseProject u)).trans (congrArg f (phaseBallMinus_proj u hu))
  let D : Set UnitSpinor := {u | u.val.1.re = 0}
  letI : ConnectedSpace D := isConnected_iff_connectedSpace.mp connected_spinEquator
  have he (u : D) : ∃ n : ℤ, P u.val - M u.val = (n:ℝ)*(2*Real.pi) :=
    phase_difference_mem_period _ _ ((hpos u.val u.property.ge).trans (hneg u.val u.property.le).symm)
  choose k hk using he
  have hπ : (2*Real.pi) ≠ 0 := by positivity
  have hcoe : (fun u : D => ((k u : ℤ) : ℝ)) = fun u => (P u.val-M u.val) / (2*Real.pi) := by
    funext u
    exact ((div_eq_iff hπ).mpr (hk u)).symm
  have hkc : Continuous k := by
    apply Int.isUniformEmbedding_coe_real.isEmbedding.continuous_iff.mpr
    change Continuous (fun u : D => (k u : ℝ))
    rw [hcoe]
    exact (((hP.sub hM).comp continuous_subtype_val).div_const _)
  obtain ⟨u₀,hu₀⟩ := connected_spinEquator.nonempty
  let n₀ := k ⟨u₀,hu₀⟩
  have hdisc := (isConnected_range hkc).isPreconnected.subsingleton
  have hperiod (u : UnitSpinor) (hu : u.val.1.re = 0) :
      P u = M u + (n₀:ℝ)*(2*Real.pi) := by
    let q : D := ⟨u,hu⟩
    have hh : k q = n₀ := hdisc ⟨q,rfl⟩ ⟨⟨u₀,hu₀⟩,rfl⟩
    have hq := hk q
    rw [hh] at hq
    change P u - M u = _ at hq
    linarith
  let A : Set UnitSpinor := {u | 0 ≤ u.val.1.re}
  let M' := fun u => M u + (n₀:ℝ)*(2*Real.pi)
  have hM' : Continuous M' := hM.add continuous_const
  classical
  let θ := A.piecewise P M'
  have hfr (u : UnitSpinor) (hu : u ∈ frontier A) : P u = M' u := by
    apply hperiod
    exact (frontier_le_subset_eq continuous_const
      (Complex.continuous_re.comp (continuous_fst.comp continuous_subtype_val)) hu).symm
  refine ⟨θ,Continuous.piecewise hfr hP hM',?_⟩
  intro u
  by_cases hu : 0 ≤ u.val.1.re
  · simpa only [θ, Set.piecewise_eq_of_mem A _ _ (show u ∈ A from hu)] using hpos u hu
  · have hval : θ u = M' u := by simp [θ, Set.piecewise, A, hu]
    rw [hval, ← hneg u (le_of_not_ge hu)]
    apply Complex.exp_eq_exp_iff_exists_int.mpr
    refine ⟨n₀,?_⟩
    simp only [M', Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_ofNat,
      Complex.ofReal_intCast]
    ring

end F18
