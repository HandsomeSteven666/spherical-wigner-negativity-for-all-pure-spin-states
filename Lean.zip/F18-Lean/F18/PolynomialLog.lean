import F18.ComplexLog
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Algebra.BigOperators.Fin

namespace F18
open Polynomial MeasureTheory

private theorem prod_get_toList {A B : Type*} [CommMonoid B] (m : Multiset A) (g : A → B) :
    (∏ i : Fin m.toList.length, g m.toList[i.val]) = (m.map g).prod := by
  rw [← List.prod_ofFn, List.ofFn_getElem_eq_map]
  rw [← Multiset.prod_coe, ← Multiset.map_coe, Multiset.coe_toList]

/-- The normalized polynomial estimate in the original paper, over complex coefficients. -/
theorem integral_log_polynomial_complex (p : ℂ[X]) (h₀ : p.eval 0 = 1) :
    IntervalIntegrable (fun s : ℝ => Real.log ‖p.eval (s : ℂ)‖) volume 0 1 ∧
    -(p.natDegree : ℝ) * (1 + Real.exp (-1)) ≤
      ∫ s in (0 : ℝ)..1, Real.log ‖p.eval (s : ℂ)‖ := by
  classical
  have hp : p ≠ 0 := by intro hp; simp [hp] at h₀
  let m := p.roots
  let I := Fin m.toList.length
  let r : I → ℂ := fun i => m.toList[i.val]
  have hr (i : I) : r i ≠ 0 := by
    intro he
    have hm : r i ∈ m := Multiset.mem_toList.mp (List.getElem_mem i.isLt)
    have hv := (Polynomial.mem_roots hp).mp hm
    change p.eval (r i) = 0 at hv
    rw [he, h₀] at hv
    exact one_ne_zero hv
  have hsplit : p.Splits (RingHom.id ℂ) := IsAlgClosed.splits p
  have hrepr (x : ℂ) : p.eval x = p.leadingCoeff * ∏ i : I, (x - r i) := by
    rw [Polynomial.eval_eq_prod_roots_sub_of_splits_id hsplit, prod_get_toList]
  have hbase : p.leadingCoeff * (∏ i : I, (-r i)) = 1 := by
    simpa only [zero_sub] using (hrepr 0).symm.trans h₀
  have hnorm (x : ℂ) : p.eval x = ∏ i : I, ((1 : ℂ) - (r i)⁻¹ * x) := by
    rw [hrepr]
    have hfactor (i : I) : x - r i = (-r i) * ((1 : ℂ) - (r i)⁻¹ * x) := by
      field_simp [hr i]
      all_goals ring
    simp_rw [hfactor]
    rw [Finset.prod_mul_distrib, ← mul_assoc, hbase, one_mul]
  have hdeg : p.natDegree = m.toList.length := by
    simpa [m] using Polynomial.natDegree_eq_card_roots hsplit
  have hcard : Fintype.card I = p.natDegree := (Fintype.card_fin _).trans hdeg.symm
  have hprod := integral_log_linear_factors (Finset.univ : Finset I) (fun i => (r i)⁻¹)
  simpa only [Finset.mem_univ, Finset.card_univ, hcard, ← hnorm] using hprod

/-- The real form, with the degree and constant used in the manuscript unchanged. -/
theorem integral_log_polynomial_real (p : ℝ[X]) (h₀ : p.eval 0 = 1) :
    IntervalIntegrable (fun s : ℝ => Real.log |p.eval s|) volume 0 1 ∧
    -(p.natDegree : ℝ) * (1 + Real.exp (-1)) ≤
      ∫ s in (0 : ℝ)..1, Real.log |p.eval s| := by
  let pc := p.map Complex.ofRealHom
  have hc : pc.eval 0 = 1 := by simp [pc, h₀]
  have he (s : ℝ) : pc.eval (s : ℂ) = ((p.eval s : ℝ) : ℂ) := by
    unfold pc
    rw [Polynomial.eval_map]
    exact Polynomial.eval₂_at_apply Complex.ofRealHom s
  have h := integral_log_polynomial_complex pc hc
  change IntervalIntegrable (fun s : ℝ => Real.log ‖pc.eval (s : ℂ)‖) volume 0 1 ∧ _ at h
  simpa only [he, Complex.norm_real, Real.norm_eq_abs, pc, Polynomial.natDegree_map] using h

end F18
