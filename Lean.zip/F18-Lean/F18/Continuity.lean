import F18.Phase
import F18.Geometry
import Mathlib.Tactic.FunProp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Topology.Instances.Matrix

namespace F18

theorem continuousAt_spinor_of_ne_south (p : Sphere) (hp : p.val.2.2 ≠ -1) :
    ContinuousAt spinor p := by
  have hcoord : Continuous (fun q : Sphere => q.val.2.2) := by fun_prop
  have hz : -1 < p.val.2.2 := by
    have h : p.val.1 ^ 2 + p.val.2.1 ^ 2 + p.val.2.2 ^ 2 = 1 := p.property
    have : -1 ≤ p.val.2.2 := by nlinarith [sq_nonneg p.val.1, sq_nonneg p.val.2.1]
    exact lt_of_le_of_ne this hp.symm
  let a : Sphere → ℝ := fun q => Real.sqrt ((1 + q.val.2.2) / 2)
  have ha : Continuous a := by
    unfold a
    fun_prop
  have hca : Continuous (fun q : Sphere => (a q : ℂ)) :=
    Complex.continuous_ofReal.comp ha
  let numerator : Sphere → ℂ := fun q => (q.val.1 : ℂ) + (q.val.2.1 : ℂ) * Complex.I
  have hnum : Continuous numerator := by
    unfold numerator
    fun_prop
  have hden : (2 : ℂ) * (a p : ℂ) ≠ 0 := by
    have hreal : 0 < a p := Real.sqrt_pos.2 (by linarith)
    exact mul_ne_zero (by norm_num) (by exact_mod_cast hreal.ne')
  let s : Sphere → ℂ × ℂ := fun q => ((a q : ℂ), numerator q / (2 * (a q : ℂ)))
  have hs : ContinuousAt s p :=
    hca.continuousAt.prodMk (hnum.continuousAt.div (continuousAt_const.mul hca.continuousAt) hden)
  refine hs.congr ?_
  filter_upwards [(isOpen_ne_fun hcoord continuous_const).mem_nhds hp] with q hq
  have hq' : q.val.2.2 ≠ -1 := hq
  simp [spinor, hq', s, numerator, a]

def flipSphere (p : Sphere) : Sphere :=
  ⟨(p.val.1, -p.val.2.1, -p.val.2.2), by
    change p.val.1 ^ 2 + (-p.val.2.1) ^ 2 + (-p.val.2.2) ^ 2 = 1
    rw [neg_sq, neg_sq]
    exact p.property⟩

theorem continuous_flipSphere : Continuous flipSphere := by
  apply Continuous.subtype_mk
  fun_prop

noncomputable def southSpinor (p : Sphere) : ℂ × ℂ :=
  ((spinor (flipSphere p)).2, (spinor (flipSphere p)).1)

theorem continuousAt_southSpinor_of_ne_north (p : Sphere) (hp : p.val.2.2 ≠ 1) :
    ContinuousAt southSpinor p := by
  have hflip : (flipSphere p).val.2.2 ≠ -1 := by
    change -p.val.2.2 ≠ -1
    intro h
    exact hp (by linarith)
  exact continuous_swap.continuousAt.comp
    ((continuousAt_spinor_of_ne_south (flipSphere p) hflip).comp continuous_flipSphere.continuousAt)

theorem kernel_eq_south (N : ℕ) (signs : Weight N → Bool) (p : Sphere) :
    kernel N signs p = kernelFromSpinor N signs (southSpinor p).1 (southSpinor p).2 := by
  rw [kernel_eq_kernelFromSpinor]
  symm
  apply kernelFromSpinor_bloch_eq
  · exact spinor_unit p
  · simpa [southSpinor, add_comm] using spinor_unit (flipSphere p)
  · rw [(spinor_norms p).1]
    change (1 + p.val.2.2) / 2 = Complex.normSq (spinor (flipSphere p)).2
    rw [(spinor_norms (flipSphere p)).2]
    simp [flipSphere, sub_neg_eq_add]
  · apply mul_left_cancel₀ (show (2 : ℂ) ≠ 0 by norm_num)
    rw [← mul_assoc, spinor_equator]
    have h := congrArg (starRingEnd ℂ) (spinor_equator (flipSphere p))
    simp only [map_mul, map_add, map_ofNat, starRingEnd_apply, star_star,
      Complex.conj_ofReal, Complex.conj_I] at h
    rw [← mul_assoc]
    change _ = (2 : ℂ) * starRingEnd ℂ (spinor (flipSphere p)).2 * (spinor (flipSphere p)).1
    rw [show (2 : ℂ) * starRingEnd ℂ (spinor (flipSphere p)).2 * (spinor (flipSphere p)).1 =
      (2 : ℂ) * (spinor (flipSphere p)).1 * starRingEnd ℂ (spinor (flipSphere p)).2 by ring]
    simp only [starRingEnd_apply]
    rw [h]
    simp only [Complex.star_def, Complex.conj_ofReal, Complex.conj_I]
    change (p.val.1 : ℂ) + (p.val.2.1 : ℂ) * Complex.I =
      (p.val.1 : ℂ) + ((-p.val.2.1 : ℝ) : ℂ) * (-Complex.I)
    push_cast
    ring

theorem continuous_spinMatrix (N : ℕ) :
    Continuous (fun v : ℂ × ℂ => spinMatrix N v.1 v.2) := by
  apply continuous_matrix
  intro r s
  unfold spinMatrix
  refine continuous_const.mul ?_
  apply continuous_finset_sum
  intro u _
  by_cases h : u ≤ r.val ∧ r.val - u ≤ s.val
  · simp only [if_pos h, starRingEnd_apply]
    fun_prop
  · simp only [if_neg h]
    exact continuous_const

theorem continuous_kernelFromSpinor (N : ℕ) (signs : Weight N → Bool) :
    Continuous (fun v : ℂ × ℂ => kernelFromSpinor N signs v.1 v.2) := by
  unfold kernelFromSpinor
  have h := continuous_spinMatrix N
  exact (h.mul continuous_const).mul ((continuous_matrix fun i j => by
    change Continuous (fun v : ℂ × ℂ => star (spinMatrix N v.1 v.2 j i))
    have hij := h.matrix_elem j i
    exact hij.star))

/-- The concrete covariant kernel is continuous across both poles. -/
theorem continuous_kernel (N : ℕ) (signs : Weight N → Bool) :
    Continuous (kernel N signs) := by
  rw [continuous_iff_continuousAt]
  intro p
  by_cases hp : p.val.2.2 = -1
  · have hn : p.val.2.2 ≠ 1 := by rw [hp]; norm_num
    have h := (continuous_kernelFromSpinor N signs).continuousAt.comp
      (continuousAt_southSpinor_of_ne_north p hn)
    exact h.congr (Filter.Eventually.of_forall (fun q => (kernel_eq_south N signs q).symm))
  · have h := (continuous_kernelFromSpinor N signs).continuousAt.comp
      (continuousAt_spinor_of_ne_south p hp)
    exact h.congr (Filter.Eventually.of_forall (fun q => (kernel_eq_kernelFromSpinor N signs q).symm))

theorem continuous_wigner {N : ℕ} (signs : Weight N → Bool) (ψ : State N) :
    Continuous (wigner signs ψ) := by
  unfold wigner
  have h := continuous_kernel N signs
  have hprod : Continuous (fun p => projector ψ * kernel N signs p) := continuous_const.mul h
  have htrace : Continuous (fun p => Matrix.trace (projector ψ * kernel N signs p)) := by
    unfold Matrix.trace
    exact continuous_finset_sum _ (fun i _ => hprod.matrix_elem i i)
  exact Complex.continuous_re.comp htrace

/-- Equivalence of the two exact statements, without a continuity assumption. -/
theorem minimum_iff_allSigns : OriginalMinimumNegativity ↔ OriginalAllSigns := by
  constructor
  · exact allSigns_of_minimum
  · intro h N hN signs ψ hψ
    exact negative_minimum_of_continuous _ (continuous_wigner signs ψ) (h N hN signs ψ hψ)

end F18
