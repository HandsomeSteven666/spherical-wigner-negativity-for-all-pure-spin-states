import Mathlib.MeasureTheory.Constructions.HaarToSphere
import Mathlib.MeasureTheory.Measure.Haar.InnerProductSpace

namespace F18
open MeasureTheory Set Metric
open scoped Pointwise

variable {E : Type*} [NormedAddCommGroup E] [InnerProductSpace ℝ E]

/-- An ambient orthogonal map acting on the norm unit sphere. -/
def sphereOfLinearIso (L : E ≃ₗᵢ[ℝ] E) (p : sphere (0 : E) 1) : sphere (0 : E) 1 :=
  ⟨L p.val, by
    have hp : ‖p.val‖ = 1 := by simpa only [mem_sphere, dist_zero_right] using p.property
    simpa only [mem_sphere, dist_zero_right, L.norm_map] using hp⟩

theorem continuous_sphereOfLinearIso (L : E ≃ₗᵢ[ℝ] E) :
    Continuous (sphereOfLinearIso L) :=
  (L.continuous.comp continuous_subtype_val).subtype_mk _

private theorem linearIso_preimage_cone (L : E ≃ₗᵢ[ℝ] E) (S : Set (sphere (0 : E) 1)) :
    L ⁻¹' (Ioo (0 : ℝ) 1 • (Subtype.val '' S)) =
      Ioo (0 : ℝ) 1 • (Subtype.val '' ((sphereOfLinearIso L) ⁻¹' S)) := by
  ext x
  constructor
  · intro hx
    change L x ∈ Ioo (0 : ℝ) 1 • (Subtype.val '' S) at hx
    obtain ⟨r,hr,y,⟨p,hp,rfl⟩,he⟩ := Set.mem_smul.mp hx
    let q := sphereOfLinearIso L.symm p
    have hq : sphereOfLinearIso L q = p := by
      apply Subtype.ext
      exact L.apply_symm_apply p.val
    have hxq : r • q.val = x := by
      apply L.injective
      rw [L.map_smul]
      exact (congrArg (fun z : E => r • z) (congrArg Subtype.val hq)).trans he
    have hmem : q ∈ sphereOfLinearIso L ⁻¹' S := by
      change sphereOfLinearIso L q ∈ S
      rwa [hq]
    exact Set.mem_smul.mpr ⟨r,hr,q.val,⟨q,hmem,rfl⟩,hxq⟩
  · intro hx
    obtain ⟨r,hr,y,⟨q,hq,rfl⟩,he⟩ := Set.mem_smul.mp hx
    change L x ∈ Ioo (0 : ℝ) 1 • (Subtype.val '' S)
    refine Set.mem_smul.mpr ⟨r,hr,L q.val,⟨sphereOfLinearIso L q,hq,rfl⟩,?_⟩
    rw [← L.map_smul, he]

/-- Radial-cone area is invariant under every ambient orthogonal map, including
reflections. The separate polar-chart calculation links this measure to F18. -/
theorem sphereOfLinearIso_preserves_toSphere [MeasurableSpace E] [BorelSpace E]
    [FiniteDimensional ℝ E] (L : E ≃ₗᵢ[ℝ] E) :
    MeasurePreserving (sphereOfLinearIso L) (volume : Measure E).toSphere
      (volume : Measure E).toSphere := by
  have hm := (continuous_sphereOfLinearIso L).measurable
  refine ⟨hm, Measure.ext fun S hS => ?_⟩
  rw [Measure.map_apply hm hS, Measure.toSphere_apply' _ (hm hS), Measure.toSphere_apply' _ hS,
    ← linearIso_preimage_cone]
  rw [L.measurePreserving.measure_preimage_emb L.toHomeomorph.measurableEmbedding]

end F18
