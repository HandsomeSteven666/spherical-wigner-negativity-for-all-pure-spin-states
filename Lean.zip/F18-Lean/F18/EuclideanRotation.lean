import F18.BlochAction
import F18.RadialInvariance
import F18.ClosingAssembly

namespace F18
open Metric
open scoped Matrix

abbrev E3 := EuclideanSpace ℝ (Fin 3)

def sphereEuclideanCoords (p : Sphere) : E3 :=
  (WithLp.equiv 2 _).symm ![p.val.1, p.val.2.1, p.val.2.2]

theorem sphereEuclideanCoords_norm (p : Sphere) : ‖sphereEuclideanCoords p‖ = 1 := by
  rw [EuclideanSpace.norm_eq, Fin.sum_univ_three]
  change Real.sqrt (‖p.val.1‖^2 + ‖p.val.2.1‖^2 + ‖p.val.2.2‖^2) = 1
  simp only [Real.norm_eq_abs, sq_abs, p.property, Real.sqrt_one]

/-- Identification of the original Cartesian subtype with the Euclidean sphere. -/
noncomputable def sphereEuclidean : Sphere ≃ sphere (0 : E3) 1 where
  toFun p := ⟨sphereEuclideanCoords p, by simpa only [mem_sphere, dist_zero_right] using sphereEuclideanCoords_norm p⟩
  invFun z := ⟨(z.val 0, z.val 1, z.val 2), by
    have h : ‖z.val‖ = 1 := by simpa only [mem_sphere, dist_zero_right] using z.property
    rw [EuclideanSpace.norm_eq, Fin.sum_univ_three] at h
    simp only [Real.norm_eq_abs, sq_abs] at h
    have hs : 0 ≤ z.val 0 ^ 2 + z.val 1 ^ 2 + z.val 2 ^ 2 := by positivity
    have he := Real.sq_sqrt hs
    rw [h] at he
    nlinarith⟩
  left_inv p := by apply Subtype.ext; rfl
  right_inv z := by
    apply Subtype.ext
    ext i
    fin_cases i <;> rfl

private def axisTriple (i : Fin 3) : Sphere :=
  if i = 0 then ⟨(1,0,0), by norm_num⟩ else
    if i = 1 then ⟨(0,1,0), by norm_num⟩ else ⟨(0,0,1), by norm_num⟩

private theorem sphereDot_axisTriple (p : Sphere) (i : Fin 3) :
    sphereDot p (axisTriple i) = sphereEuclideanCoords p i := by
  fin_cases i <;> simp [axisTriple, sphereDot, sphereEuclideanCoords, WithLp.equiv_symm_pi_apply]

private theorem spinorRotation_dot_inv (u : UnitSpinor) (p q : Sphere) :
    sphereDot (spinorRotation u p) q = sphereDot p (spinorRotation (unitSpinorInv u) q) := by
  conv_lhs => rw [← spinorRotation_inv_right u q]
  exact spinorRotation_dot u p (spinorRotation (unitSpinorInv u) q)

private noncomputable def euclideanRotationLinear (u : UnitSpinor) : E3 →ₗ[ℝ] E3 :=
  Matrix.toEuclideanLin (fun i j => sphereEuclideanCoords (spinorRotation (unitSpinorInv u) (axisTriple i)) j)

theorem euclideanRotationLinear_on_sphere (u : UnitSpinor) (p : Sphere) :
    euclideanRotationLinear u (sphereEuclideanCoords p) = sphereEuclideanCoords (spinorRotation u p) := by
  ext i
  rw [← sphereDot_axisTriple, spinorRotation_dot_inv, euclideanRotationLinear,
    Matrix.toEuclideanLin_apply, WithLp.equiv_symm_pi_apply, Matrix.mulVec, dotProduct,
    Fin.sum_univ_three]
  simp [sphereEuclideanCoords, WithLp.equiv_symm_pi_apply, sphereDot]
  ring

private theorem euclideanRotationLinear_norm (u : UnitSpinor) (x : E3) :
    ‖euclideanRotationLinear u x‖ = ‖x‖ := by
  by_cases hx : x = 0
  · simp [hx]
  have hn : 0 < ‖x‖ := norm_pos_iff.mpr hx
  let z : sphere (0 : E3) 1 := ⟨‖x‖⁻¹ • x, by
    rw [mem_sphere, dist_zero_right, norm_smul, Real.norm_eq_abs,
      abs_of_nonneg (by positivity), inv_mul_cancel₀ hn.ne']⟩
  let p := sphereEuclidean.symm z
  have hp : sphereEuclideanCoords p = z.val := congrArg Subtype.val (sphereEuclidean.apply_symm_apply z)
  have he : ‖x‖ • sphereEuclideanCoords p = x := by
    rw [hp]
    change ‖x‖ • (‖x‖⁻¹ • x) = x
    rw [smul_smul, mul_inv_cancel₀ hn.ne', one_smul]
  conv_lhs => rw [← he, map_smul, euclideanRotationLinear_on_sphere]
  rw [norm_smul, sphereEuclideanCoords_norm, mul_one, Real.norm_eq_abs, abs_of_pos hn]

private noncomputable def euclideanRotationEmbedding (u : UnitSpinor) : E3 →ₗᵢ[ℝ] E3 :=
  ⟨euclideanRotationLinear u, euclideanRotationLinear_norm u⟩

noncomputable def euclideanRotation (u : UnitSpinor) : E3 ≃ₗᵢ[ℝ] E3 :=
  LinearIsometryEquiv.ofSurjective (euclideanRotationEmbedding u)
    (LinearMap.surjective_of_injective (euclideanRotationEmbedding u).injective)

/-- The original spinor action is the restriction of an ambient linear isometry. -/
theorem euclideanRotation_on_sphere (u : UnitSpinor) (p : Sphere) :
    euclideanRotation u (sphereEuclideanCoords p) = sphereEuclideanCoords (spinorRotation u p) :=
  euclideanRotationLinear_on_sphere u p

theorem sphereEuclidean_rotation (u : UnitSpinor) (p : Sphere) :
    sphereEuclidean (spinorRotation u p) = sphereOfLinearIso (euclideanRotation u) (sphereEuclidean p) := by
  apply Subtype.ext
  exact (euclideanRotation_on_sphere u p).symm


/-- The Cartesian and Euclidean models have the same sphere topology. -/
noncomputable def sphereEuclideanHomeomorph : Sphere ≃ₜ sphere (0 : E3) 1 where
  toEquiv := sphereEuclidean
  continuous_toFun := by
    change Continuous (fun p : Sphere => (⟨sphereEuclideanCoords p, _⟩ : sphere (0 : E3) 1))
    apply Continuous.subtype_mk
    unfold sphereEuclideanCoords
    apply (PiLp.continuous_equiv_symm 2 (fun _ : Fin 3 => ℝ)).comp
    apply continuous_pi
    intro i
    fin_cases i <;> simp <;> fun_prop
  continuous_invFun := by
    change Continuous (fun z : sphere (0 : E3) 1 => (⟨(z.val 0,z.val 1,z.val 2),_⟩ : Sphere))
    apply Continuous.subtype_mk
    have h (i : Fin 3) : Continuous (fun z : sphere (0 : E3) 1 => z.val i) :=
      (continuous_apply i).comp ((PiLp.continuous_equiv 2 (fun _ : Fin 3 => ℝ)).comp continuous_subtype_val)
    exact (h 0).prodMk ((h 1).prodMk (h 2))


open MeasureTheory

/-- After matching the polar area with normalized radial area, invariance
transfers back to the exact original Cartesian spinor action. -/
theorem sphereRotationInvariant_of_radialArea
    (harea : Measure.map sphereEuclidean areaProbability =
      ENNReal.ofReal ((4*Real.pi)⁻¹) • (volume : Measure E3).toSphere) :
    SphereRotationInvariant := by
  intro u
  letI : BorelSpace Sphere := Subtype.borelSpace _
  let e := sphereEuclideanHomeomorph.toMeasurableEquiv
  have hR := sphereOfLinearIso_preserves_toSphere (euclideanRotation u)
  have hspin := (continuous_spinorRotation u).measurable
  refine ⟨hspin, e.map_measurableEquiv_injective ?_⟩
  change Measure.map sphereEuclidean (Measure.map (spinorRotation u) areaProbability) =
    Measure.map sphereEuclidean areaProbability
  have he : Measurable sphereEuclidean := sphereEuclideanHomeomorph.continuous_toFun.measurable
  rw [Measure.map_map he hspin, show (sphereEuclidean ∘ spinorRotation u) =
    sphereOfLinearIso (euclideanRotation u) ∘ sphereEuclidean from funext (sphereEuclidean_rotation u),
    ← Measure.map_map hR.measurable he, harea, Measure.map_smul, hR.map_eq]


/-- Regroup Euclidean coordinates as a horizontal Cartesian pair and a height,
with the product Lebesgue measure used in planar polar coordinates. -/
def euclideanCartesian (z : E3) : (ℝ × ℝ) × ℝ :=
  ((z 0,z 1),z 2)

theorem euclideanCartesian_measurePreserving :
    MeasurePreserving euclideanCartesian (volume : Measure E3) volume := by
  have h₁ := PiLp.volume_preserving_equiv (ι := Fin 3)
  have h₂ := volume_preserving_piFinSuccAbove (fun _ : Fin 3 => ℝ) 2
  have h₃ := (MeasurePreserving.id (volume : Measure ℝ)).prod
    (volume_preserving_piFinTwo (fun _ : Fin 2 => ℝ))
  have h₄ := Measure.measurePreserving_swap (μ := (volume : Measure ℝ))
    (ν := (volume : Measure (ℝ × ℝ)))
  have h := h₄.comp (h₃.comp (h₂.comp h₁))
  convert h using 1

end F18
