import F18.BlochAction
import F18.MatrixFacts
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.Algebra.BigOperators.Fin

namespace F18
open Polynomial
open scoped Polynomial Matrix

private noncomputable def affine (a b : ℂ) : ℂ[X] := C a + C b * X

private theorem affine_pow (a b : ℂ) (n : ℕ) :
    affine a b ^ n = ∑ k ∈ Finset.range (n+1),
      C (a ^ (n-k) * b ^ k * (n.choose k : ℂ)) * X ^ k := by
  rw [affine, add_comm, add_pow]
  apply Finset.sum_congr rfl
  intro k _
  simp only [mul_pow, map_mul, map_pow, map_natCast]
  ring

private theorem coeff_affine_pow (a b : ℂ) (n k : ℕ) :
    (affine a b ^ n).coeff k = a^(n-k) * b^k * (n.choose k : ℂ) := by
  rw [affine_pow, finset_sum_coeff]
  simp_rw [coeff_C_mul_X_pow]
  by_cases hk : k ∈ Finset.range (n+1)
  · rw [Finset.sum_eq_single k, if_pos rfl]
    · intro j _ hj
      exact if_neg (Ne.symm hj)
    · exact fun h => (h hk).elim
  · have h : n < k := by simpa [Finset.mem_range] using hk
    rw [Nat.choose_eq_zero_of_lt h, Nat.cast_zero, mul_zero]
    apply Finset.sum_eq_zero
    intro j hj
    exact if_neg (fun e : k = j => hk (e.symm ▸ hj))

noncomputable def rootChoose (N : ℕ) (r : Weight N) : ℂ :=
  (Real.sqrt (N.choose r.val : ℝ) : ℂ)

theorem rootChoose_ne_zero (N : ℕ) (r : Weight N) :
    rootChoose N r ≠ 0 := by
  unfold rootChoose
  exact_mod_cast (Real.sqrt_pos.mpr (by exact_mod_cast Nat.choose_pos (Nat.le_of_lt_succ r.isLt))).ne'

private theorem rootChoose_sq (N : ℕ) (r : Weight N) :
    rootChoose N r ^ 2 = (N.choose r.val : ℂ) := by
  unfold rootChoose
  exact_mod_cast Real.sq_sqrt (show (0 : ℝ) ≤ (N.choose r.val : ℝ) by positivity)

theorem rootChoose_star (N : ℕ) (r : Weight N) :
    starRingEnd ℂ (rootChoose N r) = rootChoose N r := Complex.conj_ofReal _

/-- The exact factorial/binomial matrix in the manuscript is the coefficient
matrix of the symmetric power, in its normalized basis. -/
theorem spinMatrix_coeff (N : ℕ) (a b : ℂ) (r s : Weight N) :
    spinMatrix N a b r s =
      (rootChoose N s / rootChoose N r) *
        (affine a b ^ (N-s.val) * affine (-starRingEnd ℂ b) (starRingEnd ℂ a) ^ s.val).coeff r.val := by
  unfold spinMatrix
  have hroot : (Real.sqrt ((N.choose s.val : ℝ) / (N.choose r.val : ℝ)) : ℂ) =
      rootChoose N s / rootChoose N r := by
    rw [Real.sqrt_div (by positivity)]
    push_cast
    rfl
  rw [hroot]
  congr 1
  rw [affine_pow a b, Finset.sum_mul, finset_sum_coeff]
  apply Finset.sum_congr rfl
  intro k _
  simp only [mul_assoc, coeff_C_mul, coeff_X_pow_mul']
  by_cases hkr : k ≤ r.val
  · rw [if_pos hkr, coeff_affine_pow]
    by_cases hks : r.val-k ≤ s.val
    · rw [if_pos ⟨hkr,hks⟩]
      ring
    · rw [if_neg (fun h => hks h.2), Nat.choose_eq_zero_of_lt (by omega : s.val < r.val-k)]
      simp
  · simp [hkr]

/-- A normalized symmetric-power monomial vector; its input need not be unit. -/
noncomputable def coherentVec (N : ℕ) (z : ℂ × ℂ) : State N :=
  fun r => rootChoose N r * z.1 ^ (N-r.val) * z.2 ^ r.val

/-- The fundamental-column convention applied in ℂ². -/
noncomputable def spinPair (a b : ℂ) (z : ℂ × ℂ) : ℂ × ℂ :=
  (a*z.1 - starRingEnd ℂ b*z.2, b*z.1 + starRingEnd ℂ a*z.2)

private theorem affine_spinPair (a b : ℂ) (z : ℂ × ℂ) :
    C z.1 * affine a b + C z.2 * affine (-starRingEnd ℂ b) (starRingEnd ℂ a) =
      affine (spinPair a b z).1 (spinPair a b z).2 := by
  simp only [affine, spinPair, map_add, map_sub, map_mul, map_neg]
  ring


/-- Acting on the coherent vector is the same as acting on its generating
spinor before taking its normalized degree-N monomials. -/
theorem spinMatrix_coherentVec (N : ℕ) (a b : ℂ) (z : ℂ × ℂ) :
    spinMatrix N a b *ᵥ coherentVec N z = coherentVec N (spinPair a b z) := by
  funext r
  let p := affine a b
  let q := affine (-starRingEnd ℂ b) (starRingEnd ℂ a)
  let g := spinPair a b z
  have h : (affine g.1 g.2 ^ N).coeff r.val =
      ∑ s : Weight N, z.2 ^ s.val * z.1 ^ (N-s.val) *
        (N.choose s.val : ℂ) * (p ^ (N-s.val) * q ^ s.val).coeff r.val := by
    rw [← affine_spinPair a b z, add_comm, add_pow, Finset.sum_range, finset_sum_coeff]
    apply Finset.sum_congr rfl
    intro s _
    change ((C z.2 * q) ^ s.val * (C z.1 * p) ^ (N-s.val) *
      (N.choose s.val : ℂ[X])).coeff r.val = _
    have he : (C z.2 * q) ^ s.val * (C z.1 * p) ^ (N-s.val) *
        (N.choose s.val : ℂ[X]) =
        C (z.2 ^ s.val * z.1 ^ (N-s.val) * (N.choose s.val : ℂ)) *
          (p ^ (N-s.val) * q ^ s.val) := by
      simp only [mul_pow, map_mul, map_pow, map_natCast]
      ring
    rw [he, coeff_C_mul]
  rw [coeff_affine_pow] at h
  have hr := rootChoose_ne_zero N r
  apply (mul_right_cancel₀ hr)
  simp only [Matrix.mulVec, dotProduct, Finset.sum_mul, spinMatrix_coeff, coherentVec]
  change (∑ s : Weight N, (rootChoose N s / rootChoose N r *
    (p ^ (N-s.val) * q ^ s.val).coeff r.val *
    (rootChoose N s * z.1^(N-s.val) * z.2^s.val)) * rootChoose N r) = _
  calc
    _ = ∑ s : Weight N, z.2 ^ s.val * z.1 ^ (N-s.val) *
        (N.choose s.val : ℂ) * (p ^ (N-s.val) * q ^ s.val).coeff r.val := by
      apply Finset.sum_congr rfl
      intro s _
      rw [← rootChoose_sq]
      field_simp [hr]
      ring
    _ = _ := by
      rw [← h, ← rootChoose_sq]
      ring

/-- Powers of one complex variable separate the coordinate functionals. -/
theorem coefficients_eq_of_power_sum (N : ℕ) (c d : Weight N → ℂ)
    (h : ∀ z : ℂ, (∑ s : Weight N, c s * z ^ s.val) =
      ∑ s : Weight N, d s * z ^ s.val) : c = d := by
  let P (e : Weight N → ℂ) : ℂ[X] := ∑ s : Weight N, C (e s) * X ^ s.val
  have he : ∀ e r, (P e).coeff r.val = e r := by
    intro e r
    unfold P
    rw [finset_sum_coeff, Finset.sum_eq_single r, coeff_C_mul_X_pow, if_pos rfl]
    · intro s _ hs
      exact (coeff_C_mul_X_pow ..).trans (if_neg fun h => hs (Fin.ext h.symm))
    · simp
  have hP : P c = P d := Polynomial.funext fun z => by
    simpa only [P, eval_finset_sum, eval_mul, eval_C, eval_pow, eval_X] using h z
  funext r
  rw [← he c r, ← he d r, hP]

theorem matrix_ext_coherent {N : ℕ} (A B : Operator N)
    (h : ∀ z : ℂ, A *ᵥ coherentVec N (1,z) = B *ᵥ coherentVec N (1,z)) :
    A = B := by
  ext r s
  have h' : (fun j => A r j * rootChoose N j) = fun j => B r j * rootChoose N j := by
    apply coefficients_eq_of_power_sum N
    intro z
    have hz := congrFun (h z) r
    simpa only [Matrix.mulVec, dotProduct, coherentVec, one_pow, mul_one, mul_assoc] using hz
  exact mul_right_cancel₀ (rootChoose_ne_zero N s) (congrFun h' s)

private theorem spinPair_one (z : ℂ × ℂ) : spinPair 1 0 z = z := by simp [spinPair]

private theorem spinPair_comp (a b c d : ℂ) (z : ℂ × ℂ) :
    spinPair a b (spinPair c d z) =
      spinPair (spinPair a b (c,d)).1 (spinPair a b (c,d)).2 z := by
  apply Prod.ext <;> simp only [spinPair, map_add, map_sub, map_mul, Complex.conj_conj] <;> ring

theorem spinMatrix_one (N : ℕ) : spinMatrix N 1 0 = 1 := by
  apply matrix_ext_coherent
  intro z
  rw [spinMatrix_coherentVec, spinPair_one, Matrix.one_mulVec]

theorem spinMatrix_mul_unitSpinor (N : ℕ) (u v : UnitSpinor) :
    spinMatrix N (unitSpinorMul u v).val.1 (unitSpinorMul u v).val.2 =
      spinMatrix N u.val.1 u.val.2 * spinMatrix N v.val.1 v.val.2 := by
  apply matrix_ext_coherent
  intro z
  rw [← Matrix.mulVec_mulVec, spinMatrix_coherentVec, spinMatrix_coherentVec,
    spinMatrix_coherentVec, spinPair_comp]
  rfl


noncomputable def pairInner (z w : ℂ × ℂ) : ℂ :=
  starRingEnd ℂ z.1 * w.1 + starRingEnd ℂ z.2 * w.2

theorem coherentVec_inner (N : ℕ) (z w : ℂ × ℂ) :
    star (coherentVec N z) ⬝ᵥ coherentVec N w = pairInner z w ^ N := by
  unfold pairInner
  conv_rhs => rw [add_comm, add_pow, Finset.sum_range]
  apply Finset.sum_congr rfl
  intro r _
  simp only [coherentVec, Pi.star_apply, ← starRingEnd_apply, map_mul, map_pow,
    rootChoose_star, mul_pow, ← rootChoose_sq]
  ring

private theorem spinPair_inner (u : UnitSpinor) (z w : ℂ × ℂ) :
    pairInner (spinPair u.val.1 u.val.2 z) (spinPair u.val.1 u.val.2 w) = pairInner z w := by
  have hu : (Complex.normSq u.val.1 : ℂ) + (Complex.normSq u.val.2 : ℂ) = 1 := by
    exact_mod_cast u.property
  calc
    _ = pairInner z w *
        (u.val.1 * starRingEnd ℂ u.val.1 + u.val.2 * starRingEnd ℂ u.val.2) := by
      simp only [pairInner, spinPair, map_add, map_sub, map_mul, Complex.conj_conj]
      ring
    _ = _ := by rw [Complex.mul_conj, Complex.mul_conj, hu, mul_one]

private theorem vector_ext_coherent {N : ℕ} (v w : State N)
    (h : ∀ z : ℂ, star (coherentVec N (1,z)) ⬝ᵥ v =
      star (coherentVec N (1,z)) ⬝ᵥ w) : v = w := by
  have hc : (fun r => rootChoose N r * v r) = fun r => rootChoose N r * w r := by
    apply coefficients_eq_of_power_sum N
    intro z
    have hz := h (starRingEnd ℂ z)
    unfold dotProduct at hz
    simp only [coherentVec, Pi.star_apply, ← starRingEnd_apply, map_mul, map_pow,
      one_pow, mul_one, rootChoose_star, Complex.conj_conj] at hz
    simpa only [mul_right_comm] using hz
  funext r
  exact mul_left_cancel₀ (rootChoose_ne_zero N r) (congrFun hc r)

/-- The original normalized matrix preserves the standard complex inner product. -/
theorem spinMatrix_conjTranspose_mul_self (N : ℕ) (u : UnitSpinor) :
    (spinMatrix N u.val.1 u.val.2)ᴴ * spinMatrix N u.val.1 u.val.2 = 1 := by
  let U := spinMatrix N u.val.1 u.val.2
  change Uᴴ * U = 1
  apply matrix_ext_coherent
  intro z
  rw [← Matrix.mulVec_mulVec, Matrix.one_mulVec]
  apply vector_ext_coherent
  intro w
  rw [Matrix.dotProduct_mulVec, ← Matrix.star_mulVec]
  simp only [U, spinMatrix_coherentVec, coherentVec_inner, spinPair_inner]

theorem spinMatrix_inv_eq_conjTranspose (N : ℕ) (u : UnitSpinor) :
    spinMatrix N (unitSpinorInv u).val.1 (unitSpinorInv u).val.2 =
      (spinMatrix N u.val.1 u.val.2)ᴴ := by
  let U := spinMatrix N u.val.1 u.val.2
  let V := spinMatrix N (unitSpinorInv u).val.1 (unitSpinorInv u).val.2
  have hu : U * V = 1 := by
    rw [← spinMatrix_mul_unitSpinor N u (unitSpinorInv u),
      unitSpinorMul_inv]
    exact spinMatrix_one N
  have hunit : Uᴴ * U = 1 := spinMatrix_conjTranspose_mul_self N u
  change V = Uᴴ
  calc
    V = (Uᴴ * U) * V := by rw [hunit, one_mul]
    _ = Uᴴ := by rw [mul_assoc, hu, mul_one]

theorem spinMatrix_mul_conjTranspose (N : ℕ) (u : UnitSpinor) :
    spinMatrix N u.val.1 u.val.2 * (spinMatrix N u.val.1 u.val.2)ᴴ = 1 := by
  rw [← spinMatrix_inv_eq_conjTranspose N u, ← spinMatrix_mul_unitSpinor N u (unitSpinorInv u),
    unitSpinorMul_inv]
  exact spinMatrix_one N


/-- Exact covariance of the concrete kernel under the original sphere action. -/
theorem kernel_spinorRotation (N : ℕ) (signs : Weight N → Bool) (u : UnitSpinor) (p : Sphere) :
    kernel N signs (spinorRotation u p) =
      spinMatrix N u.val.1 u.val.2 * kernel N signs p *
        (spinMatrix N u.val.1 u.val.2)ᴴ := by
  conv_lhs => rw [spinorRotation, kernel_bloch]
  conv_rhs => rw [← bloch_liftSpinor p, kernel_bloch]
  simp only [kernelFromSpinor, spinMatrix_mul_unitSpinor, Matrix.conjTranspose_mul,
    Matrix.mul_assoc]

theorem projector_mulVec {N : ℕ} (A : Operator N) (ψ : State N) :
    projector (A *ᵥ ψ) = A * projector ψ * Aᴴ := by
  ext i j
  simp only [projector, Matrix.mul_apply, Matrix.mulVec, dotProduct,
    Matrix.conjTranspose_apply, ← starRingEnd_apply, map_sum, map_mul,
    Finset.sum_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k _
  apply Finset.sum_congr rfl
  intro l _
  ring

theorem wigner_spinorRotation {N : ℕ} (signs : Weight N → Bool) (u : UnitSpinor)
    (ψ : State N) (p : Sphere) :
    wigner signs ((spinMatrix N u.val.1 u.val.2)ᴴ *ᵥ ψ) p =
      wigner signs ψ (spinorRotation u p) := by
  unfold wigner
  rw [kernel_spinorRotation, projector_mulVec, Matrix.conjTranspose_conjTranspose]
  congr 1
  let A := spinMatrix N u.val.1 u.val.2
  change Matrix.trace (Aᴴ * projector ψ * A * kernel N signs p) =
    Matrix.trace (projector ψ * (A * kernel N signs p * Aᴴ))
  rw [Matrix.mul_assoc, Matrix.mul_assoc, Matrix.trace_mul_comm Aᴴ]
  simp only [Matrix.mul_assoc]

theorem squaredNorm_mulVec_spinMatrix {N : ℕ} (u : UnitSpinor) (ψ : State N) :
    squaredNorm (spinMatrix N u.val.1 u.val.2 *ᵥ ψ) = squaredNorm ψ := by
  have he (φ : State N) : ((squaredNorm φ : ℝ) : ℂ) = star φ ⬝ᵥ φ := by
    simp only [squaredNorm, Complex.ofReal_sum, dotProduct, Pi.star_apply,
      ← starRingEnd_apply]
    apply Finset.sum_congr rfl
    intro r _
    rw [mul_comm, Complex.mul_conj]
  apply Complex.ofReal_injective
  rw [he, he, Matrix.star_mulVec, ← Matrix.dotProduct_mulVec, Matrix.mulVec_mulVec,
    spinMatrix_conjTranspose_mul_self, Matrix.one_mulVec]


theorem spinMatrix_diagonal_entry (N : ℕ) (a : ℂ) (r s : Weight N) :
    spinMatrix N a 0 r s =
      if r = s then a ^ (N-s.val) * starRingEnd ℂ a ^ s.val else 0 := by
  rw [spinMatrix_coeff]
  simp only [affine, map_zero, zero_mul, add_zero, neg_zero, zero_add, ← map_pow, mul_pow,
    ← mul_assoc, ← map_mul, coeff_C_mul_X_pow]
  by_cases hrs : r = s
  · subst r
    rw [if_pos rfl, if_pos rfl, div_self (rootChoose_ne_zero N s), one_mul]
  · rw [if_neg hrs, if_neg (fun h => hrs (Fin.ext h)), mul_zero]

theorem spinMatrix_column_zero (N : ℕ) (a b : ℂ) (r : Weight N) :
    spinMatrix N a b r 0 = coherentVec N (a,b) r := by
  rw [spinMatrix_coeff]
  simp only [Fin.val_zero, Nat.sub_zero, pow_zero, mul_one, coeff_affine_pow, coherentVec]
  have h0 : rootChoose N 0 = 1 := by simp [rootChoose]
  rw [h0, ← rootChoose_sq N r]
  field_simp [rootChoose_ne_zero N r]
  ring

theorem spinMatrix_column_zero_ne_zero (N : ℕ) {a b : ℂ}
    (ha : a ≠ 0) (hb : b ≠ 0) (r : Weight N) :
    spinMatrix N a b r 0 ≠ 0 := by
  rw [spinMatrix_column_zero]
  exact mul_ne_zero (mul_ne_zero (rootChoose_ne_zero N r) (pow_ne_zero _ ha)) (pow_ne_zero _ hb)

theorem coherentVec_unit {N : ℕ} (u : UnitSpinor) : squaredNorm (coherentVec N u.val) = 1 := by
  have hc (ψ : State N) : ((squaredNorm ψ : ℝ) : ℂ) = star ψ ⬝ᵥ ψ := by
    simp only [squaredNorm, Complex.ofReal_sum, dotProduct, Pi.star_apply, ← starRingEnd_apply]
    apply Finset.sum_congr rfl
    intro r _
    rw [mul_comm, Complex.mul_conj]
  have hu : pairInner u.val u.val = 1 := by
    unfold pairInner
    rw [mul_comm (starRingEnd ℂ u.val.1), Complex.mul_conj,
      mul_comm (starRingEnd ℂ u.val.2), Complex.mul_conj]
    exact_mod_cast u.property
  apply Complex.ofReal_injective
  rw [hc, coherentVec_inner, hu, one_pow, Complex.ofReal_one]


theorem coherentVec_normSq (N : ℕ) (z : ℂ × ℂ) (r : Weight N) :
    Complex.normSq (coherentVec N z r) = (N.choose r.val : ℝ) *
      Complex.normSq z.1 ^ (N-r.val) * Complex.normSq z.2 ^ r.val := by
  simp only [coherentVec, map_mul, map_pow, rootChoose, Complex.normSq_ofReal,
    ← pow_two, Real.sq_sqrt (by positivity : (0 : ℝ) ≤ (N.choose r.val : ℝ))]

end F18
