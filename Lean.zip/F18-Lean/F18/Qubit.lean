import F18.Definition
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FinCases

namespace F18

/-- The south pole in the original sphere. -/
def south : Sphere := ⟨(0, 0, -1), by norm_num⟩

/-- Highest-weight spin-up state for N=1. -/
def qubitUp : State 1 := fun r => if r = 0 then 1 else 0

theorem qubitUp_unit : squaredNorm qubitUp = 1 := by
  norm_num [squaredNorm, qubitUp, Fin.sum_univ_two]

private theorem spinSouth : spinMatrix 1 0 1 = !![0, -1; 1, 0] := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    norm_num [spinMatrix, Finset.sum_range_succ, Nat.choose]

private theorem poleDown :
    poleEigenvalue 1 (standardSigns 1) 1 = (1 - Real.sqrt 3) / 2 := by
  have h : Real.sqrt (1 / 3 : ℝ) = Real.sqrt 3 / 3 := by
    rw [Real.sqrt_div (by norm_num : (0 : ℝ) ≤ 1), Real.sqrt_one]
    have hsq := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 3)
    have hp := Real.sqrt_pos.2 (by norm_num : (0 : ℝ) < 3)
    apply (div_eq_iff (ne_of_gt hp)).2
    nlinarith
  unfold poleEigenvalue
  rw [Fin.sum_univ_two]
  norm_num [northCG, rankSign, standardSigns,
    Finset.sum_range_succ, Nat.factorial, h]
  all_goals ring

theorem qubitUp_south_exact :
    wigner (standardSigns 1) qubitUp south = (1 - Real.sqrt 3) / 2 := by
  have hs : spinor south = (0, 1) := by simp [spinor, south]
  unfold wigner kernel
  simp only [hs, spinSouth, Prod.fst, Prod.snd]
  rw [← poleDown]
  simp [projector, qubitUp, Matrix.trace, Matrix.diag_apply, Matrix.mul_apply,
    Matrix.conjTranspose_apply, Matrix.diagonal_apply, Matrix.vecMul, dotProduct, Fin.sum_univ_two]

theorem qubitUp_has_negative_point : ∃ p : Sphere, wigner (standardSigns 1) qubitUp p < 0 := by
  refine ⟨south, ?_⟩
  rw [qubitUp_south_exact]
  have h := Real.sq_sqrt (by norm_num : (0 : ℝ) ≤ 3)
  have hn := Real.sqrt_nonneg 3
  by_contra! hn'
  nlinarith

end F18
