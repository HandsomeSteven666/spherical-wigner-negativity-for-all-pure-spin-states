import F18.QuantitativeBridge
import Mathlib.Analysis.Convex.Integral
import Mathlib.Analysis.Convex.SpecificFunctions.Basic

namespace F18
open MeasureTheory Set

private theorem areaProbability_isProbability : IsProbabilityMeasure areaProbability :=
  ⟨areaProbability_mass⟩

private theorem area_integrable_overlap {N : ℕ} (signs : Weight N → Bool) (ψ φ : State N) :
    Integrable (fun p => |wigner signs ψ p * wigner signs φ p|) areaProbability := by
  letI : IsProbabilityMeasure areaProbability := areaProbability_isProbability
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  have h := ((continuous_wigner signs ψ).mul (continuous_wigner signs φ)).abs
  exact h.integrable_of_hasCompactSupport (HasCompactSupport.of_compactSpace _)

/-- The exact Jensen step from the manuscript, for the concrete normalized sphere.
Only the two logarithmic means and nonvanishing a.e. remain as inputs. -/
theorem overlap_of_log_means {N : ℕ} (signs : Weight N → Bool) (ψ φ : State N)
    (M : ℝ) (hM : 0 < M)
    (hnψ : ∀ᵐ p ∂areaProbability, wigner signs ψ p ≠ 0)
    (hnφ : ∀ᵐ p ∂areaProbability, wigner signs φ p ≠ 0)
    (hiψ : Integrable (fun p => Real.log |wigner signs ψ p|) areaProbability)
    (hiφ : Integrable (fun p => Real.log |wigner signs φ p|) areaProbability)
    (hψ : Real.log M - (1 + Real.exp (-1)) * (N : ℝ) ≤
      ∫ p, Real.log |wigner signs ψ p| ∂areaProbability)
    (hφ : Real.log M - (1 + Real.exp (-1)) * (N : ℝ) ≤
      ∫ p, Real.log |wigner signs φ p| ∂areaProbability) :
    ((N + 1 : ℕ) : ℝ) * M ^ 2 * boundFactor N ≤
      ∫ p, |wigner signs ψ p * wigner signs φ p| ∂spinMeasure N := by
  letI : IsProbabilityMeasure areaProbability := areaProbability_isProbability
  let f : Sphere → ℝ := fun p =>
    Real.log |wigner signs ψ p| + Real.log |wigner signs φ p|
  have hfeq : (fun p => Real.exp (f p)) =ᵐ[areaProbability]
      fun p => |wigner signs ψ p * wigner signs φ p| := by
    filter_upwards [hnψ, hnφ] with p hp hq
    change Real.exp (Real.log |wigner signs ψ p| + Real.log |wigner signs φ p|) =
      |wigner signs ψ p * wigner signs φ p|
    rw [Real.exp_add, Real.exp_log (abs_pos.mpr hp), Real.exp_log (abs_pos.mpr hq), abs_mul]
  have hi : Integrable f areaProbability := hiψ.add hiφ
  have hiexp := (area_integrable_overlap signs ψ φ).congr hfeq.symm
  have hj := convexOn_exp.map_integral_le Real.continuous_exp.continuousOn
    isClosed_univ (Filter.Eventually.of_forall fun _ => mem_univ _) hi hiexp
  have hlo : Real.log M + Real.log M + (-2 * (1 + Real.exp (-1)) * (N : ℝ)) ≤
      ∫ p, f p ∂areaProbability := by
    unfold f
    rw [integral_add hiψ hiφ]
    linarith
  have ha := (Real.exp_le_exp.mpr hlo).trans hj
  rw [Real.exp_add, Real.exp_add, Real.exp_log hM, ← pow_two] at ha
  rw [integral_congr_ae hfeq] at ha
  unfold spinMeasure
  rw [integral_smul_measure, ENNReal.toReal_natCast, smul_eq_mul]
  simpa only [boundFactor, mul_assoc] using
    mul_le_mul_of_nonneg_left ha (show 0 ≤ (((N + 1 : ℕ) : ℝ)) by positivity)

end F18
