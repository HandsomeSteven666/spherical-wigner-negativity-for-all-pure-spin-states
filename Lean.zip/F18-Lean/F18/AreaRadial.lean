import F18.EuclideanRotation
import F18.RadialLatitude
import F18.ZonalTracial
import Mathlib.Analysis.SpecialFunctions.Integrals

namespace F18
open MeasureTheory Set Metric
open scoped Pointwise ENNReal

private def radialCone (S : Set (sphere (0:E3) 1)) : Set E3 :=
  Ioo (0:ℝ) 1 • (Subtype.val '' S)

private theorem radialCone_measurable {S : Set (sphere (0:E3) 1)} (hs : MeasurableSet S) :
    MeasurableSet (radialCone S) := by
  let e := homeomorphUnitSphereProd E3
  let oneR : Ioi (0:ℝ) := ⟨1, mem_Ioi.mpr zero_lt_one⟩
  have hm : MeasurableEmbedding (Subtype.val ∘ e.symm) :=
    (MeasurableEmbedding.subtype_coe (measurableSet_singleton _).compl).comp e.symm.measurableEmbedding
  have he : radialCone S = (Subtype.val ∘ e.symm) '' (S ×ˢ Iio oneR) := by
    ext x
    constructor
    · rintro hx
      obtain ⟨r,hr,_,⟨p,hp,rfl⟩,rfl⟩ := Set.mem_smul.mp hx
      exact ⟨(p,⟨r,hr.1⟩),⟨hp,hr.2⟩,rfl⟩
    · rintro ⟨⟨p,r⟩,⟨hp,hr⟩,rfl⟩
      exact Set.mem_smul.mpr ⟨r.val,⟨r.property,hr⟩,p.val,⟨p,hp,rfl⟩,rfl⟩
  rw [he]
  exact hm.measurableSet_image.mpr (hs.prod measurableSet_Iio)

private theorem smul_mem_radialCone {S : Set (sphere (0:E3) 1)} (p : sphere (0:E3) 1)
    (R : ℝ) (hR : 0 < R) :
    R • p.val ∈ radialCone S ↔ R < 1 ∧ p ∈ S := by
  constructor
  · intro h
    obtain ⟨r,hr,_,⟨q,hq,rfl⟩,he⟩ := Set.mem_smul.mp h
    have hpN : ‖p.val‖ = 1 := mem_sphere_zero_iff_norm.mp p.property
    have hqN : ‖q.val‖ = 1 := mem_sphere_zero_iff_norm.mp q.property
    have hrR := congrArg (fun x : E3 => ‖x‖) he
    simp only [norm_smul, hpN, hqN, mul_one, Real.norm_eq_abs,
      abs_of_pos hr.1, abs_of_pos hR] at hrR
    rw [hrR] at hr he
    have hqp : q = p := Subtype.ext (smul_right_injective E3 hR.ne' he)
    exact ⟨hr.2,hqp ▸ hq⟩
  · rintro ⟨h1,hp⟩
    exact Set.mem_smul.mpr ⟨R,⟨hR,h1⟩,p.val,⟨p,hp,rfl⟩,rfl⟩

private def cartesianEuclidean (x : (ℝ × ℝ) × ℝ) : E3 :=
  (WithLp.equiv 2 _).symm ![x.1.1,x.1.2,x.2]

private theorem cartesianEuclidean_continuous : Continuous cartesianEuclidean := by
  unfold cartesianEuclidean
  apply (PiLp.continuous_equiv_symm 2 (fun _ : Fin 3 => ℝ)).comp
  apply continuous_pi
  intro i
  fin_cases i <;> simp <;> fun_prop

private theorem cartesianEuclidean_euclideanCartesian (x : E3) :
    cartesianEuclidean (euclideanCartesian x) = x := by
  ext i
  fin_cases i <;> rfl

private theorem cartesianEuclidean_chart (t φ R : ℝ) (ht : t ∈ Ioo (-1:ℝ) 1) :
    cartesianEuclidean (((R*Real.sqrt (1-t^2))*Real.cos φ,
        (R*Real.sqrt (1-t^2))*Real.sin φ),R*t) =
      R • (sphereEuclidean (sphereChart (t,φ))).val := by
  have ht₀ := ht.1
  have ht₁ := ht.2
  have hn : 0 < (1-t)*(1+t) := mul_pos (by linarith) (by linarith)
  have h : t^2 ≤ 1 := by nlinarith
  change _ = R • sphereEuclideanCoords (sphereChart (t,φ))
  unfold sphereEuclideanCoords cartesianEuclidean
  rw [sphereChart_val h]
  ext i
  fin_cases i <;> change _ = _ <;> simp [WithLp.equiv_symm_pi_apply] <;> ring

private theorem integral_radius_sq :
    (∫⁻ R in Ioo (0:ℝ) 1, ENNReal.ofReal (R^2)) = ENNReal.ofReal (1/3) := by
  rw [restrict_Ioo_eq_restrict_Icc, ← ofReal_integral_eq_lintegral_ofReal,
    integral_restrict_eq_interval (by norm_num : (0:ℝ) ≤ 1), integral_pow]
  · norm_num
  · exact ((continuous_id.pow 2).continuousOn.integrableOn_compact isCompact_Icc)
  · exact Filter.Eventually.of_forall (fun _ => sq_nonneg _)


private theorem sector_period_integral (A : Set Sphere) (hA : MeasurableSet A) (t : ℝ) :
    (∫⁻ φ in Ioo (-Real.pi) Real.pi, A.indicator (fun _ => (1:ℝ≥0∞)) (sphereChart (t,φ))) =
      ∫⁻ φ in Icc 0 (2*Real.pi), A.indicator (fun _ => (1:ℝ≥0∞)) (sphereChart (t,φ)) := by
  let f (φ : ℝ) := A.indicator (fun _ => (1:ℝ)) (sphereChart (t,φ))
  have hme := measurable_sphereChart.comp (measurable_const.prodMk measurable_id : Measurable fun φ : ℝ => (t,φ))
  have hf : Measurable f := (measurable_const.indicator hA).comp hme
  have hnon (φ : ℝ) : 0 ≤ f φ := by by_cases h : sphereChart (t,φ) ∈ A <;> simp [f,h]
  have hbound (φ : ℝ) : ‖f φ‖ ≤ 1 := by by_cases h : sphereChart (t,φ) ∈ A <;> simp [f,h]
  have hreal (φ : ℝ) : ENNReal.ofReal (f φ) =
      A.indicator (fun _ => (1:ℝ≥0∞)) (sphereChart (t,φ)) := by
    by_cases h : sphereChart (t,φ) ∈ A <;> simp [f,h]
  have hi (a b : ℝ) : Integrable f (volume.restrict (Icc a b)) :=
    (integrable_const (1:ℝ)).mono' hf.aestronglyMeasurable (Filter.Eventually.of_forall hbound)
  have hper : Function.Periodic f (2*Real.pi) := by
    intro φ
    unfold f
    have hchart : sphereChart (t,φ+2*Real.pi) = sphereChart (t,φ) := by
      by_cases ht : t^2 ≤ 1
      · apply Subtype.ext
        rw [sphereChart_val ht, sphereChart_val ht]
        simp [Real.cos_add_two_pi, Real.sin_add_two_pi]
      · simp [sphereChart, ht]
    rw [hchart]
  simp_rw [← hreal]
  rw [restrict_Ioo_eq_restrict_Icc, ← ofReal_integral_eq_lintegral_ofReal (hi _ _)
      (Filter.Eventually.of_forall hnon),
    ← ofReal_integral_eq_lintegral_ofReal (hi _ _) (Filter.Eventually.of_forall hnon),
    integral_restrict_eq_interval (by linarith [Real.pi_pos] : -Real.pi ≤ Real.pi),
    integral_restrict_eq_interval (by positivity : 0 ≤ 2*Real.pi)]
  congr 1
  have he := hper.intervalIntegral_add_eq_of_pos (by positivity : 0 < 2*Real.pi) (-Real.pi) 0
  convert he using 2 <;> ring

private noncomputable def coneSector (S : Set (sphere (0:E3) 1)) (t φ : ℝ) : ℝ≥0∞ :=
  S.indicator (fun _ => 1) (sphereEuclidean (sphereChart (t,φ)))

private noncomputable def coneCartesianIndicator (S : Set (sphere (0:E3) 1))
    (x : (ℝ × ℝ) × ℝ) : ℝ≥0∞ :=
  (radialCone S).indicator (fun _ => 1) (cartesianEuclidean x)

set_option maxHeartbeats 400000 in
private theorem radialCone_restrict_section (S : Set (sphere (0:E3) 1)) (φ : ℝ) :
      (∫⁻ R in Ioi (0:ℝ), ∫⁻ t in Ioo (-1:ℝ) 1, ENNReal.ofReal (R^2) *
        coneCartesianIndicator S (((R*Real.sqrt (1-t^2))*Real.cos φ, (R*Real.sqrt (1-t^2))*Real.sin φ),R*t)) =
      ENNReal.ofReal (1/3) * ∫⁻ t in Ioo (-1:ℝ) 1, coneSector S t φ := by
    classical
    have hin (R : ℝ) (hR : R ∈ Ioi (0:ℝ)) :
        (∫⁻ t in Ioo (-1:ℝ) 1, ENNReal.ofReal (R^2) *
          coneCartesianIndicator S (((R*Real.sqrt (1-t^2))*Real.cos φ, (R*Real.sqrt (1-t^2))*Real.sin φ),R*t)) =
        (Iio (1:ℝ)).indicator (fun r => ENNReal.ofReal (r^2)) R *
          ∫⁻ t in Ioo (-1:ℝ) 1, coneSector S t φ := by
      have hfinite : (Iio (1:ℝ)).indicator (fun r => ENNReal.ofReal (r^2)) R ≠ ⊤ := by
        by_cases h : R < 1 <;> simp [h]
      rw [← lintegral_const_mul' _ _ hfinite]
      apply setLIntegral_congr_fun measurableSet_Ioo
      filter_upwards with t ht
      unfold coneCartesianIndicator coneSector
      rw [cartesianEuclidean_chart t φ R ht, indicator_apply,
        smul_mem_radialCone _ R hR]
      by_cases h₁ : R < 1 <;> by_cases h₂ : sphereEuclidean (sphereChart (t,φ)) ∈ S <;>
        simp [h₁,h₂]
    calc
      _ = ∫⁻ R in Ioi (0:ℝ), (Iio (1:ℝ)).indicator (fun r => ENNReal.ofReal (r^2)) R *
          ∫⁻ t in Ioo (-1:ℝ) 1, coneSector S t φ := by
            apply setLIntegral_congr_fun measurableSet_Ioi
            filter_upwards with R hR using hin R hR
      _ = _ := by
        have hp : Measurable (fun r : ℝ => ENNReal.ofReal (r^2)) := by fun_prop
        have hpi := hp.indicator (measurableSet_Iio (a := (1:ℝ)))
        rw [lintegral_mul_const _ hpi, lintegral_indicator measurableSet_Iio, Measure.restrict_restrict
            measurableSet_Iio, Iio_inter_Ioi, integral_radius_sq]

private theorem coneSector_measurable {S : Set (sphere (0:E3) 1)} (hs : MeasurableSet S) :
    Measurable (Function.uncurry (coneSector S)) :=
  (measurable_const.indicator hs).comp
    (sphereEuclideanHomeomorph.continuous_toFun.measurable.comp measurable_sphereChart)

private theorem coneSector_period_for_latitude {S : Set (sphere (0:E3) 1)} (hs : MeasurableSet S)
    (t : ℝ) :
    (∫⁻ φ in Ioo (-Real.pi) Real.pi, coneSector S t φ) =
      ∫⁻ φ in Icc 0 (2*Real.pi), coneSector S t φ := by
  let A := sphereEuclidean ⁻¹' S
  have hA : MeasurableSet A := sphereEuclideanHomeomorph.continuous_toFun.measurable hs
  have hx (φ : ℝ) : coneSector S t φ =
      A.indicator (fun _ => (1:ℝ≥0∞)) (sphereChart (t,φ)) := by
    classical
    by_cases h : sphereEuclidean (sphereChart (t,φ)) ∈ S <;>
      simp only [coneSector, A, indicator_apply, mem_preimage, h, if_true, if_false]
  calc
    _ = _ := (lintegral_congr hx).trans (sector_period_integral A hA t)
    _ = _ := lintegral_congr fun φ => (hx φ).symm

private theorem lintegral_replace_angular_measure (g : ℝ → ℝ → ℝ≥0∞)
    (μ ν ν' : Measure ℝ) [SFinite μ] [SFinite ν] [SFinite ν']
    (h : Measurable (Function.uncurry g))
    (hsec : ∀ t, (∫⁻ φ, g t φ ∂ν) = ∫⁻ φ, g t φ ∂ν') :
    (∫⁻ φ, ∫⁻ t, g t φ ∂μ ∂ν) = ∫⁻ φ, ∫⁻ t, g t φ ∂μ ∂ν' := by
  have h' : Measurable (Function.uncurry (fun φ t => g t φ)) := h.comp measurable_swap
  calc
    _ = ∫⁻ t, ∫⁻ φ, g t φ ∂ν ∂μ :=
      lintegral_lintegral_swap (μ := ν) (ν := μ) h'.aemeasurable
    _ = ∫⁻ t, ∫⁻ φ, g t φ ∂ν' ∂μ := lintegral_congr hsec
    _ = _ := lintegral_lintegral_swap (μ := μ) (ν := ν') h.aemeasurable

private theorem coneSector_period {S : Set (sphere (0:E3) 1)} (hs : MeasurableSet S) :
    (∫⁻ φ in Ioo (-Real.pi) Real.pi, ∫⁻ t in Ioo (-1:ℝ) 1, coneSector S t φ) =
      ∫⁻ φ in Icc 0 (2*Real.pi), ∫⁻ t in Icc (-1:ℝ) 1, coneSector S t φ := by
  simp only [restrict_Ioo_eq_restrict_Icc (a := (-1:ℝ)) (b := (1:ℝ))]
  exact lintegral_replace_angular_measure _ _ _ _ (coneSector_measurable hs)
    (coneSector_period_for_latitude hs)

set_option maxHeartbeats 400000 in
private theorem radialCone_volume {S : Set (sphere (0:E3) 1)} (hs : MeasurableSet S) :
    (volume : Measure E3) (radialCone S) =
      ENNReal.ofReal (1/3) * ∫⁻ φ in Icc 0 (2*Real.pi), ∫⁻ t in Icc (-1:ℝ) 1,
        S.indicator (fun _ => (1:ℝ≥0∞)) (sphereEuclidean (sphereChart (t,φ))) := by
  classical
  let c : E3 → ℝ≥0∞ := (radialCone S).indicator (fun _ => 1)
  have hc : Measurable c := measurable_const.indicator (radialCone_measurable hs)
  have hf : Measurable (coneCartesianIndicator S) := hc.comp cartesianEuclidean_continuous.measurable
  rw [← lintegral_indicator_one (radialCone_measurable hs)]
  change (∫⁻ x, c x) = _
  have hcv : (∫⁻ x, c x) = ∫⁻ w, coneCartesianIndicator S w := by
    rw [← euclideanCartesian_measurePreserving.map_eq, lintegral_map hf
      euclideanCartesian_measurePreserving.measurable]
    simp [c, coneCartesianIndicator, cartesianEuclidean_euclideanCartesian]
  rw [hcv, lintegral_spherical_coordinates _ hf]
  calc
    _ = ∫⁻ φ in Ioo (-Real.pi) Real.pi, ENNReal.ofReal (1/3) *
        ∫⁻ t in Ioo (-1:ℝ) 1, coneSector S t φ := lintegral_congr (radialCone_restrict_section S)
    _ = _ := by
      rw [lintegral_const_mul' _ _ ENNReal.ofReal_ne_top, coneSector_period hs]
      rfl


/-- The concrete polar chart has exactly the underlying SO(3)-invariant area
measure, normalized by (4pi). -/
theorem areaProbability_eq_radialArea :
    Measure.map sphereEuclidean areaProbability =
      ENNReal.ofReal ((4*Real.pi)⁻¹) • (volume : Measure E3).toSphere := by
  have hm : Measurable sphereEuclidean := sphereEuclideanHomeomorph.continuous_toFun.measurable
  ext S hs
  rw [areaProbability, Measure.map_smul, Measure.smul_apply, Measure.smul_apply,
    Measure.map_map hm measurable_sphereChart, Measure.toSphere_apply' _ hs]
  congr 1
  change _ = _ * volume (radialCone S)
  rw [radialCone_volume hs, ← mul_assoc]
  have hdim : (Module.finrank ℝ E3 : ℝ≥0∞) * ENNReal.ofReal (1/3) = 1 := by
    simp only [E3, finrank_euclideanSpace, Fintype.card_fin]
    change (3:ℝ≥0∞) * ENNReal.ofReal (1/3) = 1
    rw [show (3:ℝ≥0∞) = ENNReal.ofReal 3 by norm_num, ← ENNReal.ofReal_mul (by norm_num)]
    norm_num
  rw [hdim, one_mul]
  rw [Measure.map_apply (hm.comp measurable_sphereChart) hs,
    ← lintegral_indicator_one ((hm.comp measurable_sphereChart) hs),
    Measure.volume_eq_prod, ← Measure.prod_restrict, lintegral_prod_symm]
  · apply lintegral_congr
    intro φ
    apply lintegral_congr
    intro t
    by_cases h : sphereEuclidean (sphereChart (t,φ)) ∈ S <;>
      simp [Function.comp, indicator_apply, h]
  · exact ((measurable_const.indicator ((hm.comp measurable_sphereChart) hs))).aemeasurable

theorem sphereRotationInvariant : SphereRotationInvariant :=
  sphereRotationInvariant_of_radialArea areaProbability_eq_radialArea

theorem spinWignerTracial : SpinWignerTracial :=
  spinWignerTracial_of_rotationInvariant sphereRotationInvariant


def sphereAntipode (p : Sphere) : Sphere :=
  ⟨(-p.val.1,-p.val.2.1,-p.val.2.2), by simpa only [neg_sq] using p.property⟩

theorem sphereAntipode_preserves_area :
    MeasurePreserving sphereAntipode areaProbability areaProbability := by
  letI : BorelSpace Sphere := Subtype.borelSpace _
  let e := sphereEuclideanHomeomorph.toMeasurableEquiv
  let L : E3 ≃ₗᵢ[ℝ] E3 := LinearIsometryEquiv.neg ℝ
  have hR := sphereOfLinearIso_preserves_toSphere L
  have ha : Measurable sphereAntipode := by
    apply Continuous.measurable
    unfold sphereAntipode
    apply Continuous.subtype_mk
    fun_prop
  have he : Measurable sphereEuclidean := e.measurable
  have hcomp : sphereEuclidean ∘ sphereAntipode = sphereOfLinearIso L ∘ sphereEuclidean := by
    funext p
    apply Subtype.ext
    change sphereEuclideanCoords (sphereAntipode p) = -sphereEuclideanCoords p
    ext i
    fin_cases i <;> rfl
  refine ⟨ha, e.map_measurableEquiv_injective ?_⟩
  change Measure.map sphereEuclidean (Measure.map sphereAntipode areaProbability) =
    Measure.map sphereEuclidean areaProbability
  rw [Measure.map_map he ha, hcomp, ← Measure.map_map hR.measurable he,
    areaProbability_eq_radialArea, Measure.map_smul, hR.map_eq]

end F18
