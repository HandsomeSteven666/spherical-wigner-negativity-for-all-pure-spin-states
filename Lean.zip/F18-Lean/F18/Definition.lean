import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Analysis.Complex.Basic
import Mathlib.LinearAlgebra.Matrix.Trace
import Mathlib.Data.Matrix.ConjTranspose

/-! Concrete statement of F18. No abstract Wigner axioms occur in the statement. -/
namespace F18

open scoped BigOperators

/-- Ordinary unit sphere in three real Cartesian coordinates. -/
abbrev Sphere :=
  {p : ℝ × ℝ × ℝ // p.1 ^ 2 + p.2.1 ^ 2 + p.2.2 ^ 2 = 1}

/-- N is twice the spin. The index r corresponds to m = N/2 − r. -/
abbrev Weight (N : ℕ) := Fin (N + 1)
abbrev State (N : ℕ) := Weight N → ℂ
abbrev Operator (N : ℕ) := Matrix (Weight N) (Weight N) ℂ

def squaredNorm {N : ℕ} (ψ : State N) : ℝ :=
  ∑ r, Complex.normSq (ψ r)

/-- C_{j,m;ℓ,0}^{j,m} in the north-pole convention of the manuscript,
with N = 2j and r = j − m. The finite factorial sum has admissible terms only. -/
noncomputable def northCG (N : ℕ) (r l : Weight N) : ℝ :=
  Real.sqrt
    (((N + 1 : ℕ) : ℝ) * (Nat.factorial (N - l.val) : ℝ) *
       (Nat.factorial l.val : ℝ) ^ 2 / (Nat.factorial (N + l.val + 1) : ℝ)) *
    (Nat.factorial l.val : ℝ) * (Nat.factorial (N - r.val) : ℝ) *
    (Nat.factorial r.val : ℝ) *
    ∑ q ∈ Finset.range (l.val + 1),
      if q ≤ r.val ∧ l.val + r.val ≤ N + q then
        (-1 : ℝ) ^ q /
          ((Nat.factorial q : ℝ) ^ 2 * (Nat.factorial (l.val - q) : ℝ) ^ 2 *
            (Nat.factorial (r.val - q) : ℝ) *
            (Nat.factorial (N + q - l.val - r.val) : ℝ))
      else 0

/-- The rank-zero sign is fixed to +1. Other ranks have independent signs. -/
def rankSign {N : ℕ} (signs : Weight N → Bool) (l : Weight N) : ℝ :=
  if l.val = 0 ∨ signs l = true then 1 else -1

noncomputable def poleEigenvalue (N : ℕ) (signs : Weight N → Bool) (r : Weight N) : ℝ :=
  ∑ l, rankSign signs l * ((2 * l.val + 1 : ℕ) : ℝ) /
    ((N + 1 : ℕ) : ℝ) * northCG N r l

/-- A section of the spinor-to-sphere map, with its south pole defined separately.
The represented rotation sends the north pole to p. -/
noncomputable def spinor (p : Sphere) : ℂ × ℂ :=
  if p.val.2.2 = -1 then (0, 1)
  else
    let a := Real.sqrt ((1 + p.val.2.2) / 2)
    ((a : ℂ), ((p.val.1 : ℂ) + (p.val.2.1 : ℂ) * Complex.I) / (2 * (a : ℂ)))

/-- The Nth symmetric power of the spinor matrix [a, −conj b; b, conj a]
in the normalized monomial basis. -/
noncomputable def spinMatrix (N : ℕ) (a b : ℂ) : Operator N :=
  fun r s =>
    (Real.sqrt ((Nat.choose N s.val : ℝ) / (Nat.choose N r.val : ℝ)) : ℂ) *
    ∑ u ∈ Finset.range (N - s.val + 1),
      if u ≤ r.val ∧ r.val - u ≤ s.val then
        ((Nat.choose (N - s.val) u : ℕ) : ℂ) *
        ((Nat.choose s.val (r.val - u) : ℕ) : ℂ) *
        a ^ (N - s.val - u) * b ^ u *
        (-starRingEnd ℂ b) ^ (s.val - (r.val - u)) *
        (starRingEnd ℂ a) ^ (r.val - u)
      else 0

/-- The north-pole Clebsch–Gordan diagonal, conjugated by the spin rotation. -/
noncomputable def kernel (N : ℕ) (signs : Weight N → Bool) (p : Sphere) : Operator N :=
  let u := spinMatrix N (spinor p).1 (spinor p).2
  u * Matrix.diagonal (fun r => (poleEigenvalue N signs r : ℂ)) * u.conjTranspose

noncomputable def projector {N : ℕ} (ψ : State N) : Operator N :=
  fun r s => ψ r * starRingEnd ℂ (ψ s)

/-- Real trace of the original pure-state Wigner symbol. -/
noncomputable def wigner {N : ℕ} (signs : Weight N → Bool)
    (ψ : State N) (p : Sphere) : ℝ :=
  (Matrix.trace (projector ψ * kernel N signs p)).re

def standardSigns (N : ℕ) : Weight N → Bool := fun _ => true

/-- Catalogue F18, expressed as the existence of a negative point.
The sole spin/state restrictions are 0 < 2j and unit normalization. -/
def OriginalF18 : Prop :=
  ∀ (N : ℕ), 0 < N → ∀ (ψ : State N), squaredNorm ψ = 1 →
    ∃ p : Sphere, wigner (standardSigns N) ψ p < 0

/-- The stronger proposition in the manuscript, quantifying over every sign choice. -/
def OriginalAllSigns : Prop :=
  ∀ (N : ℕ), 0 < N → ∀ (signs : Weight N → Bool) (ψ : State N), squaredNorm ψ = 1 →
    ∃ p : Sphere, wigner signs ψ p < 0

/-- Exact attained-minimum form of the manuscript's qualitative theorem. -/
def OriginalMinimumNegativity : Prop :=
  ∀ (N : ℕ), 0 < N → ∀ (signs : Weight N → Bool) (ψ : State N), squaredNorm ψ = 1 →
    ∃ p : Sphere, (∀ q : Sphere, wigner signs ψ p ≤ wigner signs ψ q) ∧
      wigner signs ψ p < 0

theorem allSigns_of_minimum (h : OriginalMinimumNegativity) : OriginalAllSigns := by
  intro N hN signs ψ hψ
  obtain ⟨p, _, hp⟩ := h N hN signs ψ hψ
  exact ⟨p, hp⟩

/-- Restriction to the standard sign choice; no geometric premise is added. -/
theorem original_of_allSigns (h : OriginalAllSigns) : OriginalF18 :=
  fun N hN ψ hψ => h N hN (standardSigns N) ψ hψ

end F18
