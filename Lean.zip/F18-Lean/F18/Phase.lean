import F18.Definition
import Mathlib.Tactic.Ring

namespace F18
open scoped BigOperators

/-- Multiplying both spinor coordinates by c changes only the phases of the
columns in the symmetric power matrix. This algebraic identity requires no
condition on c. -/
theorem spinMatrix_phase_entry (N : ℕ) (a b c : ℂ) (r s : Weight N) :
    spinMatrix N (c * a) (c * b) r s =
      spinMatrix N a b r s * (c ^ (N - s.val) * (starRingEnd ℂ c) ^ s.val) := by
  classical
  let d := c ^ (N - s.val) * (starRingEnd ℂ c) ^ s.val
  change spinMatrix N (c * a) (c * b) r s = spinMatrix N a b r s * d
  unfold spinMatrix
  rw [mul_assoc, Finset.sum_mul]
  congr 1
  apply Finset.sum_congr rfl
  intro u hu
  by_cases h : u ≤ r.val ∧ r.val - u ≤ s.val
  · have hu' : u ≤ N - s.val := by
      have := Finset.mem_range.mp hu
      omega
    have h1 : N - s.val - u + u = N - s.val := Nat.sub_add_cancel hu'
    have h2 : s.val - (r.val - u) + (r.val - u) = s.val := Nat.sub_add_cancel h.2
    simp only [if_pos h, map_mul, neg_mul_eq_mul_neg, mul_pow]
    have hc : c ^ (N - s.val - u) * c ^ u = c ^ (N - s.val) := by rw [← pow_add, h1]
    have hsc : (starRingEnd ℂ c) ^ (s.val - (r.val - u)) *
        (starRingEnd ℂ c) ^ (r.val - u) = (starRingEnd ℂ c) ^ s.val := by
      rw [← pow_add, h2]
    unfold d
    rw [← hc, ← hsc]
    ring
  · simp only [if_neg h, zero_mul]

/-- Conjugation of the same pole diagonal, before selecting a representative. -/
noncomputable def kernelFromSpinor (N : ℕ) (signs : Weight N → Bool) (a b : ℂ) : Operator N :=
  let U := spinMatrix N a b
  U * Matrix.diagonal (fun r => (poleEigenvalue N signs r : ℂ)) * U.conjTranspose

theorem kernel_eq_kernelFromSpinor (N : ℕ) (signs : Weight N → Bool) (p : Sphere) :
    kernel N signs p = kernelFromSpinor N signs (spinor p).1 (spinor p).2 := rfl

/-- The kernel is independent of the common unit phase of the spinor. -/
theorem kernelFromSpinor_phase (N : ℕ) (signs : Weight N → Bool) (a b c : ℂ)
    (hc : c * starRingEnd ℂ c = 1) :
    kernelFromSpinor N signs (c * a) (c * b) = kernelFromSpinor N signs a b := by
  classical
  ext r s
  simp only [kernelFromSpinor]
  rw [Matrix.mul_apply, Matrix.mul_apply]
  simp only [Matrix.mul_diagonal,
    Matrix.conjTranspose_apply]
  apply Finset.sum_congr rfl
  intro q _
  rw [spinMatrix_phase_entry, spinMatrix_phase_entry]
  let d := c ^ (N - q.val) * (starRingEnd ℂ c) ^ q.val
  have hd : d * star d = 1 := by
    change d * starRingEnd ℂ d = 1
    unfold d
    simp only [map_mul, map_pow, starRingEnd_apply, star_star]
    calc
      _ = (c * star c) ^ (N - q.val) * (c * star c) ^ q.val := by
        simp only [mul_pow]
        ring
      _ = 1 := by
        change (c * starRingEnd ℂ c) ^ (N - q.val) * (c * starRingEnd ℂ c) ^ q.val = _
        simp [hc]
  change (spinMatrix N a b r q * d * (poleEigenvalue N signs q : ℂ)) *
      star (spinMatrix N a b s q * d) =
    (spinMatrix N a b r q * (poleEigenvalue N signs q : ℂ)) * star (spinMatrix N a b s q)
  rw [star_mul]
  calc
    _ = ((spinMatrix N a b r q * (poleEigenvalue N signs q : ℂ)) *
        star (spinMatrix N a b s q)) * (d * star d) := by ring
    _ = _ := by rw [hd, mul_one]

/-- Unit spinors describing the same Bloch point differ by a common unit phase. -/
theorem exists_phase_of_bloch_eq (a b a' b' : ℂ)
    (hunit : Complex.normSq a + Complex.normSq b = 1)
    (hunit' : Complex.normSq a' + Complex.normSq b' = 1)
    (ha : Complex.normSq a = Complex.normSq a')
    (heq : starRingEnd ℂ a * b = starRingEnd ℂ a' * b') :
    ∃ c : ℂ, c * starRingEnd ℂ c = 1 ∧ a' = c * a ∧ b' = c * b := by
  have hh (u v : ℂ) (hv : v ≠ 0) (hn : Complex.normSq u = Complex.normSq v) :
      (u / v) * starRingEnd ℂ (u / v) = 1 := by
    rw [Complex.mul_conj, Complex.normSq_div, hn, div_self]
    · simp
    · exact fun h => hv (Complex.normSq_eq_zero.mp h)
  by_cases hz : a = 0
  · subst a
    have hz' : a' = 0 := Complex.normSq_eq_zero.mp (by simpa using ha.symm)
    subst a'
    have hn : Complex.normSq b' = Complex.normSq b := by simpa using hunit'.trans hunit.symm
    have hb : b ≠ 0 := by
      intro h
      simp [h] at hunit
    refine ⟨b' / b, hh b' b hb hn, by simp, ?_⟩
    exact (div_mul_cancel₀ b' hb).symm
  · let c := a' / a
    have hc : c * starRingEnd ℂ c = 1 := hh a' a hz ha.symm
    have hca : a' = c * a := (div_mul_cancel₀ a' hz).symm
    have hsc : starRingEnd ℂ a ≠ 0 := (map_ne_zero _).2 hz
    rw [hca, map_mul] at heq
    have hcb : b = starRingEnd ℂ c * b' := by
      apply mul_left_cancel₀ hsc
      calc
        _ = (starRingEnd ℂ c * starRingEnd ℂ a) * b' := heq
        _ = _ := by ring
    refine ⟨c, hc, hca, ?_⟩
    calc
      b' = (c * starRingEnd ℂ c) * b' := by rw [hc, one_mul]
      _ = c * b := by rw [hcb, mul_assoc]

/-- All spinor representatives of the same Bloch point give the same kernel. -/
theorem kernelFromSpinor_bloch_eq (N : ℕ) (signs : Weight N → Bool) (a b a' b' : ℂ)
    (hunit : Complex.normSq a + Complex.normSq b = 1)
    (hunit' : Complex.normSq a' + Complex.normSq b' = 1)
    (ha : Complex.normSq a = Complex.normSq a')
    (heq : starRingEnd ℂ a * b = starRingEnd ℂ a' * b') :
    kernelFromSpinor N signs a' b' = kernelFromSpinor N signs a b := by
  obtain ⟨c, hc, hca, hcb⟩ := exists_phase_of_bloch_eq a b a' b' hunit hunit' ha heq
  rw [hca, hcb, kernelFromSpinor_phase N signs a b c hc]

end F18
