import F18.Definition
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp

namespace F18

/-- The section uses unit spinors with the prescribed polar coordinate. -/
theorem spinor_norms (p : Sphere) :
    Complex.normSq (spinor p).1 = (1 + p.val.2.2) / 2 ∧
    Complex.normSq (spinor p).2 = (1 - p.val.2.2) / 2 := by
  rcases p with ⟨⟨x, y, z⟩, hp⟩
  change x ^ 2 + y ^ 2 + z ^ 2 = 1 at hp
  by_cases hz : z = -1
  · subst z
    norm_num [spinor, Complex.normSq_ofReal]
  · have hz₁ : -1 < z := by
      have hz₂ : -1 ≤ z := by nlinarith [sq_nonneg x, sq_nonneg y]
      exact lt_of_le_of_ne hz₂ (Ne.symm hz)
    let a := Real.sqrt ((1 + z) / 2)
    have ha : 0 < a := Real.sqrt_pos.2 (by linarith)
    have ha₂ : a ^ 2 = (1 + z) / 2 := Real.sq_sqrt (by linarith)
    have hchoice : spinor ⟨(x, y, z), hp⟩ =
        ((a : ℂ), ((x : ℂ) + (y : ℂ) * Complex.I) / (2 * (a : ℂ))) := by
      simp [spinor, hz, a]
    rw [hchoice]
    constructor
    · change Complex.normSq (a : ℂ) = (1 + z) / 2
      rw [Complex.normSq_ofReal, ← pow_two, ha₂]
    · change Complex.normSq (((x : ℂ) + (y : ℂ) * Complex.I) / (2 * (a : ℂ))) =
        (1 - z) / 2
      rw [Complex.normSq_div, Complex.normSq_add_mul_I, Complex.normSq_mul,
        Complex.normSq_ofReal, ← pow_two, ha₂]
      norm_num
      have hden : 4 * ((1 + z) / 2) ≠ 0 := by linarith
      apply (div_eq_iff hden).2
      nlinarith [hp]

theorem spinor_unit (p : Sphere) :
    Complex.normSq (spinor p).1 + Complex.normSq (spinor p).2 = 1 := by
  rw [(spinor_norms p).1, (spinor_norms p).2]
  ring

/-- The complex equatorial coordinate of the section is the original x+iy. -/
theorem spinor_equator (p : Sphere) :
    2 * starRingEnd ℂ (spinor p).1 * (spinor p).2 =
      (p.val.1 : ℂ) + (p.val.2.1 : ℂ) * Complex.I := by
  rcases p with ⟨⟨x, y, z⟩, hp⟩
  change x ^ 2 + y ^ 2 + z ^ 2 = 1 at hp
  by_cases hz : z = -1
  · subst z
    have hx : x = 0 := by nlinarith [sq_nonneg y]
    have hy : y = 0 := by nlinarith [sq_nonneg x]
    simp [spinor, hx, hy]
  · have hz₁ : -1 < z :=
      lt_of_le_of_ne (by nlinarith [sq_nonneg x, sq_nonneg y]) (Ne.symm hz)
    let a := Real.sqrt ((1 + z) / 2)
    have ha : 0 < a := Real.sqrt_pos.2 (by linarith)
    have hchoice : spinor ⟨(x, y, z), hp⟩ =
        ((a : ℂ), ((x : ℂ) + (y : ℂ) * Complex.I) / (2 * (a : ℂ))) := by
      simp [spinor, hz, a]
    rw [hchoice]
    change (2 : ℂ) * starRingEnd ℂ (a : ℂ) *
      (((x : ℂ) + (y : ℂ) * Complex.I) / (2 * (a : ℂ))) = _
    rw [Complex.conj_ofReal]
    have hne : (2 : ℂ) * (a : ℂ) ≠ 0 := mul_ne_zero (by norm_num) (by exact_mod_cast ha.ne')
    rw [mul_div_cancel₀ _ hne]

/-- The concrete unit sphere is compact, as a closed subset of [-1,1]^3. -/
theorem sphere_isCompact :
    IsCompact {p : ℝ × ℝ × ℝ | p.1 ^ 2 + p.2.1 ^ 2 + p.2.2 ^ 2 = 1} := by
  have hcont : Continuous (fun p : ℝ × ℝ × ℝ =>
      p.1 ^ 2 + p.2.1 ^ 2 + p.2.2 ^ 2) :=
    ((continuous_fst.pow 2).add ((continuous_fst.comp continuous_snd).pow 2)).add
      ((continuous_snd.comp continuous_snd).pow 2)
  have hclosed : IsClosed {p : ℝ × ℝ × ℝ | p.1 ^ 2 + p.2.1 ^ 2 + p.2.2 ^ 2 = 1} :=
    isClosed_eq hcont continuous_const
  have hI : IsCompact (Set.Icc (-1 : ℝ) 1) := isCompact_Icc
  apply (hI.prod (hI.prod hI)).of_isClosed_subset hclosed
  rintro ⟨x, y, z⟩ h
  change x ^ 2 + y ^ 2 + z ^ 2 = 1 at h
  exact ⟨⟨by nlinarith [sq_nonneg y, sq_nonneg z], by nlinarith [sq_nonneg y, sq_nonneg z]⟩,
    ⟨by nlinarith [sq_nonneg x, sq_nonneg z], by nlinarith [sq_nonneg x, sq_nonneg z]⟩,
    ⟨by nlinarith [sq_nonneg x, sq_nonneg y], by nlinarith [sq_nonneg x, sq_nonneg y]⟩⟩

/-- Converts the existence of a negative point to the manuscript's attained
minimum once continuity of the concrete symbol has been proved. -/
theorem negative_minimum_of_continuous (f : Sphere → ℝ) (hf : Continuous f)
    (hneg : ∃ p : Sphere, f p < 0) :
    ∃ p : Sphere, (∀ q : Sphere, f p ≤ f q) ∧ f p < 0 := by
  letI : CompactSpace Sphere := isCompact_iff_compactSpace.mp sphere_isCompact
  obtain ⟨q, hq⟩ := hneg
  obtain ⟨p, _, hp⟩ := isCompact_univ.exists_isMinOn
    (show (Set.univ : Set Sphere).Nonempty from ⟨q, trivial⟩) hf.continuousOn
  have hle (r : Sphere) : f p ≤ f r := hp (Set.mem_univ r)
  exact ⟨p, hle, lt_of_le_of_lt (hle q) hq⟩

end F18
